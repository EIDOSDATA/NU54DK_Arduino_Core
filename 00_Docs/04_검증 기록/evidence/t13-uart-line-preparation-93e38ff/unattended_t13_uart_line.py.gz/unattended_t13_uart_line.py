"""! @brief 앞선 실기 배치가 끝난 뒤 남은 확인 시간 안에서 UART 오류를 검증합니다. """
from pathlib import Path

helper = Path(__file__).with_name('unattended_t13_followups.py')
prefix = helper.read_text(encoding='utf-8').split('\ntry:\n    save()')[0]
prefix = prefix.replace("'unattended-s-followups-01.json'", "'unattended-s-uart-line-01.json'")
prefix = prefix.replace("'waiting-for-current-S-batch'", "'waiting-for-conflict-and-CTS-diagnostics'")
exec(compile(prefix, str(helper), 'exec'))

try:
    save()
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.OpenProcess.argtypes = (ctypes.c_uint32, ctypes.c_bool, ctypes.c_uint32)
    kernel.OpenProcess.restype = ctypes.c_void_p
    kernel.WaitForSingleObject.argtypes = (ctypes.c_void_p, ctypes.c_uint32)
    kernel.WaitForSingleObject.restype = ctypes.c_uint32
    kernel.CloseHandle.argtypes = (ctypes.c_void_p,)
    handle = kernel.OpenProcess(0x00100000, False, 27564)
    if not handle:
        raise RuntimeError('original diagnostic process handle unavailable; review final state')
    try:
        while True:
            result = kernel.WaitForSingleObject(handle, 20000)
            if result == 0:
                break
            if result != 258:
                raise RuntimeError('diagnostic process wait failed')
            if time.time() >= grant['expires_at_unix']:
                raise RuntimeError('S confirmation ended while prior diagnostics were running')
    finally:
        kernel.CloseHandle(handle)
    previous = json.loads((folder/'unattended-s-diagnostics-01.json').read_text())
    if previous['status'] != 'finished-available-diagnostics':
        raise RuntimeError('prior diagnostics did not finish with attempted cleanup proven')
    records = json.loads((folder/'uart-line-builds.json').read_text())
    if len(records) != 1:
        raise RuntimeError('one exact UART line build registration required')
    build, record = next(iter(records.items()))
    source = record['source']
    passed = []
    for mode in ('parity', 'break'):
        for case, instance in ((2, 20), (3, 21), (4, 22), (5, 30)):
            for role in (1, 2):
                name = f'line{instance}-r{role}-{mode}'
                options = ['--cases', str(case), '--fault-role', str(role), '--uart-line-mode', mode]
                if execute(name+'-preflight-sauto-01', source, 'run_t13_uart_line.py', build,
                           ['--phase', 'uart-line-preflight', *options], 120):
                    passed.append((name, options))
    for name, options in passed:
        execute(name+'-100-sauto-01', source, 'run_t13_uart_line.py', build,
                ['--phase', 'uart-line-fault', *options], 900)
    report.pop('active', None)
    report['status'] = 'finished-available-uart-line-tests'
    save()
except BaseException as error:
    report.update(status='stopped-requires-review', error=f'{type(error).__name__}: {error}')
    save()
    raise
