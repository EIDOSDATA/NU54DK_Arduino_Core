"""! @brief UART 오류 image를 기존 exact UID·확인서·CI·배타 gate 뒤 실행합니다. """
from pathlib import Path
helper = Path(__file__).with_name('launch_t13_recovery.py')
source = helper.read_text(encoding='utf-8').replace("Path('C:/tr13dev')", "Path('C:/tsline04')")
source = source.replace("'recovery-builds.json'", "'uart-line-builds.json'")
source = source.replace("'pwm-recovery-preflight', 'pwm-recovery'), required=True)",
    "'pwm-recovery-preflight', 'pwm-recovery', 'uart-line-preflight', 'uart-line-fault'), required=True)")
source = source.replace("parser.add_argument('--fault-mode'",
    "parser.add_argument('--uart-line-mode', choices=('parity', 'break'))\nparser.add_argument('--fault-mode'")
source = source.replace("for option in ('fault_mode',", "for option in ('uart_line_mode', 'fault_mode',")
assert "'uart-line-fault'" in source and "('uart_line_mode'," in source
exec(compile(source, str(helper), 'exec'))
