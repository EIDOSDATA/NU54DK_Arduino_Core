"""! @brief UART 오류 예행/실행의 순서와 개별 원본을 보존합니다. """
from pathlib import Path
helper = Path(__file__).with_name('run_t13_recovery.py')
source = helper.read_text(encoding='utf-8').replace('launch_t13_recovery.py', 'launch_t13_uart_line.py')
exec(compile(source, str(helper), 'exec'))
