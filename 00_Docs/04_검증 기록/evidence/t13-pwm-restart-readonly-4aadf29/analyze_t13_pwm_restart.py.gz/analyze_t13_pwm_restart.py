"""! @brief 최초 PWM 재시작 실패의 이전 CC와 실제 첫 두 캡처를 원본에서 독립 대조합니다. """
import json
from check_pc import WORK

folder = WORK / 't13-s-20260908'
name = 'pwm-unstarted-4aadf29-pwm-recovery-1'
result = json.loads((folder / name / 'result.json').read_text())
rows = {row['id']: row for row in result['results']}
prefix = 'T13-S/pwm-recovery/pwm20/mode2/repeat006'
prior = rows[prefix + '/unstarted/end']['pins1'][13]
failure = prefix + '/restart/T13-S/preflight/pwm20/failure/role1/'
trace = rows[failure + 'pwm-trace1']['words']
engine = rows[failure + 'engine']['words']
stream = rows[failure + 'stream1']['words']
assert prior == trace[1] == 1743637 and trace[6] == 502
assert engine[5] == 0 and stream[2:4] == [9, 2]
report = {'source': result['core_revision'], 'campaign': name,
    'completed_repetitions': 5, 'failed_repetition': 6,
    'failure_stage': 'normal restart after successful unstarted cancellation',
    'pre_start_cc0': prior, 'first_two_edges': [trace[:5], trace[5:10]],
    'first_edge_matches_pre_start_cc0': prior == trace[1],
    'unsigned_interval': (trace[6] - trace[1]) & 0xffffffff,
    'engine_lease_expirations': engine[5], 'capture_error_detail': stream[2:4],
    'cause_inference': 'GPIOTE event between pre-enable clear and DPPI enable can retain earlier CC0; physical validation of ordering fix remains required',
    'original_failure_preserved': True, 'tolerance_changed': False}
with (folder / (name + '-analysis-01.json')).open('x', encoding='utf-8') as output:
    json.dump(report, output, indent=2)
print(json.dumps(report, indent=2))
