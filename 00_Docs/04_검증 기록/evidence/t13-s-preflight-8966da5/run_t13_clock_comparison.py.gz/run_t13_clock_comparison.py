"""! @brief 제한 clock 비교의 실행 상태와 표준 출력을 별도 원본에 보존합니다. """
import json
import os
from check_pc import PYTHON, WORK, run
state_path = WORK/'current_common_task_state.json'
name = 'pwm-clock-comparison-8966da5-01'
state = json.loads(state_path.read_text(encoding='utf-8'))
state['active_t13_s'].update(hardware_running=True,
    source='8966da5571464dcb55503eb3d0129f93311d008d', build_root='C:/t3k04',
    phase='bounded-clock-diagnostic', campaign=str(WORK/'t13-s-20260908'/name))
state_path.write_text(json.dumps(state, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
try:
    result = run(name+'-execution', (PYTHON, '-X', 'utf8', '-B', WORK/'run_ncs.py',
        'diagnose_t13_pwm_clock.py', '--build', 'C:/t3k04', '--name', name,
        '--source', '8966da5571464dcb55503eb3d0129f93311d008d'), os.environ.copy())
finally:
    state = json.loads(state_path.read_text(encoding='utf-8'))
    state['active_t13_s'].update(hardware_running=False,
        checkpoint='Clock comparison ended; inspect failures, clock release and pin cleanup before next run')
    state_path.write_text(json.dumps(state, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
raise SystemExit(result)
