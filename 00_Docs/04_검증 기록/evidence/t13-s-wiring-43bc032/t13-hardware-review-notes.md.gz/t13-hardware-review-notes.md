# T13 후속 하드웨어 대조 메모

2026-09-08. 다음 기록104 갱신 때 반영할 읽기 전용 조사이며 새로운 PASS가 아니다.

- `board_package/NU54DK_Zephyr_DTS/NU54-DK Schematic.pdf` 전체 9쪽 중 6·8쪽을 렌더링해 확인했다.
- 8쪽 On-Board IO: GPIO 신호 LED4(P1.14)는 R34 330Ω을 거쳐 U9B NC7WZ17P6X 슈미트 버퍼 입력으로 연결된다. 출력은 DRV_LED4→Q6B EMH60T2R→D15 경로다. GPIO와 보드 간 점퍼 신호가 슈미트 출력 뒤에 직렬 연결된 구조는 아니다. 입력 부하의 영향은 별도로 남는다.
- 6쪽 DAP Level Shifter: P1.04~07의 U7 SN74AVC4T245와 P0.00~03의 U6은 DISABLE_UART로 OE를 제어한다. 사용자가 확인한 DAP UART 분리 상태를 유지한다. OE 비활성을 보드 입력 정전용량까지 없어진 것으로 해석하지 않는다.
- [Nordic I2S transmitting/receiving](https://docs.nordicsemi.com/r/bundle/ps_nrf54l15/page/i2s.html-concept_wvj_ssy_vr): TX는 SCK 하강, RX는 상승 에지이며 시작 시 master 첫 frame zero가 명시된다. 이번 10.776초 뒤 29word zero는 이미 허용·제거한 초기 padding2/6과 구분한다. 이 문서로 이번 원인을 확정하지 않는다.
- [Nordic TWIM pull-up](https://docs.nordicsemi.com/r/bundle/ps_nrf54l15/page/twim.html-concept_twim_timings): pull-up 조건은 bit rate와 bus capacitance에 따라 달라진다. 현재 내부 pull-up만 사용한 C01 241/256byte 실패의 전기적 원인은 아직 측정으로 확정하지 않았다. 목표 속도를 낮추거나 외부 저항을 몰래 추가하지 않는다.
- [Nordic rev1 errata](https://docs.nordicsemi.com/r/bundle/errata_nrf54l15_rev1/)의105번은 clock stretch 중 TWIM disable 조건이다. 이번 정상 C01 data NACK와 같은 현상으로 단정하지 않는다. 적용 여부는 실제 SoC revision과 errata 조건을 대조해야 한다.
- 43bc032을 branch와 main에 각각 push하면서 같은 SHA에 Software check 두 묶음이 생겼다. launcher가 Host check를 단 하나로 가정해 비실기 preflight를 거부했다. 최신 check id의 성공을 요구하도록 임시 launcher를 고쳤다. 거부된 `pwm21-dap-43bc032-diagnostic1`은 flash·외부 출력이 없었고 원본 log를 보존한다.
- 43bc032의 `pwm21-dap-43bc032-diagnostic2`는 04:29:10Z S 결선 검사 net4에서 멈췄다. A P1.05 LOW는 관측됐지만 B P1.04는 HIGH였다. pulse/lease 만료0이고 양쪽 checker STOP·소유권0·입력 반환을 확인했다. PWM PREPARE/START는 실행되지 않았다. 해당 점퍼의 위치·접촉 및 가능하면 교체 후 USB 재연결을 사용자에게 요청했고 응답 대기 중이다.
- 이 net은 S I2S의 A LRCK(P1.05) → B LRCK(P1.04)와 일치한다. 앞서 A 수신의 끝29word zero·B 오류0/송신RAM정상과 관련된 원인 후보지만 아직 인과관계를 입증하지 않았다. 결선 복구 후 새 checker와 I2S 재현이 필요하다. PWM P1.14와 C01 TWI의 다른 net 오류까지 이 한 접촉 문제로 단정하지 않는다.
