# M27 v0.4.0-rc.1 비공개 릴리스 준비

2026-09-08 현재: R00~R13·source별 T11 단독 회귀와 **T12 기능검증은 완료**했다. **QDEC도 일부 문제·제한사항을 101번에 보고하고 검증 작업을 완료**했다. 동작 중 수동 read/clear 누산 누락은 미해결이며 실패 결과를 PASS로 변경하지 않는다. 사용자 완료 결정은 T12 마일스톤에 적용하며 알려진 제한은 T14/T15에서 정리한다. 현재는 사용자 S 재배치·실행 중 유지 확인에 따라 T13 전용 runner와 실기를 준비 중이다. S 단독 29개·동시 7조합 및 복구/전환을 진행하고 종료 후 U 결선을 안내한다. T13 실제 완료는 아직 0회이며 T13 전체·RC·공개는 미완료다. [문서 감사·요구별 증거 대조](<../../00_Docs/04_검증 기록/102_개발_문서_전수_검토와_마일스톤_체크포인트.md>), [실행 TODO](<../../00_Docs/TODO_v0.4.0.md>)를 따른다.

M27 도구는 `v0.4.0-rc.1` package를 두 번 독립 생성해 ZIP·checksum·SBOM·license inventory와
notices가 byte-identical인지 검증하고 RC index와 HOLD plan을 만든다. 기존 M11/M18/M22 도구와
공개 `v0.1.0`~`v0.3.0` package allowlist는 수정하지 않는다.

진행 중인 전체 작업은 [v0.4.0 실행 TODO](../../00_Docs/TODO_v0.4.0.md)를 먼저 읽는다.
아래 명령은 현재 비공개 prepare 도구의 사용법이며 TODO T18~T24의 정식 공개 절차가 이미
구현됐다는 뜻이 아니다.

이 도구에는 tag, push, GitHub Release, stable index 갱신이나 공개 명령이 없다. M24~M26 physical
gate, Boards Manager 전체 수명주기와 프로젝트 소유자 승인이 모두 PASS가 되기 전에는 plan의
`publication_allowed`가 항상 `false`다.

## 계약 확인

```powershell
python tools/release/m27_release.py contract
```

## Exact clean commit에서 후보 산출물 준비

출력 디렉터리는 비어 있어야 하며 저장소 밖의 새 경로를 권장한다.

```powershell
python tools/release/m27_release.py prepare `
  --repository C:\Users\eidos\GitHub\NU54DK_Arduino_Core `
  --output-dir C:\nu54-m27-rc1 `
  --commit HEAD
```

성공해도 결과는 `M27_RELEASE_PREPARE_HOLD=1`이다. 생성되는
`m27-release-plan.json`은 두 package build의 재현성과 남은 blocker를 기록한다.

## 기존 plan 재검증

```powershell
python tools/release/m27_release.py validate-plan `
  --plan C:\nu54-m27-rc1\m27-release-plan.json
```

## 비공개 후보 package 29개 예제 검증

공개 Boards Manager 설치 전에는 생성된 ZIP을 격리 Arduino data 디렉터리에 직접 staging하고,
그 설치본에서 발견한 예제 29개를 전부 compile한다. 이 단계는 기존 Arduino15와 공개 index를
수정하지 않으며 upload도 수행하지 않는다.

```powershell
python tools/release/m27_staged_candidate.py `
  --archive C:\nu54-m27-rc1\artifacts\nucode-nu54dk-zephyr-0.4.0-rc.1.zip `
  --workspace C:\nu54-m27-stage `
  --arduino-cli "C:\Program Files\Arduino CLI\arduino-cli.exe" `
  --ncs-root C:\Users\eidos\ncs\v3.4.0 `
  --toolchain-root C:\Users\eidos\ncs\toolchains\dcbdc366a1 `
  --prerequisite-state-root "$env:LOCALAPPDATA\NUCODE\NU54DK_Arduino_Core\prerequisites" `
  --workers 4
```

성공 표식은 `M27_STAGED_CANDIDATE_PASS=29`이며 workspace 안에 package별 build와
`m27-package-examples.json`, `m27-staged-candidate.json` 증적을 남긴다. 기본 4개 worker는 서로
분리된 build 경로를 사용하고 결과를 lock 순서로 다시 정렬한다.

Physical evidence를 확보한 뒤에는
`variants/nu54dk/v0.4.0-release-readiness.json`의 각 gate를 exact evidence와 함께 갱신하고,
frozen RC commit에서 host·docs·전체 v0.4.0 Zephyr·package·Boards Manager gate를 다시 실행한다.
Stable 공개 절차의 준비·검사는 TODO T18의 별도 변경으로 수행한다. 준비 코드를 만들었다고
공개를 허용하지 않으며, 실제 tag·Release·index 쓰기는 모든 technical gate와 최종 사용자 승인을
확인한 T23에서만 수행한다.
