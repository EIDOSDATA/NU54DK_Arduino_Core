# NU54DK HIL 시험

**최신 사용자 결정 — T13 연속 전환 시험 제외, 실기 중지 유지.**
UART/SPI/TWI personality 및 master/slave 연속 전환(`handover`) 묶음은 v0.4.0 필수 검증에서
제외하고 재실행하지 않는다. serial00/20/21/22/30의 기존 5개 항목은 현재 진행률의 분모·분자에서
모두 제외한다. 기존 2/5 성공·실패 기록은 당시 증거이며 새 PASS나 오류 해결로 변경하지 않는다.
정상 안정성36/36, 고정 serial 취소/NACK21/21, PWM 복구6/6, 자원 충돌 사용자 수용 완료를 유지한다.
I2S/PDM 복구는3/4이며 I2S B의 같은 기능 중단·재시작은 별도 잔여 항목이다.
현재 보드 실기는 사용자 중지 상태다. 자동 대열·이전 실행 명령을 재개하지 않는다.
남은 오류 복구·System OFF·U·T13 전체·RC·공개를 완료 처리하지 않는다.
정확한 제외 범위·마지막 실패·다음 작업은 [109번 최신 결정](<../../../00_Docs/04_검증 기록/109_T13_S_세_복구_묶음_재검증.md>)을 따른다.

아래 시각별 체크포인트와 역할 전환 준비 설명은 이 결정 이전의 이력이다.

현재 S 실행의 종료·미완료 목록은 [108번 최종 기록](<../../../00_Docs/04_검증 기록/108_T13_S_자동_실행_종료와_재개_항목.md>)을 따른다.

T13 S의 정상 안정성·오류 복구·역할 전환은 별도 완료 기준으로 집계한다.
과거 실패 원본을 유지하고 현재 source별 완료 수와 실행 중 항목은 아래104번 및 활성 TODO에서 확인한다.
T12 완료·QDEC 문제 보고 후 종료 결정은 유지한다. 현재 source별 원본·Host/target·진행도는
[104번](<../../../00_Docs/04_검증 기록/104_T13_S_복구_동시_안정성_검증.md>)을 따른다. 아래 이전 source 이력은 당시 결과다.

2026-09-08 후속 정정: TIMER 기능은 95번의 두 보드 7,040회 PASS 범위로 완료 정리했다. 다음은 T13 runner 준비와 C→S→U 재배선 후 복구·동시·안정성 실기다. QDEC는 문제 기록 후 진단 종료이며 알려진 제한을 유지한다. 외부 ADC 반복 수 차이와 승인 전 자동 진행·현장 조작 경계는 [103번](<../../../00_Docs/04_검증 기록/103_TIMER_기능_완료와_T13_진행_경계.md>)을 따른다.

2026-09-08 현재: R00~R13·source별 T11 단독 회귀와 **T12 기능검증은 완료**했다. **QDEC도 일부 문제·제한사항을 101번에 보고하고 검증 작업을 완료**했다. 동작 중 수동 read/clear 누산 누락은 미해결이며 실패 결과를 PASS로 변경하지 않는다. 사용자 완료 결정은 T12 마일스톤에 적용하며 알려진 제한은 T14/T15에서 정리한다. 현재는 사용자 S 재배치·실행 중 유지 확인에 따라 T13 실기와 실패 원인 분석을 진행 중이다. S 정상 안정성은 source별 단독29/29·동시7/7, 합계36/36을 완료했다. 이번 S 자동 실행은 확인 시간 안에서 종료했으며 복구·오류 주입·역할 전환의 잔여 항목과 최종 원본은 활성 TODO와108번 기록을 따른다. 새 S 확인 뒤 남은 복구를 이어가며 U UART00·T13 전체·RC·정식 공개는 미완료다. [문서 감사·요구별 증거 대조](<../../../00_Docs/04_검증 기록/102_개발_문서_전수_검토와_마일스톤_체크포인트.md>), [실행 TODO](<../../../00_Docs/TODO_v0.4.0.md>)를 따른다.

T12 완료 결정과 원본의 구분: 공통 기능 결과는 [COMMON_WIRING](COMMON_WIRING.md)과 [100번](<../../../00_Docs/04_검증 기록/100_T12_공통_기능_묶음과_T13_조합_확정.md>)을 따른다. GPIO/GPIOTE2502·PWM675+288·I2S432 PASS 뒤 QDEC는 누산 누락을 보고하고 검증 작업을 완료했다. [101번](<../../../00_Docs/04_검증 기록/101_T12_QDEC_누산_누락_원인_분리.md>)의 마지막 IRQ 보호 대비도 재현하여 실기 진단을 종료했다. `qdec-*-diagnostic` 관측은 기능240의 PASS가 아니다. [T13 계획](T13_PLAN.md)은 QDEC20/21 단독·C07을 제외하고 C→S→U 두 결선 변경을 명시하며 현재 S 실기를 진행한다.

공통 결선 최신 상태: [Fixture 501 안내](COMMON_WIRING.md)의 exact d8d1e13 재검사에서 P1.10 포함 102 net-round·자동 해제 3개를 통과했고 양쪽 출력을 해제했다. 첫 8c1cfe2 실패는 보존한다. [99번](<../../../00_Docs/04_검증 기록/99_공통_결선_검사와_승인_전_자동_진행_계획.md>)에서 원본·범위와 단독 180초·동시 900초·전체 대표 한 조합 3600초 기준을 관리한다. GPIO API·T12 전체 완료는 아니며 아래 무결선 상태는 이전 94·95번 당시 기록이다.

이전 PC 개발 검증(2026-09-07 당시): [94번](<../../../00_Docs/04_검증 기록/94_T14_PWM_지연_시작_취소와_무점퍼_검증.md>)에서 PWM 미시작 STOP 수정·두 보드 회귀와 전체 software/설치 예제 검증을 완료했다. [95번](<../../../00_Docs/04_검증 기록/95_T12_내부_ADC_TIMER_이벤트_무점퍼_검증.md>)의 내부 ADC·TIMER·이벤트·시간 함수와 PWM 회귀도 두 보드 1,808명령 PASS다. 보드 간 결선은 해제됐으며 T12 전체·T13 이후와 RC/공개는 미완료다. 아래 source별 이력의 당시 상태와 현재 재개 조건을 구별한다.

이 디렉터리는 NU54DK 실물 보드가 필요한 host-side 시험만 관리합니다. 일반 host unit test나
Arduino compile test와 분리하며, 장치가 없는 CI에서 PASS로 추정하지 않습니다.

| 파일 | 역할 | 주요 fixture |
| --- | --- | --- |
| `v04_wiring_run.py` / `v04_wiring.py` | 고정 17신호의 양방향 LOW/해제 102회와 pulse/lease 자동 해제 | Fixture 501, 새 확인서·SWD 10 MHz, GPIO API PASS와 구별 |
| `v04_nojumper.py` | PWM·내부 ADC·TIMER·EGU/DPPI/PPIB·시간 함수의 exact SWD 명령/판정 | 두 지정 보드 USB/SWD, 보드 간 결선 해제, 94·95번 |
| `m6_serial_echo.py` | pyOCD flash 후 UART READY·echo 검증 | NU54DK, CMSIS-DAP V2 UART |
| `m7_i2c_pmic.py` | BQ25186 고정 ID register의 읽기 전용 I2C 검증 | 보드 내장 PMIC |
| `m7_peripheral_hil.py` | SPI loopback·ADC·PWM token 검증 | 명시된 점퍼와 핀 fixture |
| `m8_upload.py` | manifest를 검증한 pyOCD/J-Link upload 반복 시험 | NU54DK debug probe |
| `m8_debug.py` | debug server와 Sketch source breakpoint 검증 | pyOCD 또는 J-Link |
| `m14_pin_hil.py` | 신규 LED output/readback과 버튼 pull·edge 검증 | NU54DK, CMSIS-DAP V2 UART, 사용자 버튼 동작 |
| `m15_auto.py` | identity·uptime·GRTC callback·Settings·WDT 비-System-OFF 자동 검증 | 공식 Ubuntu CI artifact, NU54DK, CMSIS-DAP V2 UART |
| `m15_system_off.py` | SWD 격리 뒤 timed GRTC→사용자 SW0 System OFF 결합 검증 | 공식 Ubuntu CI artifact, NU54DK, CMSIS-DAP V2 UART, debug-control SW1, 사용자 SW0 |
| `ac01_gpio_hil.py` | P2 loopback GPIO·pulse·shift와 SW0 자기구동 level IRQ·callback mask 자동 검증 | NU54DK 한 대, 같은 보드 P2.5↔P2.6 점퍼 한 가닥, CMSIS-DAP V2 UART |
| `ac02b_peripheral.py` | 동적 Serial1·Wire·SPI·PWM·ADC pair HIL과 exact 증적 생성 | NU54DK 두 대, 아래 4개 점퍼, 각 보드 USB/DAPLink UART |
| `m19_ble_gap.py` | GAP UUID/manufacturer filter·연결·재연결 자동 검증 | NU54DK 두 대, 각 보드 USB/DAPLink UART, 추가 배선 없음 |
| `m20_ble_gatt.py` | 범용 GATT read/write/notify/indicate·재발견 자동 검증 | NU54DK 두 대, 각 보드 USB/DAPLink UART, 추가 배선 없음 |
| `m21_ble_security.py` | pairing·bond 복원/삭제/repair와 BAS/DIS/HID protocol 자동 검증 | NU54DK 두 대, 각 보드 USB/DAPLink UART, 추가 배선 없음 |
| `ble_pair_hil_common.py` | M19~M21 exact image·두 UID·UART·evidence 공통 경계 | 직접 실행하지 않음 |
| `test_m7_*.py` | 실제 장치 없이 HIL protocol/parser를 검증 | 없음 |
| `test_m14_pin_hil.py` | M14 수동 동작 protocol·증적의 fail-closed 경계를 검증 | 없음 |
| `test_m15_auto.py` | M15 자동 protocol과 Linux producer/Windows consumer provenance를 검증 | 없음 |
| `test_m15_system_off.py` | M15 timed·button ARM, 무응답 시간과 결합 wake protocol·증적 경계를 검증 | 없음 |
| `test_ac01_gpio_hil.py` | AC-01 exact token 순서·범위·fixture·실패 경계를 검증 | 없음 |
| `test_ac02b_peripheral.py` | AC-02B nonce·순서·ADC 범위와 WIRING_REQUIRED gate를 검증 | 없음 |
| `../../host/test_m19_ble_gap_hil.py` | M19 pair protocol의 stale/reorder/FAIL 거부 경계를 검증 | 없음 |
| `../../host/test_m20_ble_gatt_hil.py` | M20 pair protocol의 stale/누락/reorder/FAIL 거부 경계를 검증 | 없음 |
| `../../host/test_m21_ble_security_hil.py` | M21 persistence·old-key·RF nonce binding·profile parser 경계를 검증 | 없음 |

## 실행 원칙

### T12 PWM peer capture 첫 경로 준비

`v04_signal_run.py --fixture 408 --pwm-capture --swd-frequency-hz 10000000`는
기존 408 결선 **B GPIO P1.14 → A GPIO P1.14, GND ↔ GND**를 사용하는 별도 측정 모드다.
현재 준비 범위는 PWM20/21/22 × slot 0~3 × TOP 1000/4000 × duty 0/25/50/75/100% ×
DMA word bit15 극성 두 가지의 240 vector다. Individual load·4 values·CPU start·loop로 실행한다.
이 준비는 물리 PASS가 아니며 common/grouped/wave-form, 길이 32/256, sequence0/1 순서·유한
end/repeat, DPPI START, triggered-step과 pin idle inversion은 후속 범위다.

A는 GPIOTE20 channel 0 → DPPI20 channel 0 → TIMER22 CC0(1 MHz)로 에지 시각을 캡처한다.
CPU polling은 이벤트/CC/level을 수집하며 timestamp를 생성하지 않는다. 각 비정적 case의
201개 에지로 100주기와 각각의 HIGH 비율을 독립 판정한다. 주기는 목표의 ±5%, duty는 목표
비율의 상대 ±5%다. 0/100%는 에지 없음과 100주기 길이의 정적 level을 확인한다. 누락·중복·
역순·극성·개별 오차·guard 실패를 평균으로 숨기지 않는다. 실제 clock 교정·jitter 보증은 아니다.

첫 측정의 안전 경계는 기존 exact source/board/image·현재 UID·배타 probe lock·sector flash·
`auto_unlock=false`·controlled start와 30분 이내 결선 확인을 그대로 사용한다. 새 모드는
SWD 10 MHz와 유한 campaign만 허용한다. 기본 CLI는 preflight-only이며 `--execute-fixture`와
현재 confirmation 없이는 probe를 열지 않는다. 원본 status/에지를 판정 전에 journal에 남기고,
중간 측정 실패도 partial raw를 보존한다. 종료는 B 출력 STOP→A capture 자원 반환 순서다.

새 PC에서는 USB/probe를 다시 열거해 A/B 역할을 확인한 뒤 두 USB 분리→위 GPIO 결선→재연결을
안내한다. 두 DAP UART 분리·SWD 연결, 동일 I/O 전압·공통 GND·전원 레일 비연결과 현재 결선
완료를 사용자에게 확인받는다. 이전 COM/결선 확인·이 문단 자체를 실행 승인으로 재사용하지 않는다.
Mailbox 40/41/42/43/44/45/46은 각각 arm/prepare/start/capture/raw/stop/status다. capture의
transport 성공과 물리 측정 성공은 별도이며 status/error와 Host oracle 모두 통과해야 한다.

`--cmsis-dap-limit-packets`는 flash와 이후 SWD session의 USB 동시 명령을 1개로 제한하는
명시적 진단 옵션이다. 기본은 기존 설정이며 SWD 주파수·sector erase·exact UID·controlled
start·`auto_unlock=false`·확인/lock 계약은 유지한다. [pyOCD 공식 옵션](https://pyocd.io/docs/options.html)의
`cmsis_dap.limit_packets`를 사용하고 SDK/driver를 수정하지 않는다. 읽기 성공만으로 flash
timeout 원인을 확정하지 않으며 옵션·최초 실패·후속 결과를 evidence에 각각 기록한다.

### T12 PWM load·DMA 길이 확장 준비

`--pwm-capture --pwm-load common|grouped|individual|wave-form`은 선택한 load 한 개에서
4/32/256 values를 각각 검사한다. Common/grouped/individual은 각 720조건이고 WaveForm은
slot 0~2의 540조건이다. WaveForm의 네 번째 word는 출력 slot 3이 아닌 RAM TOP이다.
이 모드에서는 register TOP을 반대 값(1000↔4000)으로 두어 RAM TOP 사용을 실제 period로
구별한다. 나머지 load에서는 선택한 decoder lane과 다른 lane의 duty를 다르게 넣어 매핑을 검사한다.

기존 `--pwm-capture`만 지정하면 240조건 첫 경로를 유지한다. 그 실기는 [97번](<../../../00_Docs/04_검증 기록/97_T12_PWM_peer_capture_첫_240조건_검증.md>)에
고정되어 있으며 새로운 load/길이 시험의 PASS로 재사용하지 않는다. Opcode 41은 기존 5개 인자
또는 load ID(0/1/2/3)·value count를 덧붙인 7개 인자만 받는다. 그 밖의 길이·WaveForm slot 3은 거부한다.

Common/256/4000의 한 sequence는 약 1.024초로 100주기 capture보다 길다. Host는 capture 뒤
첫 sequence 완료를 최대 2초 기다리고, 완료되지 않으면 원본을 보존한 뒤 실패로 처리한다.
두 보드의 10초 lease·B 우선 STOP·exact image/UID·10 MHz·현재 결선 확인을 유지한다.
이 확장은 **constant-duty CPU-start loop**이며 sequence0/1의 시간상 순서·유한 end/repeat,
DPPI START·triggered-step·idle inversion의 완료 근거가 아니다. 다음 실행 전 현재 408 결선의
확인을 다시 받아야 하며 이전 30분 확인을 자동 연장하지 않는다.

- 보드 target과 build manifest가 기대값과 일치해야 합니다.
- 일반 upload 경로에서는 mass erase나 recover를 사용하지 않습니다.
- PMIC 시험은 허용한 address/register의 읽기만 수행합니다.
- probe UID, COM port와 물리 fixture는 실행 인자로 명시하거나 안전한 자동 탐색 결과가 하나일
  때만 사용합니다.
- 실기 PASS는 해당 commit, artifact hash와 fixture 조건을 검증 기록에 연결합니다.
- M15 운영 절차에서는 고정된 NCS Ubuntu container를 사용하는 clean GitHub Actions build
  artifact만 사용합니다. 로컬 Windows build를 M15 검증 증적으로 대체하지 않습니다.

## M15 공식 CI artifact 계약

`m15_auto.py`와 `m15_system_off.py`의 운영 입력은
`.github/workflows/m12-reproducible-build.yml`이 exact commit에서 생성한
`m12-zephyr-build-<40자리 commit>` artifact입니다. artifact를 다운로드한 Windows checkout도
같은 commit이어야 하며 Core, M15 application, board package와 runner가 사용하는
`m14_pin_hil.py`, `m6_serial_echo.py`가 모두 clean이어야 합니다. Runner는 revision·source
digest와 HEX 실행 전후 불변성을 fail-closed로 검사하지만 GitHub run의 서명이나 attestation
자체를 확인하지는 않으므로 run ID와 artifact 이름은 검증 기록에 별도로 남깁니다.

Ubuntu producer는 checkout의 LF byte로 build record SHA-256을 만듭니다. Windows의 clean Git
checkout은 같은 commit이어도 CRLF byte를 가질 수 있으므로 M15 consumer만 Git `HEAD` blob의
canonical byte로 같은 digest를 재계산합니다. 이 처리는 dirty source를 허용하는 우회가 아닙니다.
runner는 먼저 관련 source와 board submodule의 clean 상태, exact Core·board revision, 고정
NCS/Zephyr revision과 target을 검증한 뒤 세 source digest가 모두 일치할 때만 flash합니다.
M14 로컬 build/HIL은 기존대로 실제 working-tree byte를 검증합니다.

비버튼 자동 HIL image는 artifact 안의 다음 경로를 사용합니다.

```powershell
Set-Location "<NU54DK_Arduino_Core 저장소 경로>"
$CoreRoot = (Get-Location).Path
$ArtifactRoot = "<다운로드해 압축을 푼 m12-zephyr-build artifact>"
$Python = "C:\ncs\toolchains\dcbdc366a1\opt\bin\python.exe"
$Commit = git -C $CoreRoot rev-parse HEAD
$AutoHex = Join-Path $ArtifactRoot `
  "twister\nrf54l15dk_nrf54l15_cpuapp_nu54dk\zephyr_gnu\nucode.m15.auto_hil\m15_hil\zephyr\zephyr.hex"

& $Python -I "$CoreRoot\tests\hil\nu54dk\m15_auto.py" `
  --hex $AutoHex `
  --board-id "<시험할 CMSIS-DAP UID>" `
  --expected-core-revision $Commit `
  --evidence "$CoreRoot\build\m15\hil\m15-auto.evidence.json"
```

이 자동 HIL은 System OFF에 진입하지 않습니다. Identity와 uptime, GRTC one-shot callback,
Settings의 reset 전후 유지, WDT feed·stop·expiry 경계까지만 검증합니다. 자동 transcript나
evidence를 timed GRTC wake 또는 사용자 버튼 wake PASS로 확대하지 않습니다.

## M14 신규 핀 HIL

`PIN_LED2`, `PIN_LED3`은 LOW/HIGH를 실제 GPIO에 기록한 뒤 raw readback이 같은지 자동
확인합니다. `PIN_BUTTON1`, `PIN_BUTTON2`, `PIN_BUTTON3`은 `INPUT_PULLUP`에서 뗀 상태
HIGH와 누른 상태 LOW를 확인하고 FALLING, RISING, CHANGE ISR을 순서대로 검증합니다.

화면의 Arduino 논리명과 보드의 사용자 버튼 표기는 다음과 같이 대응합니다. 회로도 내부의
부품 참조번호가 아니라 보드의 `SW0..3` 사용자 표기를 기준으로 조작합니다.

| Arduino 논리명 | DTS alias | 사용자 버튼 | nRF54L15 GPIO |
| --- | --- | --- | --- |
| `PIN_BUTTON0` | `sw0` | SW0 | P1.13 — M6에서 검증했으므로 M14 대상 제외 |
| `PIN_BUTTON1` | `sw1` | SW1 | P1.09 |
| `PIN_BUTTON2` | `sw2` | SW2 | P1.08 |
| `PIN_BUTTON3` | `sw3` | SW3 | P0.04 |

`PIN_LED1`은 `PIN_PWM0`과 동일한 물리 자원을 PWM이 소유하므로 이 digital HIL에서는
제외합니다. 해당 자원의 회귀 근거는 M7 `PIN_PWM0` 0/128/255 driver 시험입니다. 또한
`PIN_LED2`를 시험하는 동안에는 외부 debug session을 종료해 SWO와의 동시 소유를 피합니다.

보드 연결 전에는 **NCS v3.4.0 Toolchain terminal**에서 다음 production target
build-only를 실행합니다. 일반 PowerShell이라면 먼저 nRF Connect extension의 `Open terminal`로
고정 Toolchain 환경을 적용해야 합니다.

```powershell
Set-Location "<NU54DK_Arduino_Core 저장소 경로>"
$CoreRoot = (Get-Location).Path
$NcsRoot = "C:\ncs\v3.4.0"
$BoardRoot = "$CoreRoot\board_package\NU54DK_Zephyr_DTS"
$Python = "C:\ncs\toolchains\dcbdc366a1\opt\bin\python.exe"
$Build = "$env:TEMP\nu54dk-m14-pin-hil"

Push-Location $NcsRoot
& $Python -I -m west build -p always `
  -b "nrf54l15dk/nrf54l15/cpuapp/nu54dk" `
  -d $Build `
  "$CoreRoot\tests\zephyr\m14_pin_hil" `
  -- "-DBOARD_ROOT=$BoardRoot" "-DEXTRA_ZEPHYR_MODULES=$CoreRoot"
Pop-Location
```

실기는 CMSIS-DAP V2 target UART를 사용하는 다른 프로그램과 debug session을 모두 닫고
실행합니다. `--acknowledge-manual-actions`는 세 버튼을 화면 안내대로 직접 누르고 뗄 준비가
되었다는 명시적 승인입니다. 각 ACTION은 30초, 전체 transcript는 기본 520초 제한을 가지며,
기존 증적은 `--overwrite-evidence` 없이는 덮어쓰지 않습니다. Core HIL 관련 source와 보드
submodule이 clean하지 않거나, 현재 보드 checkout이 부모 commit의 gitlink와 다르거나, HEX 옆
build record가 기대 Core·보드 commit, NCS/Zephyr revision, NU54DK target과 다르면 flash 전에
실패합니다. build record의 Core 범위·M14 application·board tree SHA-256도 현재 source에서
CMake와 같은 방식으로 다시 계산하여 세 값이 모두 정확히 같아야 합니다.

```powershell
$Commit = git -C $CoreRoot rev-parse HEAD
& $Python -I "$CoreRoot\tests\hil\nu54dk\m14_pin_hil.py" `
  --hex "$Build\m14_pin_hil\zephyr\zephyr.hex" `
  --expected-core-revision $Commit `
  --acknowledge-manual-actions `
  --evidence "$CoreRoot\build\m14\hil\m14-pin-hil.evidence.json"
```

화면에 `ACTION`이 출력될 때 지정된 버튼 하나만 누르거나 뗍니다. 모든 핀과 edge가
통과해야 `status: passed` JSON과 SHA-256으로 결합된 companion transcript가 생성됩니다.
timeout, target FAIL, 핀 ID·순서 불일치 또는 중복 token은 PASS 증적을 만들지 않습니다.

## AC-01 P2.5↔P2.6 GPIO loopback HIL

같은 NU54DK의 `PIN_GPIO0/P2.5`와 `PIN_GPIO1/P2.6`을 점퍼 한 가닥으로 연결합니다. 두 번째
보드와 외부 pull-up은 사용하지 않습니다. `OUTPUT_OPENDRAIN` release는 P2.6의
`INPUT_PULLUP`으로 확인합니다. P2에는 CPUAPP GPIOTE가 없으므로 두 connector pin은 interrupt를
지원하지 않습니다. Level IRQ와 callback mask는 SW0 P1.13을 input-connected open-drain으로
자기구동해 실제 GPIOTE20 event를 만들며, 시험 중 SW0를 누르면 안 됩니다. Runner는 다음 항목을
사용자 동작 없이 한 번에 검사합니다.

- open-drain LOW와 high-Z release
- level LOW/HIGH의 hold one-shot과 deassert 뒤 재무장
- `pulseIn()`, `pulseInLong()` 폭 범위와 timeout `0`
- `shiftOut()` 최종 bit와 `shiftIn()` 고정 LOW/HIGH byte
- 중첩 `noInterrupts()` 중 callback 억제, Zephyr heartbeat 진행, held level의 마지막 복원

두 보드가 연결된 환경에서 잘못된 target을 기록하지 않도록 `--board-id`를 필수로 받습니다.
Runner는 Core 관련 source, AC-01 application과 board submodule이 commit된 clean 상태인지 확인하고,
HEX 옆 build record의 Core·board revision, NCS/Zephyr revision과 세 source SHA-256이 현재 checkout과
exact 일치할 때만 flash합니다.

```powershell
Set-Location "<NU54DK_Arduino_Core 저장소 경로>"
$CoreRoot = (Get-Location).Path
$NcsRoot = "C:\ncs\v3.4.0"
$BoardRoot = "$CoreRoot\board_package\NU54DK_Zephyr_DTS"
$Python = "C:\ncs\toolchains\dcbdc366a1\opt\bin\python.exe"
$Build = "$env:TEMP\nu54dk-ac01-gpio-hil"

Push-Location $NcsRoot
& $Python -I -m west build -p always `
  -b "nrf54l15dk/nrf54l15/cpuapp/nu54dk" `
  -d $Build `
  "$CoreRoot\tests\zephyr\ac01_hil" `
  -- "-DBOARD_ROOT=$BoardRoot" "-DZEPHYR_EXTRA_MODULES=$CoreRoot"
Pop-Location

$Commit = git -C $CoreRoot rev-parse HEAD
& $Python -I "$CoreRoot\tests\hil\nu54dk\ac01_gpio_hil.py" `
  --hex "$Build\ac01_hil\zephyr\zephyr.hex" `
  --board-id "<시험할 CMSIS-DAP UID>" `
  --expected-core-revision $Commit `
  --acknowledge-loopback `
  --evidence "$CoreRoot\build\ac01\hil\ac01-gpio.evidence.json"
```

기존 evidence와 transcript는 `--overwrite-evidence` 없이는 덮어쓰지 않습니다. 이 HIL은
외부 저항, 두 보드 간 통신, logic analyzer나 오실로스코프 정확도 측정을 요구하지 않습니다.

## AC-02B 동적 주변장치 pair HIL

AC-02B는 Board A를 Arduino Core DUT, Board B를 direct Zephyr peer로 사용합니다. DUT는 공개
production API인 `Serial1.setPins()`, `Wire.setPins()`, `SPI.setPins()`,
`analogWriteFrequency()`, `analogWrite()`와 `analogRead()`를 직접 호출합니다. P1.12/A0는
먼저 ADC 입력으로 읽은 뒤 같은 run에서 transferable PWM20 출력으로 넘깁니다. Wire는 Board A의
온보드 BQ25186 `MASK_ID`를 읽기 전용으로 검증하고 peer의 I2C controller와 target은 모두
비활성화합니다. 따라서 현재 미지원인 Wire target/Wire1을 PASS로 확대하지 않습니다.

두 보드의 전원을 끈 상태에서 다음 점퍼를 모두 연결합니다. Board A의 SPI loopback 한 가닥을
제외한 나머지는 두 보드 사이 연결입니다.

| 번호 | Board A(DUT) | 방향 | Board B(peer) | 검증 |
| --- | --- | --- | --- | --- |
| 1 | GND | ↔ | GND | 공통 기준 전압 |
| 2 | P1.12 / A0 | ↔ | P2.5 / GPIO | peer ADC LOW·HIGH drive 후 DUT 1 kHz 25%·75% PWM capture |
| 3 | P2.2 / SPI00 MOSI | ↔ 같은 Board A의 P2.4 / SPI00 MISO | 해당 없음 | 4 MHz 40-byte local loopback |

Serial1은 Board A CMSIS-DAP의 x.1 보조 VCOM을 host가 exact echo하므로 보드 간 P0 배선이
필요하지 않습니다. Wire는 Board A 내부 P1.2/P1.3 bus의 BQ25186 주소 `0x6A`, register
`0x0C`를 100/400 kHz에서 no-STOP pointer write와 repeated-start 1-byte read로 읽고, 각
round에서 exact `0x41`을 요구합니다. PMIC data register는 쓰지 않습니다. 보드 간 I2C
배선과 외부 pull-up도 필요하지 않습니다. 첫 I2C transaction으로 BQ25186 기본 watchdog이
시작될 수 있습니다. peer P2.5는 ADC 단계에서는 push-pull output이며, 마지막 ADC LOW 응답
후 high-Z input으로 전환됩니다. P2에는 CPUAPP GPIOTE가 없으므로 PWM edge는 bounded polling으로
측정합니다. DUT는 그 응답 뒤 P1.12의 ADC ownership을 PWM20으로 넘기므로 두 보드가 동시에
선을 구동하지 않습니다.

배선 전에는 두 role image와 host parser까지만 준비합니다. NCS v3.4.0 Toolchain terminal에서
다음 두 production target을 각각 pristine build합니다.

```powershell
Set-Location "<NU54DK_Arduino_Core 저장소 경로>"
$CoreRoot = (Get-Location).Path
$NcsRoot = "C:\ncs\v3.4.0"
$BoardRoot = "$CoreRoot\board_package\NU54DK_Zephyr_DTS"
$Python = "C:\ncs\toolchains\dcbdc366a1\opt\bin\python.exe"
$DutBuild = "$env:TEMP\nu54dk-ac02b-hil-dut"
$PeerBuild = "$env:TEMP\nu54dk-ac02b-hil-peer"

Push-Location $NcsRoot
& $Python -I -m west build -p always `
  -b "nrf54l15dk/nrf54l15/cpuapp/nu54dk" `
  -d $DutBuild `
  "$CoreRoot\tests\zephyr\ac02b_hil_dut" `
  -- "-DBOARD_ROOT=$BoardRoot" "-DZEPHYR_EXTRA_MODULES=$CoreRoot"
& $Python -I -m west build -p always `
  -b "nrf54l15dk/nrf54l15/cpuapp/nu54dk" `
  -d $PeerBuild `
  "$CoreRoot\tests\zephyr\ac02b_hil_peer" `
  -- "-DBOARD_ROOT=$BoardRoot" "-DZEPHYR_EXTRA_MODULES=$CoreRoot"
Pop-Location

& $Python -I "$CoreRoot\tests\hil\nu54dk\test_ac02b_peripheral.py" -v
```

Runner에는 서로 다른 두 CMSIS-DAP UID가 필수입니다. 각 UID에서 DAPLink MSD와 COM을 함께
찾아 서로 다른 UID·MSD·COM인지 확인하고, role별 build record, Core·board revision, source
digest와 HEX SHA-256을 flash 전후에 exact 검증합니다. 아래 첫 실행처럼
`--acknowledge-wiring`을 생략하면 image와 장치 preflight 뒤 `WIRING_REQUIRED`와 종료 코드 3을
반환하며 **flash, start command, PASS evidence를 수행하지 않습니다**.

```powershell
$Commit = git -C $CoreRoot rev-parse HEAD
$DutHex = "$DutBuild\ac02b_hil_dut\zephyr\zephyr.hex"
$PeerHex = "$PeerBuild\ac02b_hil_peer\zephyr\zephyr.hex"

& $Python -I "$CoreRoot\tests\hil\nu54dk\ac02b_peripheral.py" `
  --dut-hex $DutHex --peer-hex $PeerHex `
  --dut-board-id "<Board A CMSIS-DAP UID>" `
  --peer-board-id "<Board B CMSIS-DAP UID>" `
  --expected-core-revision $Commit
```

점퍼 3개와 두 보드 USB를 확인한 마지막 단계에서만 다음 실제 실행을 허용합니다.

```powershell
& $Python -I "$CoreRoot\tests\hil\nu54dk\ac02b_peripheral.py" `
  --dut-hex $DutHex --peer-hex $PeerHex `
  --dut-board-id "<Board A CMSIS-DAP UID>" `
  --peer-board-id "<Board B CMSIS-DAP UID>" `
  --expected-core-revision $Commit `
  --acknowledge-wiring `
  --evidence "$CoreRoot\build\ac02b\hil\ac02b-peripheral.evidence.json"
```

host는 같은 128-bit nonce를 먼저 peer에 주입해 ADC/PWM fixture를 arm한 뒤 DUT를 시작합니다.
Serial1 end/rebegin 두 cycle, BQ25186 Wire 100/400 kHz repeated-start 두 cycle, SPI
interrupt mask와 4 MHz loopback, ADC 외부 LOW/HIGH 뒤 동일 선의 PWM 외부 polling 측정이 양쪽 exact token
순서로 모두 끝나야만 `status: passed` evidence를 만듭니다. timeout, stale nonce, role image
오배치, 한쪽 FAIL, token 누락·재배치 또는 ADC 범위 불일치는 PASS로 축소하지 않습니다.

## M19/M20/M21 두 보드 BLE HIL

M19~M21은 RF로 통신하므로 P2.5↔P2.6 점퍼와 외부 저항을 사용하지 않습니다. 보드 두 대를
각각 USB에 연결해 전원, DAPLink flash와 UART를 확보합니다. Runner는 peripheral/central
DAPLink UID를 필수로 받아 UID·MSD·UART가 모두 다른지 확인하고, clean exact commit과 두 role
build record·HEX SHA-256을 검증한 뒤에만 flash합니다.

- M19: advertise, UUID/manufacturer filter, connect/disconnect/readvertise/reconnect
- M20: discovery, cached read, 두 write mode, notify/indicate, handle invalidation,
  reconnect 뒤 rediscovery/resubscribe
- M21: pairing, reboot 뒤 bond 복원, 삭제 뒤 old-key 재연결 거부와 repair,
  encrypted BAS/DIS/HID protocol

각 runner는 같은 nonce가 결합된 양쪽 FINAL token을 모두 확인해야 JSON PASS를 생성합니다.
M21은 128-bit nonce 전체를 Peripheral manufacturer data로 광고하고 Central이 이를 exact-match한
뒤에만 연결하므로 이름이 같은 stale 장치를 peer로 오인하지 않습니다.
한쪽 timeout/FAIL, stale nonce, token 누락·재배치, 같은 role HEX 또는 callback 문맥 오류는 PASS로
축소하지 않습니다. Build와 실행 명령, role image 경로는
[M19 검증 기록](<../../../00_Docs/04_검증 기록/23_M19_BLE_Core_GAP_검증.md>)과
[M20 검증 기록](<../../../00_Docs/04_검증 기록/24_M20_범용_GATT_검증.md>),
[M21 검증 기록](<../../../00_Docs/04_검증 기록/25_M21_BLE_보안과_표준_Profile_검증.md>)을 따릅니다.

## M15 System OFF 결합 HIL

System OFF는 자동 HIL과 분리한 단일 수동 session에서 두 단계로 검증합니다.

1. GRTC timed wake 뒤 `RESET_CLOCK` 확인
2. 다시 System OFF에 진입한 뒤 사용자 SW0/P1.13 wake와 `LOW_POWER_WAKE` 확인

두 단계는 같은 공식 CI artifact의 build record와 image를 사용합니다. 로컬에서 image를 다시
빌드하지 않습니다. Image는 부팅만으로 System OFF에 진입하지 않으며 runner가 UART 상태와
명시적 준비 token을 확인한 뒤에만 각 단계를 arm합니다.

### Debug-control SW1 설정

NU54DK에는 `DISABLE_SWD`와 `DISABLE_UART`를 함께 가진 온보드 debug-control 2연 `SW1`이
있습니다. 이 부품은 Arduino 사용자 버튼 `SW1`/P1.09와 **다른 물리 부품**입니다.

1. Image 기록과 UART 준비까지 debug-control `SW1`을 기존 상태로 둡니다.
2. Runner의 격리 안내가 나오면 `DISABLE_SWD` 쪽만 격리 위치로 전환합니다.
3. `DISABLE_UART` 쪽은 전환하지 않아 온보드 UART 연결을 유지합니다.
4. Timed 단계와 button 단계를 모두 마친 뒤 필요한 경우 `DISABLE_SWD`를 원래 위치로
   복원합니다.

Active SWD 상태에서 나타나는 `RESET_DEBUG`는 GRTC나 GPIO wake가 아닙니다. 이 원인의 즉시
wake는 결합 HIL PASS 또는 API FAIL로 판정하지 않으며, SWD가 격리되지 않은 실행은 완료 증거로
사용하지 않습니다.

```powershell
Set-Location "<NU54DK_Arduino_Core 저장소 경로>"
$CoreRoot = (Get-Location).Path
$ArtifactRoot = "<다운로드해 압축을 푼 m12-zephyr-build artifact>"
$WakeHex = Join-Path $ArtifactRoot `
  "twister\nrf54l15dk_nrf54l15_cpuapp_nu54dk\zephyr_gnu\nucode.m15.wake\m15_wake\zephyr\zephyr.hex"
```

실제 결합 시험은 M15 변경을 commit한 exact source에서 다음과 같이 실행합니다. 여러 보드가
연결될 수 있으므로 `--board-id`는 필수이며 기본 probe UID로 대체하지 않습니다. 기존 증적은
`--overwrite-evidence` 없이는 덮어쓰지 않습니다.

```powershell
$Commit = git -C $CoreRoot rev-parse HEAD
& $Python -I "$CoreRoot\tests\hil\nu54dk\m15_system_off.py" `
  --hex $WakeHex `
  --board-id "<시험할 CMSIS-DAP UID>" `
  --expected-core-revision $Commit `
  --acknowledge-interface-switch `
  --acknowledge-button-wake `
  --evidence "$CoreRoot\build\m15\hil\m15-system-off.evidence.json"
```

Runner는 먼저 timed GRTC 단계의 System OFF 무응답 구간과 `RESET_CLOCK`을 확인해야 합니다.
`TIMED READY` 안내에서 SWD만 격리한 뒤 `DISABLE_SWD_ONLY`를 입력하고, button 준비 안내에서는
사용자 SW0가 눌리지 않았음을 확인한 뒤 `SW0_RELEASED`를 입력합니다.
그 뒤에만 button 단계를 arm하고 `M15 PRESS NOW`를 출력합니다. 이 안내 전에 사용자
SW0/P1.13을 누른 결과, 다른 GPIO 또는 `LOW_POWER_WAKE`가 아닌 reset 원인, 누락·중복 token은
PASS로 인정하지 않습니다.

Core `c47239d954c45fd173d8d1393e3ea5c9c86e111a`의 공식 CI artifact로 한 SWD-only 격리
세션을 실행했습니다. Timed GRTC wake는 `2062 ms`와 exact cause `2048`, 사용자 SW0/P1.13
wake는 `20406 ms`와 exact cause `128`로 PASS했습니다. Exact image·revision·transcript
SHA-256은 [M15 기준선](<../../../00_Docs/04_검증 기록/17_M15_NU54DK_Board_System_기준선.md>)에
기록하며 M15 System OFF 항목은 완료 상태입니다.

구체적인 실행 명령과 이미 검증한 결과는
[M6 기준선](<../../../00_Docs/04_검증 기록/06_M6_기본_Arduino_API_Serial과_인터럽트_기준선.md>),
[M7 기준선](<../../../00_Docs/04_검증 기록/07_M7_Wire_SPI_ADC_PWM_기준선.md>) 및
[M8 기준선](<../../../00_Docs/04_검증 기록/08_M8_업로드와_디버그_기준선.md>),
[M14 기준선](<../../../00_Docs/04_검증 기록/16_M14_Core_API와_Variant_기준선.md>) 및
[M15 기준선](<../../../00_Docs/04_검증 기록/17_M15_NU54DK_Board_System_기준선.md>)을 따릅니다.

## v0.4.0 M24~M26 무배선 온보드 gate

이 묶음은 외부 점퍼 없이 연결된 NU54DK 한 대와 DAP VCOM 두 포트를 사용합니다. 보드의
debug-control `DISABLE_SWD`가 격리 위치이면 USB와 COM이 보이더라도 flash가 `No ACK`로 실패할 수
있습니다. 사용자 버튼 SW1/P1.09와 혼동하지 말고 SWD 연결 상태를 먼저 확인합니다.

| 순서 | Runner | 실기 판정 범위 |
| --- | --- | --- |
| 1 | `m24_uarte_onboard.py` | UARTE20/21/22/30의 DAP VCOM 32-byte DMA 왕복 |
| 2 | `m24_twim_onboard.py` | TWIM20/21/22의 BQ25186 MASK_ID read-only |
| 3 | `m25_onboard.py` | 내부 VDD SAADC, EGU→DPPI→TIMER event 경로 |
| 4 | `m26_onboard.py` | TEMP, WDT30 configure/start/feed·의도한 reset과 reset cause |

먼저 [Windows 개발환경](<../../../00_Docs/02_빌드 설계/09_Windows_개발환경_설정.md>)의 NCS 환경을
적용하고 **현재 clean commit**에서 전체 `v0.4.0` group을 새 짧은 경로에 build합니다. 다른 commit의
기존 image는 runner가 거부하므로 예전 build root를 재사용하지 않습니다.

```powershell
$CoreRoot = (Get-Location).Path
$Python = 'C:\ncs\toolchains\dcbdc366a1\opt\bin\python.exe'
$PyOcd = 'C:\ncs\toolchains\dcbdc366a1\opt\bin\Scripts\pyocd.exe'
$BuildRoot = 'C:\nb\01' # 전체 8자 이하, 아직 없는 하위 경로
$EvidenceRoot = Join-Path $env:USERPROFILE 'Documents\NU54DK-evidence\v04-run01'
$ProbeId = '<시험할 CMSIS-DAP UID>'

if ((Get-Command python.exe).Source -ne $Python) {
  throw 'NCS environment is required: pyocd.exe must select the bundled Python'
}
& $Python -I -c 'import sys, pyocd; print(sys.executable); print(pyocd.__version__, pyocd.__file__)'

& $Python tools\ci\run_zephyr_build.py `
  --workspace C:\ncs\v3.4.0 --outdir $BuildRoot --group v0.4.0 --jobs 4
if ($LASTEXITCODE -ne 0) { throw 'v0.4.0 build failed' }

$Runners = @('m24_uarte_onboard', 'm24_twim_onboard', 'm25_onboard', 'm26_onboard')
foreach ($Runner in $Runners) {
  & $Python "tests\hil\nu54dk\$Runner.py" `
    --repository $CoreRoot --build-root $BuildRoot --probe-id $ProbeId --pyocd $PyOcd `
    --evidence "$EvidenceRoot\$Runner.json"
  if ($LASTEXITCODE -ne 0) { throw "$Runner failed; later gates were not run" }
}
```

각 runner는 시작 시 clean source·board revision과 HEX hash를 기록하고 exact UID를 선택하며 mass erase/recover를
사용하지 않습니다. 실패하면 해당 시점에서 멈추며, 응답 없는 보드에서 PASS를 생성하지 않습니다.
Flash 종료 시에는 자동 reset/resume을 금지하고, 같은 probe를 다시 연결해 CPU reset·halt를 확인한
뒤 DAP target TX P0.00·P1.04가 reset 입력인지 확인하고 내부 pull-up으로 유휴 HIGH를 준비합니다.
고정 nRF54L15의 PIN_CNF에서 PULL 필드만 변경하며 출력 방향·다른 pin 설정은 바꾸지 않습니다.
입력 조건이나 readback이 다르면 CPU를 resume하지 않습니다. 활성 UART는 driver가 TX 출력을
설정하고, 비선택 UART 입력은 bias를 유지하여 host가 두 VCOM에 보내는 동안 floating RX에
예상 밖 byte가 들어오는 것을 막습니다. 변경 전·후 PIN_CNF는 controlled-start evidence에 남습니다.
이후 VCOM 두 포트의 초기 buffer를 비우고 명시적으로 resume합니다. 따라서 초기 reset transient는
앱이 READY를 보내기 전에만 제거됩니다. 시작 이후의 READY·측정 결과는 잡음을 허용하지 않습니다.
이 묶음의 PASS를 외부 SPI/TWIS·analog 정확도·audio·encoder·동시성·전력 검증으로 확대하지 않습니다.

TWIM과 M25 firmware는 유효 command 하나당 측정 결과 하나만 보내고 대기합니다. 결과에 다음
READY가 붙어 USB read 단위에 따라 성공·실패가 달라지지 않도록 한 flash당 단발 시험으로 합니다.
호스트는 완전한 frame 뒤에도 50 ms를 관찰하여 추가 byte를 거부합니다.

M26 protocol v2는 `READY → command → AR26 → WDT reset → RESET_READY → result request → NU26`
순서를 사용합니다. UART가 재초기화되기 전 reset 경계에서 transient byte가 관측됐으므로,
**AR26 검증 이후의 예상 reset 구간에서만** 최대 64바이트 prefix와 정확한 RESET_READY를
구분합니다. Prefix 원문·길이, 선택 VCOM, reset READY 대기 시간을 evidence schema v2에 남깁니다.
RESET_READY는 다른 VCOM·다른 marker·중복·후행 byte를 허용하지 않으며, 준비 신호 뒤 별도 request에
대한 NU26 결과는 여전히 정확한 32바이트·checksum·watchdog reset bit·retained TEMP를 요구합니다.
초기 READY, AR26, NU26에 잡음을 붙이거나 과거 protocol v1 진단을 새 PASS로 바꿀 수 없습니다.
이 검증은 reset 중 UART 신호가 깨끗하다는 전기적 보증을 포함하지 않습니다.

M25의 수동 SAADC 모드에서는 `start()`가 DMA를 준비하고, `ready` event 이후 `sample()`이 실제
변환을 요청합니다. `stop_timeout`이면 lease는 유지되며 `stop()`을 재시도해야 합니다. 내부 VDD
raw code를 교정된 전압이나 외부 채널 정확도 결과로 해석하지 않습니다.

현재 온보드 PASS와 exact JSON은 [교정·실기 재검증](<../../../00_Docs/04_검증 기록/41_M24_M26_온보드_protocol_교정과_실기_재검증.md>)을,
최종 release 절차의 이력은 [M27 자동 준비·HOLD 기록](<../../../00_Docs/04_검증 기록/39_M27_v0.4.0_rc1_자동_준비와_HOLD.md>)을 따릅니다.

## v0.4.0 두 보드 기능 fixture의 완료 기준

2026-09-04 [코어 기능 검증 범위 합의](<../../../00_Docs/04_검증 기록/42_v0.4.0_코어_기능_검증_범위_합의.md>)에
따라 로직 분석기·오실로스코프·교정 전압원·실제 마이크/코덱/엔코더는 필수 준비물이 아닙니다.
두 NU54DK의 승인 배선과 peer/loopback·합성 신호·capture를 사용하되 실제 data path와 기대
sample/frame/count, DMA·복구·허용 동시성·soak는 반드시 검증합니다. 필요한 pull-up 등 수동 부품과
전압·공통 GND·DAP UART switch·출력 충돌 확인은 생략하지 않습니다.

PDM/I2S/QDEC peer 신호 generator/receiver와 판정기는 build-only까지 준비했습니다. 이는 실제 핀에서
신호가 성립했다는 뜻이 아니며 T10 결선 뒤 실행하기 전까지 `NOT RUN`입니다. 신호 생성 또는 수신이
실패하면 HOLD로 남깁니다. 정밀 정확도·jitter·전력·음질·부품별 호환성은 `범위 밖·미측정`으로
구분하며 코어 기능 PASS로부터 추정하지 않습니다.

### 외부 UART/SPI/TWI fixture 모듈과 현재 실행 상태

[v04_fixtures.json](v04_fixtures.json)은 보드 소유자가 수기로 확정한
[P2/P4 커넥터 핀맵](<../../../00_Docs/01_아두이노 코어 설계/13_NU54DK_P2_P4_커넥터_핀맵.md>)과
[기계 판독 JSON](nu54dk_connector_pinmap.json)의 **커넥터 이름/핀 번호/GPIO net**을
사용하는 준비용 목록입니다. 화면상 net label 위치를 다시 추정해 핀 번호를 이동하지 않습니다.
`P2` 커넥터의 9/10/11/12번은 각각 GPIO P1.7/6/5/4입니다.
GPIO P2.4/5는 같은 커넥터의 17/19번입니다. GPIO 포트 이름을 커넥터 번호로 읽지 않습니다.
GPIO P2.6~10, PMIC I2C·INT, VBAT divider, LFXO에는 이 UART/SPI/TWI 시험을 연결하지 않습니다.
`P2-27`은 SWDCLK, `P2-28`은 SWDIO이며 일반 fixture 신호로 사용하지 않습니다.

새 `fixture_hil.cpp`는 고정된 UART 101/102/103, SPI 201/202/203과 TWI 301 경로만 선택합니다. 외부 명령은
명시적인 fixture 개정·확인값·controller role 없이는 거부되며, 실행 허가는 10초 뒤 만료됩니다.
STOP 미증명은 fault latch와 자원 보존으로 남습니다. 활성 외부 시험 동안 온보드 UART/PMIC
명령은 거부하고, 한 번에 한 controller만 생성합니다. 물리 스위치 감지는 하지 않습니다.

[v04_fixture.py](v04_fixture.py)는 역할·UID/image hash·30분 이내 사용자 결선 확인을 검사하고,
UART 135-vector, SPI 1,513-vector, TWI 328-vector를 준비합니다. UART는 단일·이중 RX buffer,
parity와 RTS/CTS를 포함하며 SPI/TWI controller는 동기·비동기 전송, peripheral/target은 단일·이중
buffer를 구분합니다. RX는 SWD mailbox로
전 바이트를 읽어 반대편의 독립 패턴 또는 ORC와 대조합니다. cleanup 기록은 기능 PASS와 분리합니다.
`v04_pair.py`는 계속 **온보드 전용**이며, 외부 시험은 별도 `v04_fixture_run.py`로 분리했습니다.
외부 실행기는 기본 preflight만 수행하고, `--execute-fixture`·별도 사용자 confirmation·새 evidence
경로가 모두 있어야 두 보드를 제어합니다. 같은 exact-boot helper로 두 role image를 시작하고
활성 session을 함께 유지합니다. RTS/CTS vector 하나는 receiver RX를 100ms 늦게 열어 sender TX가
완료되지 않는지 먼저 확인한 뒤 재개합니다. 8N1 sender/8E1 receiver와 1ms LOW generator로
parity/framing·break 오류 및 bounded STOP을 검사합니다. SPI는 모든 대상 instance에서 표현 가능한
2/4/8MHz를 사용하며 2MHz 1,024-byte 전송 취소,
TWI는 미등록 `0x44` NACK와 100kHz 256-byte 전송 취소 뒤 bounded STOP을 준비합니다.
각 오류·취소 직후 같은 lease에서 32-byte 정상 전송을 다시 수행해 재시작도 별도로 판정합니다.

pyOCD flash와 이후 mailbox session의 SWD clock은 `--swd-frequency-hz`로 함께 지정합니다.
기본값은 1,000,000 Hz입니다. CMSIS-DAP sector erase timeout이 재현되면 먼저 같은 UID를
read-only로 확인하고, 자동 recover나 mass erase 없이 `--swd-frequency-hz 100000`처럼 낮출 수
있습니다. 이 값은 UART/SPI/TWI bus clock이나 시험 vector 속도를 변경하지 않으며 evidence의
top-level과 role별 flash 기록에 남습니다.
TWI 추가 두 vector는 peer가 SDA를 LOW로 고정한 동안 복구 실패, 해제 뒤 `recoverBus()` 성공과
32-byte 정상 전송, TWIS buffer를 5ms 늦게 제공하는 실제 clock stretch 뒤 정상 완료를 판정합니다.
`buffer_needed`가 먼저 발생한 경우 `queueBuffers()`는 대기 중인 READ/WRITE 요청을 식별해
`nrfx_twis_tx_prepare()` 또는 `nrfx_twis_rx_prepare()`를 호출하고, 성공한 buffer를 DMA 소유로
전환한 뒤 clock stretch를 해제합니다. Buffer 방향이 맞지 않으면 전송을 방치하지 않고 거부합니다.
SPI fixture 201의 role 1에는 1,024-byte SPIM00 비동기 전송 중 온보드 TWIM22 PMIC read를
수행하는 허용 동시성 case가 추가되어 있습니다. 더 넓은 5-block 동시성 및 7,200초 soak는 단독
기능 실기 PASS 뒤 T13에서 수행하며 build-only 결과로 대체하지 않습니다.
TWI 301은 target 역할의 TWIS가 SDA/SCL 내부 pull-up을 명시적으로 활성화합니다. 외부 pull-up 저항과
두 보드 전원 rail 연결은 사용하지 않습니다. 확인 JSON의 `pullups_match_catalog`는 외부 pull-up과
전원 rail 연결이 없다는 사용자 확인을 포함하며, 참이 아니면 실행을 거부합니다. 내부 pull-up은 외부
2.2 kΩ 저항보다 약하므로 1MHz 통과는 짧은 fixture 배선의 기능 결과일 뿐 rise-time·신호 품질 또는
Fast-mode Plus 전기 규격 보증이 아닙니다. 이 절은 T10 전 실행 권한이 아닙니다.
preflight JSON에는 현재 source·UID·image hash에 묶인 `confirmation_template`이 함께 출력됩니다.
모든 안전 조건은 `false`, 시각은 `0`, 확인자는 빈 문자열로 생성되므로 실제 연결을 확인해 채우기
전에는 실행 승인이 되지 않습니다.

Fixture 101은 exact `2542a01`에서 양방향 UARTE data 1,620건과 예상 오류 24건을 통과했습니다.
세부 결선·결함 교정·100 kHz SWD 제어·증거 hash는
[Fixture 101 실기 기록](<../../../00_Docs/04_검증 기록/44_M24_Fixture_101_UART_실기_검증.md>)에
보존합니다. Fixture 102는 exact `ff3423e`에서 UARTE30 P0↔UARTE20/21/22 P1 양방향 data
810건과 예상 오류 12건을 통과했으며 [Fixture 102 실기 기록](<../../../00_Docs/04_검증 기록/45_M24_Fixture_102_UART_실기_검증.md>)에
보존합니다. Fixture 103은 exact `b3c689b`에서 UARTE20/21/22 P1↔P1 전 조합 양방향 data
2,430건과 예상 오류 36건을 통과했습니다. 중간 `FRAMING` 오류와 축소 재현·최종 전체 PASS의
구분은 [Fixture 103 실기 기록](<../../../00_Docs/04_검증 기록/46_M24_Fixture_103_UART_실기_검증.md>)에
보존합니다. UART Fixture 101~103의 결과를 아직 실행하지 않은 SPI/TWI에 확대하지 않습니다.

두 번째 보드 COM8/P0 DAP CTS 고정에 대해 2026-09-05 사용자가 HW 엔지니어의 납땜 이슈
진단을 전달했습니다. 정상 DUT의 RTS/CTS 결과는 유지하며, 해당 peer 경로는 FAIL 기록을 보존하고
반복 실행을 중단합니다. 이를 전체 코어 RTS/CTS 미지원 또는 다른 USB 문제의 원인으로 일반화하지 않습니다.

QDEC의 계획된 2/10ms 상태 간격에는 nrfx 기본 16384us sampling이 너무 느립니다. 후보 API에
`sample_period_us`·`led_pre_us`·`report_events`를 추가하고 기존 기본값은 보존했습니다.
준비용 `v04_qdec.py`는 256us sampling에서 A/B `00→01→11→10→00`을 +4, 역순을 -4로
판정하고 대각 전이를 별도로 셉니다. 자동 report는 누산기를 비우므로 수동 `read()`와 같은 구간을
중복 합산하지 않습니다. PWM20/21/22가 P1.14/P1.10에 quadrature sequence를 만들고 QDEC20/21이
격리된 P1.4/P1.6에서 받는 firmware와 runner를 준비했습니다. 이 oracle과 build PASS는 QDEC 실기
PASS가 아닙니다.

### Analog·stream 합성 신호 fixture — 아직 T10 실행 안내가 아님

`v04_signal_run.py`는 기본적으로 preflight만 출력합니다. `--execute-fixture`, 현재 source·두 UID·
두 image hash에 묶인 30분 이내 confirmation, 새 evidence 경로가 모두 있어야 flash와 외부 출력을
시도합니다. fixture 401~408과 420은 회로 안전상 peer인 role 2만 generator가 될 수 있습니다. 430/440은
두 role을 번갈아 clock/generator로 검사합니다.

| ID | 기능 | 전원 분리 상태에서 연결할 신호 | 판정 범위 |
| --- | --- | --- | --- |
| 401~404 | PWM→SAADC | peer P4.12(P1.14) → DUT P2.12/11/10/9의 P1.4/AIN0~P1.7/AIN3 중 해당 한 선, GND↔GND | PWM20/21/22 channel 0~3, AIN0~3, 32/256 sample과 DMA 길이 |
| 405 | 오픈드레인→SAADC | B P1.14 → A P1.11/AIN4, GND↔GND | PMIC_INT 공유 입력의 LOW/해제/LOW·32/256 sample·단일/이중 DMA·GPIO readback |
| 406 | 입력 바이어스→SAADC | B P1.14 → A P1.12/AIN5, GND↔GND | VBAT_MON/SB4·100nF 공유 입력; INPUT pull-down/up/down·25ms 정착·12 vector |
| 407 | 입력 바이어스→SAADC | B P1.14 → A P1.13/AIN6, GND↔GND | 버튼 미누름; INPUT pull-down/up/down·25ms 정착·12 vector |
| 408 | PWM→SAADC | peer P4.12(P1.14) → DUT P4.12(P1.14/AIN7), GND↔GND | 안전한 LED buffer 입력의 AIN7과 PWM channel 0~3 |
| 420 | PWM→QDEC | peer P4.12(P1.14) → DUT P2.12(P1.4/A), peer P4.8(P1.10) → DUT P2.10(P1.6/B), GND↔GND | PWM20/21/22×QDEC20/21, 방향·debounce·count |
| 430 | I2S | P1.4 SCK↔SCK, P1.5 LRCK↔LRCK, P1.6↔상대 P1.7 두 선 교차, GND↔GND | master/slave, 16/48kHz, 8/16/24/32-bit, channel·DMA packing |
| 440 | PDM | receiver P1.4 CLK→generator P1.5 SCK, receiver P1.6 DATA←generator P1.7 MISO, receiver P1.5 gate→generator P1.4 CSN, GND↔GND | PDM20/21, mono/stereo edge, 25/50/75% density 순서·channel 분리 |

401~404/408/420의 peer P1.14/P1.10은 온보드 LED buffer 입력에도 연결되어 있으나 MCU 출력끼리 맞물리지
않는 단방향 경로입니다. DUT의 P1.4~7과 403/404 양쪽 P1.4~7을 쓰려면 두 보드 debug-control의
`DISABLE_UART`를 DAP UART 분리 상태로 유지해야 합니다. `DISABLE_SWD`는 SWD 연결 상태로 둡니다.
fixture를 바꿀 때 두 USB 전원을 먼저 분리하고, 표에 없는 전원·신호선은 연결하지 않습니다.
AIN4 P1.11은 **SB1→PMIC_INT→BQ25186 /INT**와 공유합니다(원본 회로도 1·3쪽). 405는 B P1.14를
S0D1·내부 pull-up으로 구성해 LOW 또는 해제만 출력합니다. SB1·PMIC 설정 변경과 강한 HIGH 출력은 없습니다.
SB1 연결 시 R3 10kΩ도 pull-up에 참여하나 실제 SB1 상태를 추정하지 않습니다. LOW raw는 -256~256,
해제 raw는 -256~4095 안에서 95% 이상 >256 및 median >256이어야 합니다. 해제 단계에는 PMIC의 짧은
interrupt LOW를 허용하며 정확한 전압·PMIC 동작 검증으로 확대하지 않습니다. 시작 전 10ms 정착,
명령 38의 실제 GPIO 설정과 전체 ADC sample·hash를 보존하고 양쪽 cleanup 시 B를 먼저 입력으로 해제합니다.
AIN5 P1.12는 SB4→VBAT_MON→R8 470kΩ/VBAT·R11 1MΩ/GND·C12 100nF와 공유합니다.
406은 B P1.14의 **INPUT 내부 pull-down/up/down**으로 필터를 충방전하며 출력 드라이버는 활성화하지 않습니다.
25ms 정착 후 모든 LOW sample이 -256~512, 모든 HIGH sample이 1024 초과~4095여야 PASS입니다.
GPIO raw PIN_CNF mask 0xF0F는 LOW 0x4/HIGH 0xC, 종료 no-pull 입력은 0이어야 합니다.
SB4·PMIC 설정을 변경하지 않으며 실제 배터리 전압이나 SB4 연결 상태를 측정한 것으로 취급하지 않습니다.
AIN6 P1.13은 SW1 신호(버튼 부품 SW2)와 공유하며 누르면 GND로 연결됩니다(회로도 1·8쪽).
407은 버튼을 누르지 않고 406과 같은 B P1.14 INPUT 내부 pull-down/up/down·25ms 정착 및
LOW/HIGH 전 sample·GPIO raw INPUT·DMA·cleanup 판정을 사용합니다. 버튼 자체·debounce·wake 시험은 아닙니다.
**405→406→407→408 모두 필수**이며 준비와 각 ID의 실제 PASS는 구분합니다.

PDM source는 receiver가 만든 MHz clock을 SPIS21 EasyDMA로 추종하므로 software bit-bang을 기능
근거로 사용하지 않습니다. mono density 평균은 25<50<75 순서를, stereo는 교대 sample channel의
평균 차이를 검사합니다. I2S는 양쪽 독립 pattern을 sample width/channel mask로 대조합니다. 실제
마이크·코덱·엔코더 호환성과 음질은 이 fixture의 범위가 아닙니다.

405·406·407은 각각 sample 길이 2 × 단일/이중 buffer 2 × LOW/HIGH/LOW 3의 **12 vector·2,592 samples**입니다. 405는 오픈드레인, 406·407은 입력 바이어스 방식입니다.
401~404/408 Analog fixture는 각 ID마다 PWM 3 instance × channel slot 4 × sample 길이 2 × 단일/이중 buffer로
48개 vector를 실행합니다. PDM은 instance 2 × sample 길이 2 × density 3 × mono/stereo 2 × edge 2 ×
단일/이중 buffer 2의 96개 vector이며, I2S도 두 rate·네 width·세 channel mode·두 길이·단일/이중
buffer의 96개 vector입니다. 수치는 준비된 실행 경우의 수이고 실기 PASS 수가 아닙니다.

`v04_campaign.py`는 반복 횟수를 1~100회, 한 연속 soak를 최대 7,200초로 제한하고 1~60초 간격의
progress를 journal에 남깁니다. 중단된 실행은 `interrupted`이며 다음 실행에 경과 시간을 합산하지
않습니다. UART/SPI/TWI와 signal CLI의 `--repetitions`, `--duration-seconds`,
`--progress-interval-seconds`가 이 공통 계약을 사용합니다. 단독 기능 실기 PASS 전에는 soak를
시작하지 않으며, 동시성은 해당 fixture 조합을 별도로 승인한 뒤 수행합니다.

2026-09-07 사용자 지시로 T13 단독 안정성 목표는 인스턴스별 **180초(3분)**입니다.
실행기는 기간을 명시적으로 받으므로 해당 단독 campaign에 `--duration-seconds 180`을 전달합니다.
일반 기능 검사 기본값 0과 공통 실행기 최대 7200초는 유지하며, 전체 기능 sweep 반복을
각 인스턴스의 연속 부하 증거로 대체하지 않습니다. 동시 시험은 각 확정 조합 900초이며, 전체 대표 고부하 한 조합만 3600초로 대체합니다. 대표 한 조합을 family마다 중복 선정하지 않습니다.

R00~R13 이후 exact 154324c의 current-source Fixture 101은 SWD 10 MHz에서 데이터 1,620개·예상 오류 24개를 통과했습니다. [67번 기록](<../../../00_Docs/04_검증 기록/67_T11_Fixture_101_current_source_UART_회귀.md>)에 exact 증거를 보존합니다. 전체 current-source T11과 T12/T13 PASS는 아직 아닙니다.

Current-source Fixture 102도 exact a49cc0d·SWD 10 MHz에서 데이터 810개·예상 오류 12개를 통과했습니다. [68번 기록](<../../../00_Docs/04_검증 기록/68_T11_Fixture_102_current_source_UART_회귀.md>)에 원본을 보존합니다.

Current-source Fixture 103은 exact 7aece93·SWD 10 MHz에서 데이터 2,430개·예상 오류 36개를 통과했습니다. 최초 peer flash timeout과 읽기 전용 진단 뒤 한 번의 새 실행을 [69번 기록](<../../../00_Docs/04_검증 기록/69_T11_Fixture_103_current_source_UART_회귀.md>)에 구분해 보존했습니다. UART 세 묶음을 완료했습니다.

Current-source Fixture 201도 exact 0f429e7·SWD 10 MHz에서 data 18,157개와 예상 cancel 12개를 통과했습니다. Data에는 recovery 12개와 SPIM00+TWIM22 동시성 1개가 포함됩니다. [70번 기록](<../../../00_Docs/04_검증 기록/70_T11_Fixture_201_current_source_SPI_회귀.md>)에 원본을 보존합니다.

Current-source Fixture 202는 exact 1349e20·SWD 10 MHz에서 data 9,078개와 예상 cancel 6개를 통과했습니다. Data에는 recovery 6개가 포함됩니다. 최초 peer flash 실패·진단과 한 번의 새 전체 실행은 [71번 기록](<../../../00_Docs/04_검증 기록/71_T11_Fixture_202_current_source_SPI_회귀.md>)에 구분 보존했습니다.

Current-source Fixture 203은 exact be49207·SWD 10 MHz에서 data 27,234개와 예상 cancel 18개를 통과했습니다. Data에는 recovery 18개가 포함됩니다. 최초 DUT flash 실패·진단과 한 번의 새 전체 실행은 [72번 기록](<../../../00_Docs/04_검증 기록/72_T11_Fixture_203_current_source_SPI_회귀.md>)에 구분 보존했습니다. 승인 SPI 세 route의 회귀를 마쳤습니다.

Current-source Fixture 301은 exact 9a63251·SWD 10 MHz 첫 실행에서 data 1,968개, NACK/cancel 12개, stuck-SDA bus recovery 6개를 통과했습니다. Data에는 복구 18개와 clock stretch 6개가 포함됩니다. [73번 기록](<../../../00_Docs/04_검증 기록/73_T11_Fixture_301_current_source_TWI_회귀.md>)에 고유 ID·순서 대조와 current-source T11 단독 회귀 완료를 보존했습니다. T12 Fixture 401~404도 각각 48개를 통과했으며 405 오픈드레인·406/407 입력 바이어스 시험과 408 PWM도 완료했으며 420 QDEC도 완료했으며 430 I2S도 exact 36ba819의 전체 192개를 통과했으며 440 PDM의 최신 상태는 아래 92번 연속 전체 검증 기록을 따른다.

T12 Fixture 401 exact a12e444·SWD 10 MHz 첫 실행 48개 기능 PASS와 10,368 samples·cleanup 48개는 [74번 기록](<../../../00_Docs/04_검증 기록/74_T12_Fixture_401_current_source_PWM_ADC_검증.md>)에 보존했다. T12는 부분 완료이며 405 오픈드레인·406/407 입력 바이어스 시험과 408 PWM도 완료했으며 420 QDEC도 완료했으며 430 I2S도 exact 36ba819의 전체 192개를 통과했으며 440 PDM의 최신 상태는 아래 92번 연속 전체 검증 기록을 따른다. PWM 주기·듀티 capture와 T12 나머지 요구·후속 gate는 이 결과로 완료 처리하지 않는다.

T12 Fixture 402 exact ff483a1·SWD 10 MHz 첫 실행 48개 PASS는 [75번 기록](<../../../00_Docs/04_검증 기록/75_T12_Fixture_402_current_source_PWM_ADC_검증.md>)에 보존했다. 401·402 합계 기능 96개·samples 20,736개이며 각 exact identity는 구분한다. 405 오픈드레인·406/407 입력 바이어스 시험과 408 PWM도 완료했으며 420 QDEC도 완료했으며 430 I2S도 exact 36ba819의 전체 192개를 통과했으며 440 PDM의 최신 상태는 아래 92번 연속 전체 검증 기록을 따른다.

T12 Fixture 403 exact c95b904·SWD 10 MHz 첫 실행 48개 PASS는 [76번 기록](<../../../00_Docs/04_검증 기록/76_T12_Fixture_403_current_source_PWM_ADC_검증.md>)에 보존했다. 401~403 합계 기능 144개·samples 31,104개이며 각 exact identity는 구분한다. 405 오픈드레인·406/407 입력 바이어스 시험과 408 PWM도 완료했으며 420 QDEC도 완료했으며 430 I2S도 exact 36ba819의 전체 192개를 통과했으며 440 PDM의 최신 상태는 아래 92번 연속 전체 검증 기록을 따른다.

T12 Fixture 404 exact e080bbc·SWD 10 MHz 첫 실행 48개 PASS는 [77번 기록](<../../../00_Docs/04_검증 기록/77_T12_Fixture_404_current_source_PWM_ADC_검증.md>)에 보존했다. 401~404 합계 기능 192개·samples 41,472개이며 각 exact identity는 구분한다. 405 오픈드레인·406/407 입력 바이어스 시험과 408 PWM도 완료했으며 420 QDEC도 완료했으며 430 I2S도 exact 36ba819의 전체 192개를 통과했으며 440 PDM의 최신 상태는 아래 92번 연속 전체 검증 기록을 따른다.

T12 Fixture 405 exact 9fc12bf·SWD 10 MHz **첫 실행 12개 PASS**, LOW/해제/LOW·2,592 samples·cleanup 12개와 GPIO readback은 [78번 기록](<../../../00_Docs/04_검증 기록/78_T12_Fixture_405_current_source_공유_AIN4_검증.md>)에 보존했다. 공유 AIN4/P1.11의 기능을 확인했으며 이후 406·407도 완료했으며 후속 **408도 완료**했다. 제품 core 변경 없이 Host 648개·pair target 2/2를 통과했고 T12 전체·후속 gate는 미완료다.

T12 Fixture 406 exact 96f38e9·SWD 10 MHz **첫 실행 12개 PASS**, 입력 pull-down/up/down·2,592 samples·cleanup 12개와 GPIO readback은 [79번 기록](<../../../00_Docs/04_검증 기록/79_T12_Fixture_406_current_source_공유_AIN5_검증.md>)에 보존했다. Host 649개·pair target 2/2 PASS. 당시 401~406 합계 기능 216개·samples 46,656개였으며 407의 새 결과는 아래 82번에 구분한다. 이후 사용자가 407 결선 A P1.13↔B P1.14·공통 GND와 USB 분리/재연결을 확인했다. 버튼 미누름·DAP UART 분리/SWD 연결 조건이며 LLVM Host 회귀 뒤 결선 유지를 재확인해 407 첫 실행 12개를 통과했다. 408도 완료했으며 이후 420 QDEC도 완료했으며 430 I2S도 exact 36ba819의 전체 192개를 통과했으며 440 PDM의 최신 상태는 아래 92번 연속 전체 검증 기록을 따른다. T12 전체·후속 gate는 미완료다.

407 재개 exact 393e419는 설치된 LLVM 22.1.8로 Host **655 PASS·1 조건부 SKIP(총 656)**, 계약 45·package 20·정렬 358·Inventory·예제 발견과 pair/BLE **target 8/8**을 통과했다. BLE 형 변환의 기계어·재배치도 6/6 동일하다. [81번 재개 기록](<../../../00_Docs/04_검증 기록/81_T12_Fixture_407_Host_재개와_검증.md>)에 새 근거를 보존했다. 이전 Windows 차단 원본은 80번에 유지하며 보안 정책을 변경하지 않았다. 이 준비 단계에서는 결선 확인 만료로 실기를 보류했다. 이후 사용자 유지 확인을 받아 actual source 4a64c25의 407 첫 실행을 완료했으며 아래 82번에 구분한다.

T12 Fixture 407 exact 4a64c25·SWD 10 MHz **첫 실행 12개 PASS**는 [82번 기록](<../../../00_Docs/04_검증 기록/82_T12_Fixture_407_current_source_공유_AIN6_검증.md>)에 보존했다. 버튼 미누름 AIN6/P1.13에서 입력 pull-down/up/down·2,592 samples·cleanup 12개와 입력 GPIO 24회·해제 12회를 확인했다. LOW median 0·HIGH median 3752, postflight 양쪽 source/role 확인 PASS. 당시 401~407 누계는 **228개 기능·49,248 samples·228개 cleanup**이었다. 이후 408 결과는 아래 83번에 구분한다. T12 전체·T13 이후와 readiness 미해결 8개는 유지한다.

T12 Fixture 408 exact 87b987d·SWD 10 MHz **48개 기능 PASS**는 [83번 기록](<../../../00_Docs/04_검증 기록/83_T12_Fixture_408_current_source_PWM_ADC_검증.md>)에 보존했다. 최초 DUT flash timeout은 외부 시험 시작 전 실패였으며, 읽기 응답 회복 확인 뒤 한 번의 새 실행으로 10,368 samples·cleanup 48회를 통과했다. 두 runtime identity도 재확인했다. 401~408 누계 **276개 기능·59,616 samples·276개 cleanup**으로 AIN0~7의 개별 기능 근거를 확보했다. 420 QDEC도 완료했다. 현재 **430 I2S는 전체 192개 PASS**이며 440 PDM과 남은 T12 요구·T13 이후·readiness 미해결 8개는 유지한다.

420 QDEC 최신 결과는 [85번 기록](<../../../00_Docs/04_검증 기록/85_T12_Fixture_420_current_source_QDEC_재검증.md>)의 **exact 6bd8d3f 기능 48·cleanup 48·시작 전 취소 6개 PASS**다. SWD 10 MHz, 22.063초 기능 실행과 두 보드 identity·핀 복원·PWM/QDEC 해제를 확인했다. [84번](<../../../00_Docs/04_검증 기록/84_T12_Fixture_420_current_source_QDEC_검증.md>)의 이전 실패·교정 기록은 유지한다. a3d0ab5와 코드·설정이 같음을 대조했으며 이전 전체 Host 656 PASS·1 조건부 SKIP와 정렬 359 PASS는 해당 source 결과로 구분한다. 430 I2S는 아래 87번에서 오류 교정 후 전체 192개 PASS를 기록했다. 440 PDM의 최신 상태는 아래 92번 연속 전체 검증 기록을 따른다. 공용 PWM 지연 시작 취소 이슈는 T14, 440 PDM·남은 T12 요구·T13 이후와 readiness 미해결 8개도 유지한다.

430의 이전 세 source 실패·교정·72개 부분 통과 이력은 [86번 기록](<../../../00_Docs/04_검증 기록/86_T12_Fixture_430_current_source_I2S_검증.md>)에 보존한다.

430 I2S 최신 결과는 [87번 기록](<../../../00_Docs/04_검증 기록/87_T12_Fixture_430_current_source_I2S_재검증.md>)의 **exact 36ba819 기능 192·cleanup 192개 PASS**다. 공용 compact DMA token 처리 지연을 교정해 queue 시간이 278~309 us에서 104~112 us로 줄었고, 수신 원본 384개·전체 payload 82,944 word를 독립 대조했다. SWD 10 MHz, 양쪽 identity·I2S off·핀 복원 확인. 전체 Host 659 PASS·1 조건부 SKIP, 계약 45·package 20·Inventory·정렬 361·관련 target 10개 PASS다. 440의 후속 실기는 88~90번에 실패·부분 결과와 재시험 준비로 구분하며, 남은 T12·T13 이후·T14 공용 PWM 이슈·readiness 미해결 8개를 유지한다. 공용 자원 변경 이후의 T11 외부 실기는 이번에 재실행하지 않았다.

440 PDM의 이전 실행은 [88번 기록](<../../../00_Docs/04_검증 기록/88_T12_Fixture_440_current_source_PDM_검증.md>)의 **exact ea4e25a 모노 DMA 4 PASS·첫 stereo FAIL·187 미실행**이다. 밀도 비교는 미도달이며 전체 PDM PASS가 아니다. HIL buffer 공급·신호원·격리된 DAP 핀 metadata를 교정했지만 동일 stereo 채널의 원인은 미해결이다. SWD 10 MHz, cleanup 5회·양쪽 identity/peripheral off·입력 복귀 확인. 전체 Host 660 PASS·1 조건부 SKIP, 정렬 361·pair 2/2 build PASS. 확인 유효시간 20:15:39Z가 지나 440 결선·DAP UART 분리 유지 재확인 후 설정/신호 전달 진단과 전체 재검증을 진행한다. 연속 PDM 4+100 buffer·나머지 T12·T13 이후·T14 공용 PWM·readiness 8개는 유지한다.

440 최신 상태는 [92번 기록](<../../../00_Docs/04_검증 기록/92_T12_Fixture_440_PDM_연속_전체_검증.md>)의 **연속 4+100 버퍼 96개 조합·밀도 비교 16개·cleanup 96개 전체 PASS**다. Exact f02734d에서 SWD 10 MHz로 한 campaign을 완료했고 DMA 반환 9,984개·6,389,760 samples의 장치 통계를 대조했다. 측정 버퍼 각각의 모노 밀도 순서 1,600개·스테레오 부호 4,800개도 PASS다. 기본 기능 192·밀도 비교 32 PASS는 코드·설정이 같은 917dc02의 91번 결과로 구분한다. 두 보드 f02734d identity·주변장치 off·신호 입력 복귀와 pair build 2/2를 확인했다. 전체 Host는 [93번 기록](<../../../00_Docs/04_검증 기록/93_Host_재검증과_T12_이후_남은_작업.md>)의 exact e6979af에서 664 PASS·1 조건부 SKIP로 재검증을 완료했다. LLVM과 WinLibs sysroot를 유지하고 NCS 번들 CMake·Ninja를 선택했다. 440의 기본·연속 기능 검증은 완료했고 추가 결선 확인 요청은 없다. 남은 T12 요구·T13 이후·readiness 8개는 미완료다.

Fixture 440의 `--pdm-continuous`는 4개 안정화 + 100개 측정 버퍼를 전송 중단 없이 수신한다. 수신기 gate HIGH를 신호원보다 먼저 준비하며, opcode 39의 8-word 기록은 순서·slot·sample 수·좌우 합계·최솟값/최댓값·FNV다. 네 DMA slot의 전후 canary와 256-sample buffer 뒤 미사용 영역을 검사한다. 첫 4개는 평균에서 제외한다. 기본 모드는 기존 1/2 buffer와 전체 PCM 원본 판정을 유지한다. 연속 모드는 장치 통계이며 전체 PCM export가 아니다. Stereo 25/50 selector는 같은 0/100% edge pattern, 75 selector는 반전이며 실제 stereo 25/50/75% 발생 보증은 아니다.
