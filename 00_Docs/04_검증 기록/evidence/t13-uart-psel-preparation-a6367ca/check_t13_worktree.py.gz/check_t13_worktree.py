"""! @brief 격리 checkout의 Host·target·문서 원본을 고정 도구로 보존합니다. """
from pathlib import Path
import os
import sys
import check_pc

check_pc.REPO = Path('C:/tr13dev')
REPO, SDK, PYTHON, LLVM = check_pc.REPO, check_pc.SDK, check_pc.PYTHON, check_pc.LLVM
mode, label = sys.argv[1:3]
env = check_pc.host_environment()
if mode == 'target':
    sys.path.insert(0, str(REPO/'tools/nu54-builder/src'))
    from nu54_builder_impl.environment import apply_toolchain_environment
    env = apply_toolchain_environment(SDK)
    env['PATH'] = os.pathsep.join(str(value) for value in (
        SDK/'mingw64/bin', SDK/'bin', SDK/'opt/bin', SDK/'opt/bin/Scripts',
        SDK/'opt/zephyr-sdk/gnu/arm-zephyr-eabi/bin', Path('C:/Program Files/Git/cmd'),
        Path('C:/Windows/System32'), Path('C:/Windows')))
    env['PYTHONUTF8'] = '1'
    command = (SDK/'opt/bin/python.exe', '-B', REPO/'tools/ci/run_zephyr_build.py',
        '--workspace', 'C:/ncs/v3.4.0', '--outdir', sys.argv[3], '--group', 'v0.4.0',
        '--suite', 'nucode.v04.t13_s_dut', '--suite', 'nucode.v04.t13_s_peer', '--jobs', '2')
elif mode == 'host':
    command = (PYTHON, '-B', '-m', 'unittest', 'discover', '-v', '-s', 'tests/host',
               '-p', sys.argv[3] if len(sys.argv) > 3 else 'test_v04_t13*.py')
elif mode in ('style', 'format'):
    command = [PYTHON, '-B', REPO/'tools/format/run_cpp_style.py', '--clang-format', LLVM/'clang-format.exe']
    if mode == 'format':
        command.append('--write')
else:
    command = (PYTHON, '-B', REPO/'tools/ci/run_m12_gate.py', 'host' if mode == 'host-full' else mode)
raise SystemExit(check_pc.run(label, command, env))
