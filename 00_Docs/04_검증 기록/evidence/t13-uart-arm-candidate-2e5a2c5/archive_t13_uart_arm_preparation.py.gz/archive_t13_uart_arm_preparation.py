"""! @brief UART ARM 수정 초안의 정확한 patch와 검사·이미지 해시를 보존합니다. """
import hashlib
import json
from pathlib import Path
import subprocess
from check_pc import PYTHON, REPO, WORK

source = '2e5a2c5945fb3545e4f870a3f02b4fc4c55173c5'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == source
names = ['tests/zephyr/v04_t13_hil/src/engine.cpp', 'tests/zephyr/v04_t13_hil/src/uart_fault.cpp',
         'tests/hil/nu54dk/v04_t13_uart_line.py', 'tests/host/test_v04_t13_uart_line.py']
patch = subprocess.check_output(['git', 'diff', '--binary', '--', *names], cwd=REPO)
assert patch
patch_path = WORK/'t13-uart-arm-candidate.patch'
with patch_path.open('xb') as stream:
    stream.write(patch)
report = {'source_kind': 'uncommitted_candidate_on_base_plus_patch', 'base_source': source,
          'patch_sha256': hashlib.sha256(patch).hexdigest(), 'physical_executed': False,
          'exact_committed_candidate_hil': False, 'files': [], 'images': []}
for name in names:
    report['files'].append({'file': name, 'sha256': hashlib.sha256((REPO/name).read_bytes()).hexdigest()})
for role in ('dut', 'peer'):
    folder = Path('C:/t4x04/nrf54l15dk_nrf54l15_cpuapp_nu54dk/zephyr_gnu')/('nucode.v04.t13_s_'+role)/'v04_t13_hil/zephyr'
    for extension in ('elf', 'hex'):
        path = folder/('zephyr.'+extension)
        report['images'].append({'role': role, 'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
note = WORK/'t13-uart-arm-candidate-provenance.json'
with note.open('x', encoding='utf-8') as stream:
    json.dump(report, stream, indent=2)
labels = ['t13-uart-arm-'+name+'-01' for name in ('unit', 'host', 'target', 'format')]
labels += ['t13-s-final-style-01', 't13-s-final-contract-01', 't13-s-final-docs-02']
for label in labels:
    assert json.loads((WORK/(label+'.json')).read_text())['exit_code'] == 0
files = [label+suffix for label in labels for suffix in ('.json', '.log')]
files += [patch_path.name, note.name, 'archive_t13_uart_arm_preparation.py']
raise SystemExit(subprocess.call([str(PYTHON), '-X', 'utf8', '-B', str(WORK/'archive_t13_files.py'),
    't13-uart-arm-candidate-2e5a2c5', source, *files], cwd=REPO))
