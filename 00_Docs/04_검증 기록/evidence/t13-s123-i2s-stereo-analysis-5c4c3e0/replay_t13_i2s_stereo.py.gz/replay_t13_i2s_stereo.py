"""! @brief 새 실제 원본7회를 재판정하되 기존 실패·재실기 미완료 상태를 유지합니다. """
import hashlib
import json
import sys
from check_pc import WORK, REPO

sys.path.insert(0, str(REPO/'tests/hil/nu54dk'))
import v04_t13_stream_fault as fault

folder = WORK/'t13-s-20260908'
name = 'i2s-b-s123-100-01'
data = json.loads((folder/name/'result.json').read_text(encoding='utf-8'))
rows = {row['id']: row for row in data['results']}
reports = []
for source in data['results']:
    if not source['id'].endswith('/input') or 'mode' not in source:
        continue
    prefix = source['id'].removesuffix('/input')
    page = prefix+'/unexpected-data/failure/role1/i2s-failure-page'
    if page+'0' not in rows:
        continue
    raw = rows[prefix+'/final/role2/fault']['words']
    stream = rows[prefix+'/final/role2/stream']['words']
    peer = rows[prefix+'/final/role1/stream']['words']
    metadata = rows[page+'0']['words']
    buffer = [word for number in range(1, 17) for word in rows[page+str(number)]['words']]
    reports.append({'repetition': source['repetition'],
                    'fault': fault.inspect(raw, stream, source['test'], 2, 1),
                    'tail': fault.inspect_i2s_peer_tail(raw, peer, metadata, buffer, source['seed'], 2)})
assert len(reports) == 7 and reports[-1]['tail']['last_stereo_frame_truncated']
result = {'campaign': name, 'source': data['core_revision'], 'original_status': data['status'],
          'physical_access': False, 'new_physical_recovery_pass': False, 'reports': reports,
          'oracle_sha256': hashlib.sha256((REPO/'tests/hil/nu54dk/v04_t13_stream_fault.py').read_bytes()).hexdigest()}
with (folder/'i2s-b-s123-stereo-replay-01.json').open('x', encoding='utf-8') as stream:
    json.dump(result, stream, indent=2)
print(json.dumps(result))
