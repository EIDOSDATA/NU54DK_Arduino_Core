"""! @brief 실패한 실행의 RAM과 GPIO를 reset 없이 읽어 첫 오류와 정지 상태를 보존합니다. """
import json
import logging
import sys
from pathlib import Path
from check_pc import REPO, WORK
from elftools.elf.elffile import ELFFile
from pyocd.core.helpers import ConnectHelper
sys.path.insert(0, str(REPO/'tests/hil/nu54dk'))
import v04_pair as pair
from v04_protocol import ProbeLocks
logging.disable(logging.CRITICAL)
folder = WORK/'t13-s-20260908'
private = json.loads((folder/'probe-uids-local.json').read_text(encoding='utf-8'))
grant = json.loads((folder/'session-grant-repair1.json').read_text(encoding='utf-8'))
uids = [private[key].lower() for key in grant['uid_sha256']]
campaign = sys.argv[1] if len(sys.argv) > 1 else 'preflight-7a33b77-attempt2'
images = json.loads((folder/campaign/'images.json').read_text(encoding='utf-8'))
result = {'type': 'read-only-post-failure', 'source': images[0]['core_revision'], 'devices': []}
with ProbeLocks(uids):
    for uid, image in zip(uids, images):
        with Path(image['elf']).open('rb') as stream:
            elf = ELFFile(stream)
            symbols = [s for s in elf.get_section_by_name('.symtab').iter_symbols()
                       if s['st_size'] and s['st_info']['type'] == 'STT_OBJECT' and
                       any(name in s.name for name in ('lanesE', 'healthyE', 'expirationsE', 'gateE', 'lane_countE', 'edgesE', 'stream_statsE'))]
            members, types = {}, {}
            for cu in elf.get_dwarf_info().iter_CUs():
                for die in cu.iter_DIEs():
                    if die.tag == 'DW_TAG_structure_type' and die.attributes.get('DW_AT_name') and die.attributes['DW_AT_name'].value == b'Lane':
                        members = {m.attributes['DW_AT_name'].value.decode(): m.attributes['DW_AT_data_member_location'].value
                                   for m in die.iter_children() if m.tag == 'DW_TAG_member'}
                    if die.tag == 'DW_TAG_structure_type' and die.attributes.get('DW_AT_name') and die.attributes['DW_AT_name'].value in (b'Edges', b'StreamStats') and 'DW_AT_byte_size' in die.attributes:
                        types[die.attributes['DW_AT_name'].value.decode()] = {
                            'size': die.attributes['DW_AT_byte_size'].value,
                            'members': {m.attributes['DW_AT_name'].value.decode(): m.attributes['DW_AT_data_member_location'].value
                                        for m in die.iter_children() if m.tag == 'DW_TAG_member'}}
        with ConnectHelper.session_with_chosen_probe(unique_id=uid, target_override='nrf54l', frequency=10000000,
                blocking=False, no_config=True, options={'auto_unlock': False, 'connect_mode': 'attach',
                'resume_on_disconnect': False, 'cmsis_dap.limit_packets': True}) as connection:
            target = connection.target
            pair.verify_identity(bytes(target.read_memory_block8(image['symbols']['v04_identity'], 64)),
                                 image['role'], image['core_revision'])
            row = {'role': image['role'], 'state': target.get_state().name, 'symbols': {}, 'lane': {}, 'pin_cnf': {}}
            for symbol in symbols:
                address, size = symbol['st_value'], symbol['st_size']
                if 'lanesE' in symbol.name:
                    for name in ('error', 'driver_error', 'active', 'queued_tx', 'queued_rx', 'requests'):
                        row['lane'][name] = target.read8(address+members[name]) if name == 'active' else target.read32(address+members[name])
                elif 'edgesE' in symbol.name:
                    row['edges'] = {name: target.read32(address+offset) for name, offset in types['Edges']['members'].items()}
                elif 'stream_statsE' in symbol.name:
                    description = types['StreamStats']
                    row['streams'] = []
                    for index in range(4):
                        row['streams'].append({name: (target.read8 if name in ('enabled', 'active') else target.read32)(
                            address+index*description['size']+description['members'][name]) for name in
                            ('enabled', 'active', 'error', 'detail', 'completed', 'queued', 'units', 'max_gap_ms')})
                else:
                    row['symbols'][symbol.name] = list(target.read_memory_block8(address, size))
            for port, base, pins in ((0, 0x5010A000, range(4)), (1, 0x500D8200, [4,5,6,7,10,14]), (2, 0x50050400, range(7))):
                for pin in pins:
                    row['pin_cnf'][f'P{port}.{pin:02}'] = target.read32(base+0x80+pin*4)
            row['all_17_input'] = all(value & 1 == 0 for value in row['pin_cnf'].values())
            result['devices'].append(row)
output = folder/(campaign+'-readonly.json') if len(sys.argv) > 1 else folder/'start-failure-readonly-attempt2.json'
with output.open('x', encoding='utf-8') as stream:
    json.dump(result, stream, indent=2)
print(json.dumps([{'role': row['role'], 'state': row['state'], 'lane': row['lane'],
                  'streams': row.get('streams'), 'edges': row.get('edges'),
                  'all_17_input': row['all_17_input']} for row in result['devices']], indent=2))
