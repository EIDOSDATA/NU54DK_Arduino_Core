"""! @brief 앞선 SPI 배치 뒤 확인 잔여시간 안에서 C01/C05 동시 CTS를 검사합니다. """
from pathlib import Path

helper = Path(__file__).with_name('unattended_t13_followups.py')
prefix = helper.read_text(encoding='utf-8').split('\ntry:\n    save()')[0]
prefix = prefix.replace("'unattended-s-followups-01.json'", "'unattended-s-concurrent-flow-01.json'")
prefix = prefix.replace("'waiting-for-current-S-batch'", "'waiting-for-SPI-boundary-tests'")
exec(compile(prefix, str(helper), 'exec'))

try:
    save()
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.OpenProcess.argtypes = (ctypes.c_uint32, ctypes.c_bool, ctypes.c_uint32)
    kernel.OpenProcess.restype = ctypes.c_void_p
    kernel.WaitForSingleObject.argtypes = (ctypes.c_void_p, ctypes.c_uint32)
    kernel.WaitForSingleObject.restype = ctypes.c_uint32
    kernel.CloseHandle.argtypes = (ctypes.c_void_p,)
    handle = kernel.OpenProcess(0x00100000, False, 16600)
    if not handle:
        raise RuntimeError('original SPI boundary process handle unavailable; review final state')
    try:
        while True:
            result = kernel.WaitForSingleObject(handle, 20000)
            if result == 0:
                break
            if result != 258:
                raise RuntimeError('SPI boundary process wait failed')
            if time.time() >= grant['expires_at_unix']:
                raise RuntimeError('S confirmation ended while prior SPI boundary tests were running')
    finally:
        kernel.CloseHandle(handle)
    previous = json.loads((folder/'unattended-s-spi-boundary-01.json').read_text())
    if previous['status'] != 'finished-available-spi-boundary-tests':
        raise RuntimeError('prior SPI boundary tests did not finish with attempted cleanup proven')
    records = json.loads((folder/'concurrent-flow-builds.json').read_text())
    if len(records) != 1:
        raise RuntimeError('one exact concurrent CTS build registration required')
    build, record = next(iter(records.items()))
    source = record['source']
    passed = []
    for case in (101, 105):
        for role in (1, 2):
            name = f'c{case-100:02}-cts-r{role}'
            options = ['--cases', str(case), '--fault-role', str(role)]
            if execute(name+'-preflight-sauto-01', source, 'run_t13_concurrent_flow.py', build,
                       ['--phase', 'flow-preflight', *options], 120):
                passed.append((name, options))
    for name, options in passed:
        execute(name+'-100-sauto-01', source, 'run_t13_concurrent_flow.py', build,
                ['--phase', 'uart-flow', *options], 900)
    report.pop('active', None)
    report['status'] = 'finished-available-concurrent-flow-tests'
    save()
except BaseException as error:
    report.update(status='stopped-requires-review', error=f'{type(error).__name__}: {error}')
    save()
    raise
