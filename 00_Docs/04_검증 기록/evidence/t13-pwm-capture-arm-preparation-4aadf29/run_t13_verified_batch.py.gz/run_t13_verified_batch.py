"""! @brief 이미 구현·예행한 S 시험을 순차 수행하고 첫 실패에서 후속 실행을 멈춥니다. """
import argparse
from datetime import datetime, timezone
import json
import re
import subprocess
from check_pc import PYTHON, REPO, WORK

parser = argparse.ArgumentParser()
parser.add_argument('group', choices=('serial-recovery', 'stream-recovery', 'handover-preflight',
                                     'handover', 'concurrent', 'pwm-preflight', 'pwm-recovery'))
parser.add_argument('--source', required=True)
parser.add_argument('--build', required=True)
parser.add_argument('--attempt', type=int, default=1)
args = parser.parse_args()
source = args.source
assert re.fullmatch('[0-9a-f]{40}', source) and args.attempt > 0
short = source[:7]
folder = WORK / 't13-s-20260908'
registration = json.loads((folder / 'recovery-builds.json').read_text())
assert registration[args.build]['source'] == source
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd='C:/tr13dev', text=True).strip() == source
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd='C:/tr13dev', text=True).strip()
jobs = []
if args.group == 'serial-recovery':
    for label, mode, cases in (('uart-rx', 2, [2, 3, 4, 5]), ('spi-cancel', 3, [6, 7, 8, 9, 10]),
                               ('twi-cancel', 4, [16, 17, 18, 19]), ('twi-nack', 5, [16, 17, 18, 19])):
        jobs.append((label, ['--phase', 'serial-fault', '--cases', *map(str, cases), '--fault-mode', str(mode), '--fault-role', '1']))
elif args.group == 'stream-recovery':
    for label, mode, role, cases in (('i2s-a', 1, 1, [30]), ('i2s-b', 1, 2, [30]), ('pdm', 2, 1, [28, 29])):
        jobs.append((label, ['--phase', 'stream-fault', '--cases', *map(str, cases),
                            '--stream-fault-mode', str(mode), '--fault-role', str(role)]))
elif args.group.startswith('handover'):
    for instance in (0, 20, 21, 22, 30):
        jobs.append((f'serial{instance}', ['--phase', args.group, '--handover-instance', str(instance)]))
elif args.group.startswith('pwm'):
    phase = 'pwm-recovery-preflight' if args.group == 'pwm-preflight' else 'pwm-recovery'
    for label, mode in (('pwm-unstarted', 2), ('pwm-active', 1)):
        jobs.append((label, ['--phase', phase, '--pwm-recovery-mode', str(mode), '--cases', '25', '26', '27']))
else:
    jobs.append(('c01-c06-c08', ['--phase', 'soak', '--cases', '101', '102', '103', '104', '105', '106', '108']))

checkpoint = folder / f'{args.group}-batch-{short}-attempt{args.attempt}.json'
records = []
with checkpoint.open('x', encoding='utf-8') as stream:
    json.dump({'status': 'starting', 'source': source, 'jobs': jobs}, stream, indent=2)
for index, (label, options) in enumerate(jobs, 1):
    name = f'{label}-{short}-{args.group}-{args.attempt}'
    print(f'T13_BATCH_START group={args.group} job={index}/{len(jobs)} name={name}', flush=True)
    execution = subprocess.run([str(PYTHON), '-X', 'utf8', '-B', str(WORK / 'run_t13_recovery.py'),
        '--build', args.build, '--name', name, *options], cwd=REPO, check=False)
    result_path = folder / name / 'result.json'
    result = json.loads(result_path.read_text()) if result_path.is_file() else {}
    cleanup = [outcome for row in result.get('results', []) if row.get('status') == 'cleanup'
               for outcome in row.get('outcomes', [])]
    passed = execution.returncode == 0 and result.get('status') == 'passed' and cleanup and all(row['stopped'] for row in cleanup)
    records.append({'name': name, 'exit_code': execution.returncode, 'status': result.get('status'),
                    'error': result.get('error'), 'cleanup_proven': bool(cleanup and all(row['stopped'] for row in cleanup)),
                    'finished_at_utc': datetime.now(timezone.utc).isoformat()})
    checkpoint.write_text(json.dumps({'source': source, 'group': args.group,
        'status': 'running' if passed else 'failed', 'jobs': records}, indent=2) + '\n')
    if result_path.is_file() and (WORK / (name + '-execute.json')).is_file():
        archived = subprocess.run([str(PYTHON), '-X', 'utf8', '-B', str(WORK / 'archive_t13_campaign.py'),
            name, f't13-{label}-{args.group}-{short}-attempt{args.attempt}'], cwd=REPO, capture_output=True, text=True)
        if archived.returncode:
            print(archived.stdout + archived.stderr, flush=True)
            raise SystemExit(archived.returncode)
        print(f'T13_BATCH_ARCHIVED {name}', flush=True)
    if not passed:
        raise SystemExit(execution.returncode or 1)
    print(f'T13_BATCH_COMPLETED group={args.group} jobs={index}/{len(jobs)}', flush=True)
checkpoint.write_text(json.dumps({'source': source, 'group': args.group, 'status': 'passed',
                                 'jobs': records}, indent=2) + '\n')
