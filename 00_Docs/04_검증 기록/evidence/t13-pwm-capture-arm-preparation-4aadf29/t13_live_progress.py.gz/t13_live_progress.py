"""! @brief 완결된 반복 result만 집계하고 source가 다른 반복을 합산하지 않습니다. """
import json
import re
from collections import defaultdict
from datetime import datetime, timezone
from check_pc import WORK

folder = WORK / 't13-s-20260908'
counts = defaultdict(list)
state_path = WORK / 'current_common_task_state.json'
families = {
    'serial': (re.compile(r'T13-S/recovery/([^/]+)/mode(\d)/role(\d)/repeat(\d+)/result'),
               'planned_recovery_pass', 21),
    'stream': (re.compile(r'T13-S/stream-recovery/([^/]+)/role(\d)/repeat(\d+)/result'),
               'planned_recovery_pass', 4),
    'pwm': (re.compile(r'T13-S/pwm-recovery/([^/]+)/mode(\d)/repeat(\d+)/result'),
            'planned_pwm_recovery_pass', 6),
}
for campaign in folder.iterdir():
    images = campaign / 'images.json'
    journal = campaign / 'result.json.jsonl'
    if not images.is_file() or not journal.is_file():
        continue
    source = json.loads(images.read_text())[0]['core_revision']
    local = defaultdict(set)
    with journal.open(encoding='utf-8') as stream:
        for line in stream:
            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                continue
            for family, (pattern, flag, _) in families.items():
                match = pattern.fullmatch(row.get('id', ''))
                if match and row.get('status') == 'passed' and row.get(flag):
                    local[(family, *match.groups()[:-1])].add(int(match.groups()[-1]))
    for key, repeats in local.items():
        counts[key].append({'campaign': campaign.name, 'source': source, 'repetitions': len(repeats),
                            'complete': repeats == set(range(1, 101))})
state = json.loads(state_path.read_text())
active = state['active_t13_s']['campaign'].replace('\\', '/').rsplit('/', 1)[-1]
report = {}
for family, (_, _, total) in families.items():
    completed = [{'case': key[1], 'selection': list(key[2:]), **record}
                 for key, records in counts.items() if key[0] == family
                 for record in records if record['complete']]
    unique = {(row['case'], *row['selection']) for row in completed}
    active_counts = [{'case': key[1], 'selection': list(key[2:]), **record}
                     for key, records in counts.items() if key[0] == family
                     for record in records if record['campaign'] == active]
    state['active_t13_s'].update({family + '_recovery_cases_completed': len(unique),
        family + '_recovery_cases_total': total, family + '_recovery_completed': completed})
    report[family] = {'completed': len(unique), 'total': total, 'active': active_counts}
state['active_t13_s']['observed_at_utc'] = datetime.now(timezone.utc).isoformat()
state_path.write_text(json.dumps(state, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(report, indent=2))
