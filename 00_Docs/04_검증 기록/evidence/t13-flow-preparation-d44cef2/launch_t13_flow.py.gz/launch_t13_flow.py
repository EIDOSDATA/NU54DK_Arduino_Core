"""! @brief 등록된 CTS 전용 image를 원래 UID·확인서·CI·실기 배타 검사 뒤 실행합니다. """
from pathlib import Path
helper = Path(__file__).with_name('launch_t13_recovery.py')
source = helper.read_text(encoding='utf-8').replace("Path('C:/tr13dev')", "Path('C:/tsflow04')")
source = source.replace("'recovery-builds.json'", "'flow-builds.json'")
source = source.replace("'pwm-recovery-preflight', 'pwm-recovery'), required=True)",
    "'pwm-recovery-preflight', 'pwm-recovery', 'flow-preflight', 'uart-flow'), required=True)")
assert "'uart-flow'" in source
exec(compile(source, str(helper), 'exec'))
