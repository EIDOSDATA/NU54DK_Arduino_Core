"""! @brief 종료한 QDEC 대비의 실패·독립 계측·정리와 exact source를 대조합니다. """
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import sys

work = Path(__file__).resolve().parent
folder = work / sys.argv[1]
raw = (folder / 'result.json').read_bytes()
result = json.loads(raw)
journal = [json.loads(line) for line in (folder / 'result.json.jsonl').read_text(encoding='utf-8').splitlines()]
assert journal == result['results']
assert result['functional_regression'] is False
assert result['status'] in ('passed', 'failed')
methods = defaultdict(lambda: {'comparisons': 0, 'mismatches': [], 'first_mismatch_snapshots': 0,
                              'max_gpio_poll_us': 0, 'max_sample_gap_us': 0, 'max_read_gap_us': 0,
                              'min_read_sample_age_us': 0xffffffff, 'max_read_sample_age_us': 0,
                              'max_read_wait_us': 0})
cleanup = 0
rows = {row['id']: row for row in result['results']}
for row in result['results']:
    if row['id'].endswith('/cleanup'):
        assert all(outcome['stopped'] for outcome in row['outcomes'])
        cleanup += 1
    if not row['id'].endswith('/comparison'):
        continue
    label = row['id'].rsplit('/', 1)[0]
    method = methods[row['strategy']]
    method['comparisons'] += 1
    assert row['matches'] == (row['actual'] == row['expected'])
    if not row['matches']:
        method['mismatches'].append({'repetition': row['repetition'], 'actual': row['actual']})
    gpio = rows[label + '/before-final-read']['words']
    samples = rows[label + '/samples']['words']
    polling = rows.get(label + '/sample-polling', {}).get('words')
    if polling:
        window = polling[0] + polling[1] + 2
        assert gpio[4] < 256 and window < 256 and samples[3] + window < 512
        assert polling[2] >= samples[2] and polling[2] > 0
    else:
        assert gpio[4] < 128 and samples[3] < 384
    assert gpio[1:4] == [400, 0, 400] and samples[0:2] == [400, 0]
    method['max_gpio_poll_us'] = max(method['max_gpio_poll_us'], gpio[4])
    method['max_sample_gap_us'] = max(method['max_sample_gap_us'], samples[3])
    hardware = rows[label + '/forward/raw-role1']['words']
    method['max_read_gap_us'] = max(method['max_read_gap_us'], hardware[8])
    if any(rows[label + '/diagnostic-page1']['words']):
        method['first_mismatch_snapshots'] += 1
    timing = rows.get(label + '/diagnostic-page6', {}).get('words')
    if timing:
        method['min_read_sample_age_us'] = min(method['min_read_sample_age_us'], timing[0])
        method['max_read_sample_age_us'] = max(method['max_read_sample_age_us'], timing[1])
        method['max_read_wait_us'] = max(method['max_read_wait_us'], timing[2])
    late = rows.get(label + '/late-read', {}).get('words')
    if late:
        method['late_changes'] = method.get('late_changes', 0) + late[0]
        method['max_late_wait_us'] = max(method.get('max_late_wait_us', 0), late[3])
analysis = {'type': result['type'] + '-analysis', 'source': result['core_revision'],
            'status': result['status'], 'functional_regression': False,
            'result_sha256': hashlib.sha256(raw).hexdigest(), 'methods': methods, 'cleanup': cleanup,
            'control_failures': [row for row in result['results'] if row['id'].endswith('/failure')]}
with (work / (folder.name + '-analysis.json')).open('x', encoding='utf-8') as stream:
    json.dump(analysis, stream, indent=2)
print(json.dumps(analysis))
