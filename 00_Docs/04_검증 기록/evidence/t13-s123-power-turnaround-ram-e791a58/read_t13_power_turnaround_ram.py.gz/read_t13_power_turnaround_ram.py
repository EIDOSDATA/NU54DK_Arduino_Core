"""! @brief 정상 debug 분리 뒤 중계 실패의 RAM을 읽기만 합니다. """
from pathlib import Path
helper = Path(__file__).with_name('read_t13_power_debug_ram.py')
source = helper.read_text(encoding='utf-8').replace('C:/tpdbg04/', 'C:/tptrn04/').replace(
    "campaign = 'power-debug-bridge-01'", "campaign = 'power-turnaround-bridge-01'")
exec(compile(source, str(helper), 'exec'))
