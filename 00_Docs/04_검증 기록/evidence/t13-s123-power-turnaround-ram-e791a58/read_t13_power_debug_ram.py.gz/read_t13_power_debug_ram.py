"""! @brief 진단 종료 뒤 power.cpp의 송수신 RAM을 reset 없이 보존합니다. """
import base64
import json
import logging
from datetime import datetime, timezone
from pathlib import Path
import sys
from check_pc import WORK
from elftools.elf.elffile import ELFFile
from pyocd.core.helpers import ConnectHelper
sys.path.insert(0, 'C:/tpdbg04/tests/hil/nu54dk')
import v04_pair as pair
import v04_t13_session as session
from v04_protocol import ProbeLocks
logging.disable(logging.CRITICAL)
folder = WORK/'t13-s-20260908'
campaign = 'power-debug-bridge-01'
images = json.loads((folder/campaign/'images.json').read_text())
grant = json.loads((folder/'session-grant-s123-01.json').read_text())
private = json.loads((folder/'probe-uids-local.json').read_text())
uids = [private[key].lower() for key in grant['uid_sha256']]
session.validate(grant, images, uids)
state = json.loads((WORK/'current_common_task_state.json').read_text())['active_t13_s']
assert not state['hardware_running'] and state['campaign'].replace(chr(92), '/').endswith('/'+campaign)
output = folder/(campaign+'-readonly-01.json')
assert not output.exists()
report = {'source': images[0]['core_revision'], 'observed_at': datetime.now(timezone.utc).isoformat(),
          'reset_performed': False, 'physical_pass_added': False, 'devices': []}
with ProbeLocks(uids):
    for uid, image in zip(uids, images):
        selected = []
        with Path(image['elf']).open('rb') as stream:
            elf = ELFFile(stream)
            owner = ''
            for symbol in elf.get_section_by_name('.symtab').iter_symbols():
                if symbol['st_info']['type'] == 'STT_FILE':
                    owner = symbol.name
                if (owner == 'power.cpp' and symbol['st_info']['type'] == 'STT_OBJECT'
                    and 0x20000000 <= symbol['st_value'] < 0x20040000
                    and 0 < symbol['st_size'] <= 8192):
                    selected.append(symbol)
        assert selected
        with ConnectHelper.session_with_chosen_probe(unique_id=uid, target_override='nrf54l',
                frequency=10000000, blocking=False, no_config=True,
                options={'auto_unlock': False, 'connect_mode': 'attach', 'resume_on_disconnect': False,
                         'cmsis_dap.limit_packets': True}) as connection:
            target = connection.target
            pair.verify_identity(bytes(target.read_memory_block8(image['symbols']['v04_identity'], 64)),
                                 image['role'], image['core_revision'])
            row = {'role': image['role'], 'state': target.get_state().name, 'symbols': []}
            for symbol in selected:
                raw = bytes(target.read_memory_block8(symbol['st_value'], symbol['st_size']))
                row['symbols'].append({'name': symbol.name, 'address': symbol['st_value'],
                    'size': len(raw), 'raw_base64': base64.b64encode(raw).decode(),
                    'scalar': int.from_bytes(raw, 'little') if len(raw) <= 8 else None})
            report['devices'].append(row)
with output.open('x', encoding='utf-8') as stream:
    json.dump(report, stream, indent=2)
print(json.dumps([{'role': row['role'], 'state': row['state'], 'values': {
    symbol['name']: symbol['scalar'] for symbol in row['symbols'] if symbol['scalar'] is not None}}
    for row in report['devices']]))
