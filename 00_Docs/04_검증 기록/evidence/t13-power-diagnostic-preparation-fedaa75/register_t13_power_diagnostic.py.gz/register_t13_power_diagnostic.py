"""! @brief 새 power 진단 symbol과 exact power/일반 target·Host·CI를 모두 검사합니다. """
import json
from pathlib import Path
import re
import sys
from check_pc import WORK
source = sys.argv[1]
assert re.fullmatch('[0-9a-f]{40}', source)
repo = Path('C:/tspdiag')
sys.path.insert(0, str(repo/'tests/hil/nu54dk'))
import v04_pair as pair
import v04_t13_power as power
for family, root in (('t13_power_s', 'C:/t4p06'), ('t13_s', 'C:/t4p07')):
    images = [power.inspect_power_image(repo, Path(root), role) if family == 't13_power_s' else
              pair.inspect_image(repo, Path(root), role, family=family) for role in (1, 2)]
    assert all(image['core_revision'] == source for image in images)
    for image in images:
        config = (image['path'].parent/'.config').read_text()
        assert ('CONFIG_NUCODE_T13_POWER=y' in config) == (family == 't13_power_s')
        if family == 't13_power_s':
            assert 'CONFIG_RETAINED_MEM_NRF_RAM_CTRL=y' in config and 'CONFIG_POWEROFF=y' in config
gates = ['t13-power-diagnostic-exact-'+name+'-01' for name in
         ('target', 'normal-target', 'unit', 'style', 'docs', 'contract')]
assert all(json.loads((WORK/(gate+'.json')).read_text())['exit_code'] == 0 for gate in gates)
ci_name = 'ci-'+source[:7]+'-01'
ci = json.loads((WORK/'t13-s-20260908'/(ci_name+'.json')).read_text())
assert ci['source'] == source
assert any(row['name'] == 'Host unit with Windows PowerShell contracts' and
           row['conclusion'] == 'success' for row in ci['checks'])
path = WORK/'t13-s-20260908/power-diagnostic-builds.json'
assert not path.exists()
path.write_text(json.dumps({'C:/t4p06': {'source': source, 'repository': str(repo),
    'local_gates': gates, 'remote_exact_host': ci_name+'; entire Host PASS',
    'normal_image_regression_build': 'C:/t4p07',
    'scope': 'Original S bridge/timer/GPIO boundaries with frozen first UART error raw; no verdict relaxation'}}, indent=2)+'\n')
print('registered C:/t4p06; no physical access')
