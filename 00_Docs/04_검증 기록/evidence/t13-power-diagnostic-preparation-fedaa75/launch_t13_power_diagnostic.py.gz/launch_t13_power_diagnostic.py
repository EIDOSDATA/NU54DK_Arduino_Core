"""! @brief 고정 S 확인·exact source CI·단일 보드 소유권 뒤에만 power runner를 실행합니다. """
import argparse
import json
import logging
from pathlib import Path
import re
import subprocess
import sys
from check_pc import WORK, SDK

REPOSITORY = Path('C:/tspdiag')
logging.disable(logging.CRITICAL)
sys.path.insert(0, str(REPOSITORY/'tests/hil/nu54dk'))
import v04_pair as pair
import v04_t13_power as runner
import v04_t13_session as session

parser = argparse.ArgumentParser()
parser.add_argument('mode', choices=('preflight', 'execute'))
parser.add_argument('--build', type=Path, required=True)
parser.add_argument('--name', required=True)
parser.add_argument('--phase', choices=('bridge', 'timer', 'gpio'), required=True)
parser.add_argument('--repeats', type=int, choices=(1, 100), default=1)
args = parser.parse_args()
folder = WORK/'t13-s-20260908'
uids = []
try:
    if not re.fullmatch('[a-z0-9][a-z0-9-]+', args.name):
        raise RuntimeError('safe unique campaign name required')
    state_path = WORK/'current_common_task_state.json'
    state = json.loads(state_path.read_text(encoding='utf-8'))
    active = state['active_t13_s']
    if args.mode == 'execute' and any(active.get(key) for key in
        ('hardware_running', 't13_traffic_paused_by_user', 'requires_wiring_repair')):
        raise RuntimeError('another campaign, user pause or unresolved wiring prevents power execution')
    registration = json.loads((folder/'power-diagnostic-builds.json').read_text())
    record = registration[str(args.build.resolve()).replace('\\', '/')]
    images = [runner.inspect_power_image(REPOSITORY, args.build.resolve(), role) for role in (1, 2)]
    if any(image['core_revision'] != record['source'] for image in images):
        raise RuntimeError('registered exact power source mismatch')
    for name in record['local_gates']:
        if json.loads((WORK/(name+'.json')).read_text())['exit_code'] != 0:
            raise RuntimeError('required local gate failed: '+name)
    checks = json.loads(subprocess.check_output(['C:/Program Files/GitHub CLI/gh.exe', 'api',
        'repos/EIDOSDATA/NU54DK_Arduino_Core/commits/'+record['source']+'/check-runs'], cwd=REPOSITORY))['check_runs']
    host = [row for row in checks if row['name'] == 'Host unit with Windows PowerShell contracts']
    latest = max(host, key=lambda row: row['id']) if host else None
    if latest is None or latest['status'] != 'completed' or latest['conclusion'] != 'success':
        raise RuntimeError('successful exact-source remote Host gate required before power execution')
    grant_path = folder/active.get('grant', 'session-grant-repair3.json')
    grant = json.loads(grant_path.read_text())
    private = json.loads((folder/'probe-uids-local.json').read_text())
    uids = [private[key].lower() for key in grant['uid_sha256']]
    session.validate(grant, images, uids)
    output = folder/args.name
    options = ['--dut', uids[0], '--peer', uids[1], '--build-root', str(args.build.resolve()),
        '--pyocd', str(SDK/'opt/bin/Scripts/pyocd.exe'), '--session-grant', str(grant_path),
        '--phase', args.phase, '--repeats', str(args.repeats)]
    if args.mode == 'preflight':
        output.mkdir(exist_ok=False)
        (output/'images.json').write_text(json.dumps(images, indent=2, default=str)+'\n')
        (output/'ci-before-flash.json').write_text(json.dumps({'source': record['source'],
            'checks': [{key: row[key] for key in ('name', 'status', 'conclusion', 'html_url')}
                       for row in checks]}, indent=2)+'\n')
        raise SystemExit(runner.main(options))
    recorded = json.loads((output/'images.json').read_text())
    if [image['sha256'] for image in recorded] != [image['sha256'] for image in images]:
        raise RuntimeError('power images changed after preflight')
    active.update(hardware_running=True, campaign=str(output), phase='power-'+args.phase,
                  source=record['source'], build_root=str(args.build), checkout=str(REPOSITORY))
    state_path.write_text(json.dumps(state, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    try:
        result = runner.main(options+['--execute-fixture', '--evidence', str(output/'result.json')])
    finally:
        state = json.loads(state_path.read_text(encoding='utf-8'))
        state['active_t13_s'].update(hardware_running=False,
            checkpoint='Power campaign ended; inspect cleanup and preserve original before continuing')
        state_path.write_text(json.dumps(state, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    raise SystemExit(result)
except SystemExit:
    raise
except BaseException as error:
    message = f'{type(error).__name__}: {error}'
    for uid in uids:
        message = re.sub(re.escape(uid), '[exact UID redacted]', message, flags=re.IGNORECASE)
    print(message, flush=True)
    raise SystemExit(1)
