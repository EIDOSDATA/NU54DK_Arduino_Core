"""! @brief 기존 TWIM 재검증 뒤 남은 확인 시간에 최초 UART 오류를 보존합니다. """
from pathlib import Path

helper = Path(__file__).with_name('unattended_t13_followups.py')
prefix = helper.read_text(encoding='utf-8').split('\ntry:\n    save()')[0]
prefix = prefix.replace("'unattended-s-followups-01.json'", "'unattended-s-power-diagnostic-01.json'")
prefix = prefix.replace("'waiting-for-current-S-batch'", "'waiting-for-TWIM-provenance-tests'")
exec(compile(prefix, str(helper), 'exec'))

try:
    save()
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.OpenProcess.argtypes = (ctypes.c_uint32, ctypes.c_bool, ctypes.c_uint32)
    kernel.OpenProcess.restype = ctypes.c_void_p
    kernel.WaitForSingleObject.argtypes = (ctypes.c_void_p, ctypes.c_uint32)
    kernel.WaitForSingleObject.restype = ctypes.c_uint32
    kernel.CloseHandle.argtypes = (ctypes.c_void_p,)
    handle = kernel.OpenProcess(0x00100000, False, 10132)
    if not handle:
        raise RuntimeError('original TWIM provenance process handle unavailable')
    try:
        while True:
            result = kernel.WaitForSingleObject(handle, 20000)
            if result == 0:
                break
            if result != 258:
                raise RuntimeError('TWIM provenance process wait failed')
            if time.time() >= grant['expires_at_unix']:
                raise RuntimeError('S confirmation expired while predecessor was running')
    finally:
        kernel.CloseHandle(handle)
    previous = json.loads((folder/'unattended-s-twi-provenance-01.json').read_text())
    if previous['status'] != 'finished-available-twi-provenance-tests':
        raise RuntimeError('previous TWIM queue did not finish with cleanup proven')
    records = json.loads((folder/'power-diagnostic-builds.json').read_text())
    if len(records) != 1:
        raise RuntimeError('one exact power diagnostic registration required')
    build, record = next(iter(records.items()))
    source = record['source']
    bridge = execute('power-bridge-diagnostic-sauto-01', source, 'run_t13_power_diagnostic.py', build,
                     ['--phase', 'bridge'], 120)
    if bridge:
        passed = []
        for phase in ('timer', 'gpio'):
            if execute('power-'+phase+'-diagnostic-preflight-sauto-01', source,
                       'run_t13_power_diagnostic.py', build, ['--phase', phase, '--repeats', '1'], 120):
                passed.append(phase)
        for phase in passed:
            execute('power-'+phase+'-diagnostic-100-sauto-01', source, 'run_t13_power_diagnostic.py', build,
                    ['--phase', phase, '--repeats', '100'], 600)
    else:
        report['dependent_phases'] = 'not-started; normal-mode bridge unqualified or time unavailable'
    report.pop('active', None)
    report['status'] = 'finished-available-power-diagnostics'
    save()
except BaseException as error:
    report.update(status='stopped-requires-review', error=f'{type(error).__name__}: {error}')
    save()
    raise
