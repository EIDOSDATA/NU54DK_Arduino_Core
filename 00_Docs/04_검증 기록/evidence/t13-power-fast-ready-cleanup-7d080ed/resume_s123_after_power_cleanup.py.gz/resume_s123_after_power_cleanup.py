"""! @brief 종료 증거를 대조하고 중계 진단으로 대기 중인 독립 S 조건만 재개합니다. """
import datetime
import json
from check_pc import WORK

folder = WORK / 't13-s-20260908'
cleanup_name = 'power-controller-fast-ready-bridge-01-cleanup-confirmed-resume-01.json'
cleanup = json.loads((folder / cleanup_name).read_text(encoding='utf-8'))
assert cleanup['cleanup_proven'] and not cleanup['flash_or_unlock_performed']
assert {row['role'] for row in cleanup['devices']} == {1, 2}
assert all(row['stopped'] and row['stamp'] == 0x53540004 and row['pin_cnf'] == [0] * 17
           for row in cleanup['devices'])
state = json.loads((WORK / 'current_common_task_state.json').read_text(encoding='utf-8'))
assert not any(state['active_t13_s'].get(key) for key in
               ('hardware_running', 't13_traffic_paused_by_user', 'requires_wiring_repair'))
priority = folder / 's123-priority-diagnostic.json'
assert json.loads(priority.read_text())['owner'] == 'peer-rx-priority'
now = datetime.datetime.now(datetime.timezone.utc).isoformat()
for name in ('peer-rx-priority-01.json', 'power-fast-ready-once-01.json'):
    path = folder / name
    with path.with_suffix('.before-cleanup-review.json').open('xb') as output:
        output.write(path.read_bytes())
    report = json.loads(path.read_text(encoding='utf-8'))
    report.update(status='stopped-with-preserved-failure', reviewed_at=now,
                  later_cleanup=cleanup_name, later_cleanup_proven=True,
                  physical_pass_added=False)
    if 'conditions' in report:
        row = report['conditions'][-1]
        assert row['condition'] == 'parity-c3-r1' and row['status'] == 'running'
        assert not (folder / 'peer-rx-parity-c3-r1-preflight-01').exists()
        row.update(status='not-run', reason='Preceding power diagnostic failed before this condition started')
        report['remaining_parity'] = 'Seven conditions await first-error register diagnostic preparation'
    else:
        report.update(campaign='power-controller-fast-ready-bridge-01', result='failed',
                      original_cleanup_proven=False,
                      reason='Bridge opcode131 timeout and B cleanup NoACK; subsequent controlled resume restored STOP')
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
wrapper = WORK / 'run_t13_peer_rx.py'
text = wrapper.read_text(encoding='utf-8')
start = text.index("if name == 'peer-rx-parity-c3-r1-preflight-01':")
end = text.index('base = ', start)
wrapper.write_text(text[:start] + text[end:], encoding='utf-8')
with (folder / 's123-after-power-cleanup-resume-01.json').open('x', encoding='utf-8') as output:
    json.dump({'resumed_at': now, 'cleanup': cleanup_name,
               'next_condition': 's123-02-break-c3-r1-preflight-01',
               'scope': 'Independent remaining S conditions; no power or already failed unchanged retry',
               'physical_pass_added': False}, output, ensure_ascii=False, indent=2)
priority.unlink()
print('Both-board STOP verified; independent remaining S scheduler released; failed diagnostics preserved', flush=True)
