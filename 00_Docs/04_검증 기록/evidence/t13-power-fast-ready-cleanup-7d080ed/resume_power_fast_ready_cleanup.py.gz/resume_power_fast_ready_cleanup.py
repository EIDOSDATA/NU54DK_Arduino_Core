"""! @brief reset 유지 접속 후 실제 HALTED·부팅 코드 일치를 확인한 B만 재개합니다. """
from pathlib import Path
helper=Path(__file__).with_name('resume_t13_power_pins_cleanup.py')
source=helper.read_text(encoding='utf-8')
anchor="exec(compile(source, str(helper), 'exec'))"
replacement='''source=source.replace('C:/tppin04/','C:/trxof04/').replace(
    "campaign = 'power-pins-bridge-01'", "campaign = 'power-controller-fast-ready-bridge-01'")
exec(compile(source,str(helper),'exec'))'''
assert anchor in source
exec(compile(source.replace(anchor,replacement),str(helper),'exec'))
