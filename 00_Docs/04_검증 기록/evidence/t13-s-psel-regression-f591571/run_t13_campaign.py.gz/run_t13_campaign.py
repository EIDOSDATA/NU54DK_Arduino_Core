"""! @brief 등록된 exact S campaign의 비실기 점검과 명시적 실행 출력을 보존합니다. """
import argparse
import os
from check_pc import PYTHON, WORK, run
parser = argparse.ArgumentParser()
parser.add_argument('--name', required=True)
parser.add_argument('--phase', choices=('preflight', 'soak'), required=True)
parser.add_argument('--cases', type=int, nargs='+', required=True)
parser.add_argument('--build', default='C:/t3m04')
args = parser.parse_args()
base = [PYTHON, '-X', 'utf8', '-B', WORK/'run_ncs.py', 'launch_t13_s.py']
options = ['--build', args.build, '--name', args.name, '--phase', args.phase,
           '--grant', 'session-grant-repair1.json', '--cases', *map(str, args.cases)]
for mode in ('preflight', 'execute'):
    result = run(args.name+'-'+mode, [*base, mode, *options], os.environ.copy())
    if result:
        raise SystemExit(result)
