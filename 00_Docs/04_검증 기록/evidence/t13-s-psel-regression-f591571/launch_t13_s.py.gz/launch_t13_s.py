"""! @brief 확인된 S 세션의 exact image만 사용하며 실패 원본과 현재 실행 상태를 보존합니다. """
import argparse
import json
import logging
import subprocess
from pathlib import Path
import sys

from check_pc import REPO, WORK, SDK
logging.disable(logging.CRITICAL)
sys.path.insert(0, str(REPO/'tests/hil/nu54dk'))
import v04_pair as pair
import v04_t13_run as runner
import v04_t13_session as session

parser = argparse.ArgumentParser()
parser.add_argument('mode', choices=('preflight', 'execute'))
parser.add_argument('--phase', choices=('wiring', 'preflight', 'soak'), default='preflight')
parser.add_argument('--build', type=Path, default=Path('C:/t3e04'))
parser.add_argument('--name', default='preflight-7a33b77-attempt1')
parser.add_argument('--grant', default='session-grant.json')
parser.add_argument('--cases', type=int, nargs='*', default=[*range(2, 24), 101, 102, 103, 104, 105])
args = parser.parse_args()
folder = WORK/'t13-s-20260908'
grant = json.loads((folder/args.grant).read_text(encoding='utf-8'))
private = json.loads((folder/'probe-uids-local.json').read_text(encoding='utf-8'))
uids = [private[key].lower() for key in grant['uid_sha256']]
images = [pair.inspect_image(REPO, args.build, role, family='t13_s') for role in (1, 2)]
if args.build == Path('C:/t3e04'):
    assert images[0]['core_revision'] == '7a33b77f9ed49a671deb2673441c6adc271c6f73'
for name in ('t13-s-full-host-03', 't13-s-contract-01', 't13-s-preparation-style-02',
             't13-s-preparation-docs-02', 't13-s-exact-target-02'):
    assert json.loads((WORK/(name+'.json')).read_text(encoding='utf-8'))['exit_code'] == 0, name
if args.build == Path('C:/t3f04'):
    assert images[0]['core_revision'].startswith('b895f5d')
    for name in ('t13-s-start-fix-host-01', 't13-s-start-fix-style-01',
                 't13-s-start-fix-docs-01', 't13-s-start-fix-target-01'):
        assert json.loads((WORK/(name+'.json')).read_text(encoding='utf-8'))['exit_code'] == 0, name
elif args.build in (Path('C:/t3i04'), Path('C:/t3m04'), Path('C:/t3o04')):
    if args.build == Path('C:/t3i04'):
        assert images[0]['core_revision'] == '3f990da9290fb3c515d4c082989ec2b483e55e48'
        gates = ('t13-s-stream-exact-target-01', 't13-s-stream-style-01',
                 't13-s-stream-docs-01', 't13-s-stream-contract-01')
    elif args.build == Path('C:/t3m04'):
        assert images[0]['core_revision'] == 'a6367caf42578d8dd825186d229cfa902a82a562'
        gates = ('t13-s-general-clock-exact-target-01', 't13-s-general-clock-style-01',
                 't13-s-general-clock-docs-02', 't13-s-general-clock-host-01')
    else:
        assert images[0]['core_revision'] == 'f5915719188774442f1b93662a769145c5a0778c'
        gates = ('t13-psel-exact-target-01', 't13-psel-style-01', 't13-psel-docs-02',
                 't13-psel-runtime-host-02', 't13-psel-uart-host-01', 't13-psel-contract-01',
                 't13-psel-inventory-01')
    for name in gates:
        assert json.loads((WORK/(name+'.json')).read_text(encoding='utf-8'))['exit_code'] == 0, name
    checks = json.loads(subprocess.check_output(['C:/Program Files/GitHub CLI/gh.exe', 'api',
        'repos/EIDOSDATA/NU54DK_Arduino_Core/commits/'+images[0]['core_revision']+'/check-runs'], cwd=REPO))['check_runs']
    host = [row for row in checks if row['name'] == 'Host unit with Windows PowerShell contracts']
    assert len(host) == 1 and host[0]['status'] == 'completed' and host[0]['conclusion'] == 'success', 'Exact remote Host gate required'
    ci_observation = {'source': images[0]['core_revision'], 'checks':
        [{key: row[key] for key in ('name', 'status', 'conclusion', 'html_url')} for row in checks]}
elif args.build == Path('C:/t3k04'):
    assert images[0]['core_revision'] == '8966da5571464dcb55503eb3d0129f93311d008d'
    for name in ('t13-s-pwm-clock-host-01', 't13-s-pwm-clock-full-host-01',
                 't13-s-pwm-clock-style-01', 't13-s-pwm-clock-docs-02',
                 't13-s-pwm-clock-exact-target-01'):
        assert json.loads((WORK/(name+'.json')).read_text(encoding='utf-8'))['exit_code'] == 0, name
elif args.build != Path('C:/t3e04'):
    raise RuntimeError('unregistered exact build gate set')
session.validate(grant, images, uids)
output = folder/args.name
base = ['--dut', uids[0], '--peer', uids[1], '--build-root', str(args.build),
        '--pyocd', str(SDK/'opt/bin/Scripts/pyocd.exe'), '--session-grant', str(folder/args.grant),
        '--phase', args.phase, '--cmsis-dap-limit-packets']
if args.cases:
    base += ['--cases', *map(str, args.cases)]
try:
    if args.mode == 'preflight':
        output.mkdir(exist_ok=False)
        with (output/'images.json').open('x', encoding='utf-8') as stream:
            json.dump(images, stream, indent=2, default=str)
        if args.build in (Path('C:/t3i04'), Path('C:/t3m04'), Path('C:/t3o04')):
            with (output/'ci-before-flash.json').open('x', encoding='utf-8') as stream:
                json.dump(ci_observation, stream, indent=2)
        raise SystemExit(runner.main(base))
    assert (output/'images.json').is_file()
    state_path = WORK/'current_common_task_state.json'
    state = json.loads(state_path.read_text(encoding='utf-8'))
    state['active_t13_s'].update(hardware_running=True, campaign=str(output), phase=args.phase,
        source=images[0]['core_revision'], build_root=str(args.build))
    state_path.write_text(json.dumps(state, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    try:
        code = runner.main(base + ['--execute-fixture', '--evidence', str(output/'result.json')])
    finally:
        state = json.loads(state_path.read_text(encoding='utf-8'))
        state['active_t13_s'].update(hardware_running=False, checkpoint='Campaign ended; inspect result and cleanup before next run')
        state_path.write_text(json.dumps(state, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    raise SystemExit(code)
except SystemExit:
    raise
except BaseException as error:
    message = f'{type(error).__name__}: {error}'
    for uid in uids:
        message = message.replace(uid, '[exact UID redacted]')
    print(message, flush=True)
    raise SystemExit(1)
