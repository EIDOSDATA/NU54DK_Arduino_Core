"""! @brief I2S 최종 원본의 Cartesian 누락·중복·양 역할·cleanup과 측정량을 감사합니다. """
import collections
import datetime
import hashlib
import itertools
import json
from check_pc import WORK

folder = WORK / 'common-i2s-hardware-b5c86a4'
raw = (folder / 'result.json').read_bytes()
campaign = json.loads(raw)
assert campaign['status'] == 'passed'
assert campaign['core_revision'] == 'b5c86a49d2a2161fe5fa137609ed78a18e2925b7'
journal = [json.loads(line) for line in (folder / 'result.json.jsonl').read_text(encoding='utf-8').splitlines()]
assert campaign['results'] == journal
expected = {'V04-COMMON-I2S/' + '/'.join(map(str, vector)) for vector in
            itertools.product((1, 2), (16000, 48000), (8, 16, 24, 32), range(3), (32, 256, 1024), (1, 2, 3))}
passed = [row for row in journal if row.get('status') == 'passed' and row['id'].startswith('V04-COMMON-I2S/')]
assert len(passed) == len(expected) == 432
assert {row['id'] for row in passed} == expected
indexed = {row['id']: row for row in journal}
totals = collections.Counter()
max_queue = 0
max_rate_error = 0
for row in passed:
    vector = list(map(int, row['id'].split('/')[1:]))
    master, rate, width, channels, words, direction = vector
    cleanup = indexed[row['id'] + '/cleanup']
    assert {item['role'] for item in cleanup['outcomes']} == {1, 2}
    assert all(item['stopped'] and item['words'][6] == 1 for item in cleanup['outcomes'])
    assert {item['role'] for item in row['results']} == {1, 2}
    for item in row['results']:
        record = indexed[row['id'] + '/raw-role' + str(item['role'])]
        assert record['vector'] == vector
        assert len(record['buffers']) == 104
        assert [buffer[0] for buffer in record['buffers']] == list(range(104))
        assert item['verified_buffers'] == 104 and item['measured_buffers'] == 100
        assert record['words'][5:7] == [0, 1] and record['words'][11] == 0
        totals['verified_dma_completions'] += 104
        totals['measured_dma_completions'] += 100
        totals['samples_compared'] += item['samples_compared']
        totals['receive_buffers'] += 104 * int(item['receive_dma_enabled'])
        totals['tail_completions_excluded'] += item['tail_completions_at_observation']
        max_queue = max(max_queue, item['max_queue_us'])
        nominal = 99 * words * (32 // width if width <= 16 else 1) * 1e6 / (rate * (2 if channels == 0 else 1))
        deviation = abs(item['completion_span_us'] - nominal) / nominal * 100
        assert deviation <= 5
        max_rate_error = max(max_rate_error, deviation)
report = {'observed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'source': campaign['core_revision'], 'result_sha256': hashlib.sha256(raw).hexdigest(),
          'status': 'passed', 'unique_vectors': 432, 'cleanup': 432, 'roles_per_vector': 2,
          'metrics': dict(totals), 'max_queue_us': max_queue, 'max_completion_rate_deviation_percent': max_rate_error,
          'whole_t12_complete': False, 't13_physical_executed': False}
with (WORK / 'common-i2s-b5c86a4-completion-audit.json').open('x', encoding='utf-8') as stream:
    json.dump(report, stream, ensure_ascii=False, indent=2)
print(json.dumps(report, ensure_ascii=False))
