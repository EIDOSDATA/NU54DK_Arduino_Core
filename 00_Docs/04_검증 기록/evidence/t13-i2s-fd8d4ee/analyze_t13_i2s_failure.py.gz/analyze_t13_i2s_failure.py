"""! @brief I2S 실패 페이지의 전체 DMA를 독립 Host 기대값으로 검증합니다. """
import json
import sys
from pathlib import Path
from check_pc import WORK
sys.path.insert(0,'C:/tr13dev/tests/hil/nu54dk')
import v04_t13_oracle as oracle
folder=WORK/'t13-s-20260908/i2s-fd8d4ee-diagnostic1'
result=json.loads((folder/'result.json').read_text())
rows={row['id']:row for row in result['results']}
prefix='T13-S/soak/i2s20'
seed=rows[prefix+'/input']['seed']
words=rows[prefix+'/failure/role1/i2s-failure-page0']['words']
buffer=[]
for page in range(1,17):
    buffer += rows[prefix+f'/failure/role1/i2s-failure-page{page}']['words']
report=oracle.i2s_failure(words,buffer,seed,1)
with (folder.parent/'i2s-fd8d4ee-diagnostic1-analysis-01.json').open('x',encoding='utf-8') as stream:
    json.dump(report,stream,indent=2)
print(json.dumps({'report_keys':list(report),'mismatch_count':len(report['mismatches']),
                  'first':report['mismatches'][0],'last':report['mismatches'][-1],
                  'zero_words':sum(value==0 for value in buffer)}))
