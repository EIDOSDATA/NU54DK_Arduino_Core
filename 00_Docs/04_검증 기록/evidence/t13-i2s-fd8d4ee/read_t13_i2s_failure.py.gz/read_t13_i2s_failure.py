"""! @brief I2S 실패 뒤 양쪽 송수신 slot과 oracle RAM을 재설정 없이 보존합니다. """
import base64
from datetime import datetime, timezone
import json
import logging
from pathlib import Path
import sys
from check_pc import REPO, WORK
from elftools.elf.elffile import ELFFile
from pyocd.core.helpers import ConnectHelper
sys.path.insert(0,str(REPO/'tests/hil/nu54dk'))
import v04_pair as pair
from v04_protocol import ProbeLocks
logging.disable(logging.CRITICAL)
folder=WORK/'t13-s-20260908'
images=json.loads((folder/'i2s-fd8d4ee-diagnostic1/images.json').read_text())
grant=json.loads((folder/'session-grant-repair1.json').read_text())
private=json.loads((folder/'probe-uids-local.json').read_text())
uids=[private[key].lower() for key in grant['uid_sha256']]
output=folder/'i2s-fd8d4ee-diagnostic1-readonly-01.json'
assert not output.exists()
assert not json.loads((WORK/'current_common_task_state.json').read_text())['active_t13_s']['hardware_running']
result={'type':'read-only-stopped-i2s-ram','source':images[0]['core_revision'],
        'observed_utc':datetime.now(timezone.utc).isoformat(),'devices':[]}
with ProbeLocks(uids):
    for uid,image in zip(uids,images):
        with Path(image['elf']).open('rb') as stream:
            elf=ELFFile(stream)
            symbols=[s for s in elf.get_section_by_name('.symtab').iter_symbols() if s['st_size'] and
                s['st_info']['type']=='STT_OBJECT' and any(s.name.endswith(end) for end in
                    ('2txE','2rxE','6oracleE','7seed_txE','7pendingE','11failed_slotE','12stream_statsE'))]
        with ConnectHelper.session_with_chosen_probe(unique_id=uid,target_override='nrf54l',frequency=10000000,
                blocking=False,no_config=True,options={'auto_unlock':False,'connect_mode':'attach',
                'resume_on_disconnect':False,'cmsis_dap.limit_packets':True}) as connection:
            target=connection.target
            pair.verify_identity(bytes(target.read_memory_block8(image['symbols']['v04_identity'],64)),image['role'],image['core_revision'])
            row={'role':image['role'],'state':target.get_state().name,'symbols':[]}
            for symbol in symbols:
                raw=bytes(target.read_memory_block8(symbol['st_value'],symbol['st_size']))
                row['symbols'].append({'name':symbol.name,'address':symbol['st_value'],'size':symbol['st_size'],
                                       'raw_base64':base64.b64encode(raw).decode()})
            result['devices'].append(row)
with output.open('x',encoding='utf-8') as stream:
    json.dump(result,stream,indent=2)
print(json.dumps([{'role':row['role'],'state':row['state'],
                  'symbols':[{k:v for k,v in sym.items() if k!='raw_base64'} for sym in row['symbols']]}
                 for row in result['devices']]))
