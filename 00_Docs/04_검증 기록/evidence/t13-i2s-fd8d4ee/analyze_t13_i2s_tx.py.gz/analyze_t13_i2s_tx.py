"""! @brief 실패 뒤 보존된 peer TX 세 slot을 해당 전역 frame 기대값과 대조합니다. """
import base64
import json
import sys
from check_pc import WORK
sys.path.insert(0,'C:/tr13dev/tests/hil/nu54dk')
from v04_common_i2s import pattern
folder=WORK/'t13-s-20260908'
data=json.loads((folder/'i2s-fd8d4ee-diagnostic1-readonly-01.json').read_text())
reports=[]
for device in data['devices']:
    symbols=device['symbols']
    tx=base64.b64decode(next(s['raw_base64'] for s in symbols if s['name'].endswith('2txE')))
    seed=int.from_bytes(base64.b64decode(next(s['raw_base64'] for s in symbols if s['name'].endswith('7seed_txE'))),'little')
    slots=[]
    for frame in (4207,4208,4209):
        slot=frame%3
        raw=tx[slot*1056+16:slot*1056+1040]
        words=[int.from_bytes(raw[i:i+4],'little') for i in range(0,1024,4)]
        mismatches=[i for i,word in enumerate(words) if word!=pattern(seed,frame*256+i)]
        slots.append({'frame':frame,'slot':slot,'mismatch_offsets':mismatches,'zero_words':words.count(0)})
    reports.append({'role':device['role'],'seed':seed,'slots':slots})
with (folder/'i2s-fd8d4ee-diagnostic1-tx-analysis-01.json').open('x',encoding='utf-8') as stream:
    json.dump(reports,stream,indent=2)
print(json.dumps(reports))
