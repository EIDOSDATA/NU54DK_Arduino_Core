"""! @brief S P1.04/05와 P2.05 세 선의 방향별 LOW 전달과 관측 소요 시간을 분리합니다. """
from contextlib import ExitStack
import json
import logging
from pathlib import Path
import sys
import time

from check_pc import WORK, SDK
REPO = Path('C:/tr13dev')
logging.disable(logging.CRITICAL)
sys.path.insert(0, str(REPO/'tests/hil/nu54dk'))
import v04_pair as pair
import v04_t13_session as session
import v04_wiring as wiring
from v04_protocol import ProbeLocks
from pyocd.core.helpers import ConnectHelper

folder = WORK/'t13-s-20260908'
grant = json.loads((folder/'session-grant-repair3.json').read_text(encoding='utf-8'))
private = json.loads((folder/'probe-uids-local.json').read_text(encoding='utf-8'))
uids = [private[key].lower() for key in grant['uid_sha256']]
images = [pair.inspect_image(REPO, Path('C:/t4c04'), role, family='t13_s') for role in (1, 2)]
session.validate(grant, images, uids)
original = json.loads((folder/'uart-tx-43bc032-repair3-preflight1/result.json').read_text(encoding='utf-8'))
assert original['status'] == 'failed' and 'wiring mismatch' in original['error']
assert all(image['core_revision'] == '43bc0320d6681d57d2ec1cd569fef35f7dd8ec0d' for image in images)
evidence = {'type': 'T13-S-repair3-P105-P205-direction-timing-diagnostic', 'core_revision': images[0]['core_revision'],
            'functional_or_soak_pass': False, 'swd_frequency_hz': 10000000, 'results': []}
output = folder/'repair3-direction-timing-attempt1.json'
with pair.evidence_session(output, evidence) as journal:
    def append(identifier, result):
        row = {'id': identifier, **result}
        evidence['results'].append(row)
        journal.write(json.dumps(row)+'\n')
        journal.flush()
    with ProbeLocks(uids), ExitStack() as stack:
        devices = []
        for uid, image in zip(uids, images):
            session.validate(grant, images, uids)
            device, metadata = pair.boot_exact(stack, ConnectHelper, SDK/'opt/bin/Scripts/pyocd.exe',
                uid, image, 10000000, cmsis_dap_limit_packets=True)
            devices.append(device)
            session.verify_profile(device)
            append(f'boot/role{image["role"]}', {'flash': metadata})
        for controller_role in (1, 2):
            session.validate(grant, images, uids)
            controller = devices[controller_role-1]
            label = f'controller{controller_role}'
            try:
                for device in devices:
                    assert device.command(48, (501, 1, 0x53414645, controller_role), timeout=2) == [501, 10000, 17]
                for net in (2, 3, 15):
                    for repetition in range(2):
                        for device in devices:
                            assert device.command(53, timeout=2) == [0]
                        began = time.monotonic()
                        assert controller.command(50, (net,), timeout=2) == [net, 500]
                        for sample in range(3):
                            for device in devices:
                                before = time.monotonic()
                                words = device.command(51, timeout=2)
                                after = time.monotonic()
                                try:
                                    wiring.observed(words, low=net, controller=device.image['role']==controller_role)
                                    difference = None
                                except Exception as error:
                                    difference = str(error)
                                append(f'{label}/net{net}/rep{repetition}/sample{sample}/role{device.image["role"]}',
                                    {'status': 'observation', 'words': words, 'difference': difference,
                                     'after_pulse_ms': (after-began)*1000, 'read_ms': (after-before)*1000})
                            time.sleep(.025)
                        assert controller.command(52, timeout=2) == [0]
                        time.sleep(.01)
            finally:
                assert wiring.stop_pair(devices, append, label+'/cleanup')
        evidence['postflight'] = []
        bases = {0: 0x5010A000, 1: 0x500D8200, 2: 0x50050400}
        for device in devices:
            image = device.image
            raw = bytes(device.target.read_memory_block8(image['symbols']['v04_identity'], 64))
            pair.verify_identity(raw, image['role'], image['core_revision'])
            configuration = {}
            for pin in session.plan.harness('S'):
                port, index = int(pin[1]), int(pin[3:])
                configuration[pin] = device.target.read32(bases[port]+0x80+index*4)
            evidence['postflight'].append({'role': image['role'], 'state': device.target.get_state().name,
                                          'pin_cnf': configuration})
            assert all(value & 1 == 0 for value in configuration.values())
differences = [row for row in evidence['results'] if row.get('difference')]
print('Diagnostic complete; mismatching snapshots=' + str(len(differences)) + '; GPIO inputs restored')
for direction in (1, 2):
    for net in (2, 3, 15):
        rows = [row for row in evidence['results'] if row['id'].startswith(f'controller{direction}/net{net}/')]
        print(f'controller={direction} net={net} mismatches={sum(bool(row.get("difference")) for row in rows)}/{len(rows)}')
