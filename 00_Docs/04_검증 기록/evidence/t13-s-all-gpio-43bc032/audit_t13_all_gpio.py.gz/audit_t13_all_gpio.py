"""! @brief 현재 S의 모든 17개 net을 양방향·시간별로 전수 진단하고 실패도 끝까지 보존합니다. """
from contextlib import ExitStack
from datetime import datetime, timezone
import hashlib
import json
import logging
from pathlib import Path
import re
import sys
import time

from check_pc import WORK, SDK
REPO = Path('C:/tr13dev')
sys.path.insert(0, str(REPO / 'tests/hil/nu54dk'))
import v04_pair as pair
import v04_t13_session as session
import v04_wiring as wiring
from v04_protocol import ProbeLocks, ProtocolError
from pyocd.core.helpers import ConnectHelper

logging.disable(logging.CRITICAL)
FOLDER = WORK / 't13-s-20260908'
OUTPUT = FOLDER / 'all-gpio-audit-43bc032-attempt2.json'
BASES = {0: 0x5010A000, 1: 0x500D8200, 2: 0x50050400}
UIDS = []


def raw_ports(device, mapping, net):
    """! @brief SDK GPIO 구조체의 IN/OUT/DIR/PIN_CNF를 halt나 register 쓰기 없이 읽습니다. """
    began = time.monotonic()
    ports = {port: device.target.read32(base + 0x0C) for port, base in BASES.items()}
    mask = 0
    for index, gpio in enumerate(mapping):
        port, pin = int(gpio[1]), int(gpio[3:])
        mask |= ((ports[port] >> pin) & 1) << index
    gpio = mapping[net]
    port, pin = int(gpio[1]), int(gpio[3:])
    return {'pins': mapping, 'net_level_mask': mask, 'port_in': ports,
        'selected_gpio': gpio, 'selected_out': (device.target.read32(BASES[port]) >> pin) & 1,
        'selected_direction': (device.target.read32(BASES[port] + 0x10) >> pin) & 1,
        'selected_pin_cnf': device.target.read32(BASES[port] + 0x80 + 4 * pin),
        'read_elapsed_ms': (time.monotonic() - began) * 1000}


def main():
    """! @brief 승인된 S 단일 open-drain LOW만 사용하고 T13 통신·복구는 재개하지 않습니다. """
    global UIDS
    grant = json.loads((FOLDER / 'session-grant-repair3.json').read_text())
    private = json.loads((FOLDER / 'probe-uids-local.json').read_text())
    UIDS = [private[key].lower() for key in grant['uid_sha256']]
    images = [pair.inspect_image(REPO, Path('C:/t4c04'), role, family='t13_s') for role in (1, 2)]
    session.validate(grant, images, UIDS)
    if any(image['core_revision'] != '43bc0320d6681d57d2ec1cd569fef35f7dd8ec0d' for image in images):
        raise ProtocolError('registered exact GPIO audit source required')
    state_path = WORK / 'current_common_task_state.json'
    state = json.loads(state_path.read_text())
    if state['active_t13_s']['hardware_running']:
        raise ProtocolError('another hardware process is active')
    state['active_t13_s'].update(hardware_running=True, phase='all-gpio-audit', campaign=str(OUTPUT),
        checkpoint='User paused T13 and requested all GPIO audit; single open-drain only',
        t13_traffic_paused_by_user=True, pending_user_action=None)
    state_path.write_text(json.dumps(state, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    mapping = session.plan.harness('S')
    pins = {1: list(mapping), 2: list(mapping.values())}
    mismatches = []
    completed = 0
    evidence = {'type': 'T13-S-all-GPIO-audit', 'core_revision': images[0]['core_revision'],
        'started_at_utc': datetime.now(timezone.utc).isoformat(), 'swd_frequency_hz': 10000000,
        'user_scope': 'Pause protocol HIL; inspect every currently wired S GPIO',
        'uid_sha256': [hashlib.sha256(uid.encode()).hexdigest() for uid in UIDS],
        'images': json.loads(json.dumps(images, default=str)), 'mapping': mapping, 'planned_pulses': 340, 'repetitions_per_direction': 10,
        'sample_delays_seconds': [0.005, 0.050, 0.150], 'functional_or_soak_pass': False,
        'direct_reads_are_not_simultaneous': True, 'results': []}
    try:
        with pair.evidence_session(OUTPUT, evidence) as journal:
            def append(identifier, row):
                entry = {'id': identifier, **row}
                evidence['results'].append(entry)
                journal.write(json.dumps(entry, ensure_ascii=False) + '\n')
                journal.flush()

            def observe(devices, label, controller_role, net, low, began, direct=False):
                expected = wiring.MASK ^ (1 << net) if low else wiring.MASK
                for device in devices:
                    role = device.image['role']
                    before = time.monotonic()
                    words = device.command(51, timeout=2)
                    difference = None
                    try:
                        wiring.observed(words, low=net if low else None,
                            controller=role == controller_role)
                    except ProtocolError as error:
                        difference = str(error)
                    row = {'status': 'observation', 'words': words, 'difference': difference,
                        'expected_level_mask': expected, 'after_pulse_ms': (time.monotonic() - began) * 1000,
                        'command_elapsed_ms': (time.monotonic() - before) * 1000}
                    append(label + f'/firmware/role{role}', row)
                    if difference:
                        mismatches.append({'id': label + f'/firmware/role{role}', **row})
                    # @brief 전압값 불일치는 계속 기록하지만 방향·소유권·만료 이상은 즉시 중단합니다.
                    checked = words[:]
                    checked[0] = expected
                    wiring.observed(checked, low=net if low else None, controller=role == controller_role)
                    if direct:
                        raw = raw_ports(device, pins[role], net)
                        raw.update(status='direct-observation', after_pulse_ms=(time.monotonic() - began) * 1000,
                            expected_level_mask=expected, difference=raw['net_level_mask'] != expected)
                        append(label + f'/direct/role{role}', raw)
                        if raw['difference']:
                            mismatches.append({'id': label + f'/direct/role{role}', **raw})

            with ProbeLocks(UIDS), ExitStack() as stack:
                def available():
                    return {probe.unique_id.lower() for probe in ConnectHelper.get_all_connected_probes(blocking=False)}
                if not set(UIDS).issubset(available()):
                    raise ProtocolError('both exact probes required before GPIO audit')
                devices = []
                for uid, image in zip(UIDS, images):
                    device, flash = pair.boot_exact(stack, ConnectHelper, SDK / 'opt/bin/Scripts/pyocd.exe',
                        uid, image, 10000000, cmsis_dap_limit_packets=True)
                    devices.append(device)
                    session.verify_profile(device)
                    append(f'boot/role{image["role"]}', {'status': 'observation', 'flash': flash})
                continuity = session.Continuity(grant, images, UIDS, devices, available, pair.verify_identity)
                for controller_role in (1, 2):
                    controller = devices[controller_role - 1]
                    root = f'all-gpio/controller{controller_role}'
                    try:
                        continuity.check()
                        for device in devices:
                            if device.command(48, (501, 1, 0x53414645, controller_role), timeout=2) != [501, 10000, 17]:
                                raise ProtocolError('GPIO audit arm failed')
                        for repetition in range(1, 11):
                            continuity.check()
                            for net in range(17):
                                label = root + f'/repeat{repetition:02}/net{net + 1:02}'
                                for device in devices:
                                    if device.command(53, timeout=2) != [0]:
                                        raise ProtocolError('GPIO audit lease renewal failed')
                                began = time.monotonic()
                                if controller.command(50, (net,), timeout=2) != [net, 500]:
                                    raise ProtocolError('GPIO audit LOW response mismatch')
                                for sample, delay in enumerate((0.005, 0.050, 0.150)):
                                    time.sleep(max(0, began + delay - time.monotonic()))
                                    observe(devices, label + f'/low{sample}', controller_role, net, True, began,
                                        direct=sample == 0)
                                if controller.command(52, timeout=2) != [0]:
                                    raise ProtocolError('GPIO audit release failed')
                                time.sleep(0.005)
                                observe(devices, label + '/released', controller_role, net, False, began)
                                completed += 1
                            print(f'GPIO_AUDIT_PROGRESS {completed}/340 ({completed/340:.0%}); mismatching observations={len(mismatches)}', flush=True)
                    finally:
                        if not wiring.stop_pair(devices, append, root + '/cleanup'):
                            raise ProtocolError('GPIO audit STOP unproven')
                evidence['postflight'] = []
                for device in devices:
                    role = device.image['role']
                    configuration = {gpio: device.target.read32(BASES[int(gpio[1])] + 0x80 + 4 * int(gpio[3:]))
                        for gpio in pins[role]}
                    evidence['postflight'].append({'role': role, 'pin_cnf': configuration,
                        'state': device.target.get_state().name})
                    if any(value & 1 for value in configuration.values()):
                        raise ProtocolError('GPIO audit final output remains')
                evidence.update(scan_completed=True, completed_pulses=completed,
                    mismatch_count=len(mismatches), mismatches=mismatches)
                if mismatches:
                    raise ProtocolError(f'GPIO audit completed with {len(mismatches)} mismatching observations')
    finally:
        state = json.loads(state_path.read_text())
        state['active_t13_s'].update(hardware_running=False, t13_traffic_paused_by_user=True,
            checkpoint='All-GPIO audit ended; inspect full matrix and both STOP; do not resume protocol HIL')
        state_path.write_text(json.dumps(state, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        print(json.dumps({'evidence': str(OUTPUT), 'completed_pulses': completed,
            'mismatching_observations': len(mismatches), 'protocol_hil_resumed': False}))


if __name__ == '__main__':
    try:
        main()
    except BaseException as error:
        message = f'{type(error).__name__}: {error}'
        for uid in UIDS:
            message = re.sub(re.escape(uid), '[exact UID redacted]', message, flags=re.IGNORECASE)
        print(message, flush=True)
        raise SystemExit(1)
