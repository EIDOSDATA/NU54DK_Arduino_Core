"""! @brief 감시점 원본의 정상 설정·오류 queue·DMA·핀·CPU 상태를 대조합니다. """
import json
import struct
from check_pc import WORK

folder = WORK / 't13-s-20260908'
result = json.loads((folder / 'uart20-a-first-error-watch-01/result.json').read_text())
rows = result['results']
captures = [row for row in rows if '/debug/capture/' in row['id']]
assert len(captures) == 2
summary = {'source': result['core_revision'], 'diagnostic_only': True, 'physical_pass_added': False,
           'watch': next(row for row in rows if '/debug/watch-hit' in row['id']), 'devices': []}
for row in captures:
    role = int(row['id'][-1])
    before = [item for item in rows if '/debug/armed/role' + str(role) in item['id']][-1]
    layout = before['layout']
    lane = bytes.fromhex(row['ram']['lanes']['bytes_hex'])
    contexts = bytes.fromhex(row['ram']['contexts']['bytes_hex'])
    size = layout['structs']['UarteContext']['size']
    context = contexts[size:2 * size]
    offsets = layout['structs']['UarteContext']['fields']
    words = lambda data, offset, count: list(struct.unpack_from('<' + str(count) + 'I', data, offset))
    queue = [words(context, offsets['events'] + index * 16, 4) for index in range(8)]
    lane_fields = layout['structs']['Lane']['fields']
    regs = row['registers']
    selected = {name: value for name, value in regs.items() if name.startswith(('UARTE20.', 'CLOCK.')) or
                name in ('P1.IN', 'P1.OUT', 'P1.DIR', 'P1.PIN_CNF[4]', 'P1.PIN_CNF[5]', 'P1.PIN_CNF[6]', 'P1.PIN_CNF[7]')}
    item = {'role': role, 'id': row['id'], 'before_start': before['normal_uart_config'],
            'cpu': row['cpu'], 'scb': row['scb'], 'lane_error_and_detail': words(lane, lane_fields['error'], 2),
            'lane_active': lane[lane_fields['active']], 'tx_pending': list(lane[lane_fields['tx_pending']:lane_fields['tx_pending'] + 2]),
            'rx_pending': list(lane[lane_fields['rx_pending']:lane_fields['rx_pending'] + 2]),
            'sent': words(lane, lane_fields['sent'], 12), 'received': words(lane, lane_fields['received'], 12),
            'configuration': words(context, offsets['configuration'], 2),
            'queue_indices_count_overflow': list(context[offsets['event_head']:offsets['event_head'] + 4]),
            'event_slots': queue, 'active_tx_rx_cancelling': words(context, offsets['active'], 4),
            'registers': selected}
    summary['devices'].append(item)
with (folder / 'uart20-a-first-error-watch-analysis-01.json').open('x', encoding='utf-8') as output:
    json.dump(summary, output, indent=2)
print(json.dumps(summary))
