"""! @brief 정지 시 DMA RAM 전체와 독립 pattern을 프레임 단위로 대조합니다. """
import json
import struct
import sys
from check_pc import WORK
sys.path.insert(0, 'C:/trxof04/tests/hil/nu54dk')
import v04_t13_oracle as oracle

folder = WORK / 't13-s-20260908'
result = json.loads((folder / 'uart20-a-first-error-watch-01/result.json').read_text())
rows = [row for row in result['results'] if '/debug/capture/' in row['id']]
output = {'source': result['core_revision'], 'physical_pass_added': False, 'diagnostic_only': True, 'devices': []}
for row in rows:
    raw = bytes.fromhex(row['ram']['lanes']['bytes_hex'])
    seeds = struct.unpack_from('<2I', raw, 4680)
    current = {'role': int(row['id'][-1]), 'buffers': [],
               'first_data_fault': oracle.serial_data_fault(list(struct.unpack_from('<20I', raw, 4728)))}
    for direction, start, seed, counter in (('tx', 64, seeds[0], 4328), ('rx', 2176, seeds[1], 4376)):
        completed = struct.unpack_from('<I', raw, counter)[0]
        for slot in range(2):
            data = raw[start + slot * 1056 + 16:start + slot * 1056 + 16 + 1024]
            comparisons = []
            for frame in range(max(0, completed - 4), completed + 5):
                expected = bytes(oracle.pattern(seed, frame * 1024 + index) for index in range(1024))
                differences = sum(actual != wanted for actual, wanted in zip(data, expected))
                comparisons.append({'frame': frame, 'different_bytes': differences})
            current['buffers'].append({'direction': direction, 'slot': slot, 'completed_frames': completed,
                                       'comparisons': comparisons})
    output['devices'].append(current)
with (folder / 'uart20-a-first-error-watch-buffer-analysis-01.json').open('x', encoding='utf-8') as stream:
    json.dump(output, stream, indent=2)
print(json.dumps(output))
