"""! @brief 기존 실패 원본에서 CTS 증명·완료 간격을 읽기 전용 대조합니다. """
import json
from pathlib import Path
import sys
from datetime import datetime, timezone

repo = Path('C:/Users/eidos/GitHub/NU54DK_Arduino_Core')
sys.path.insert(0, str(repo/'tests/hil/nu54dk'))
import v04_t13_flow as flow
folder = Path(__file__).parent/'t13-s-20260908'
output = folder/'cts-gap-analysis-2058-01.json'
assert not output.exists()
report = {'observed_at_utc': datetime.now(timezone.utc).isoformat(), 'physical_access': False,
          'existing_verdicts_changed': False, 'fresh_physical_qualification': False, 'cases': []}
for path in sorted(folder.glob('flow*-preflight-sauto-01/result.json')):
    data = json.loads(path.read_text())
    rows = data['results']
    inputs = next(row for row in rows if '/flow/' in row['id'] and row['status'] == 'input')
    raw = {role: next(row['words'] for row in rows if row['id'].endswith(f'/role{role}/raw') and
                      '/flow/' in row['id']) for role in (1, 2)}
    pause = flow.ConfirmedPause(inputs['original_test'], inputs['role'], inputs['seed'], raw)
    lanes = {role: next(row['words'] for row in rows if row['id'].endswith(f'/sample0/role{role}/lane0'))
             for role in (1, 2)}
    normalized = json.loads(json.dumps(inputs['test']))
    assert set(normalized['_flow_gpio_peer']) == {'role', 'rts', 'hold_us'}
    normalized['_flow_gpio_peer']['lane'] = 0
    limits = {role: pause.limits(normalized, inputs['seed'], role, 0) for role in (1, 2)}
    assert data['status'] == 'failed' and data['core_revision'].startswith('d44cef2')
    report['cases'].append({'name': path.parent.name, 'source': data['core_revision'], 'original_status': data['status'],
        'cts_raw': raw, 'first_measured_lane_raw': lanes, 'proposed_limits_ms': limits,
        'both_intervals_proven': True,
        'gaps_within_proposed_bound': all(all(a <= b for a, b in zip(lanes[role][17:19], limits[role]))
                                        for role in (1, 2)),
        'note': 'Old single-lane marker normalized with lane0 only for comparison. No drained hash/new-seed verdict; needs fresh physical test'})
assert len(report['cases']) == 8
output.write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps({'cases': len(report['cases']), 'within_proposed_bound': sum(row['gaps_within_proposed_bound'] for row in report['cases'])}))
