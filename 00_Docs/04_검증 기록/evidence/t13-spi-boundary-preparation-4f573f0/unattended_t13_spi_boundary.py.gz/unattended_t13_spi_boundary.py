"""! @brief UART 오류 배치 뒤 확인 잔여시간 안에서 SPI 짧은 DMA·미준비 조건을 검사합니다. """
from pathlib import Path

helper = Path(__file__).with_name('unattended_t13_followups.py')
prefix = helper.read_text(encoding='utf-8').split('\ntry:\n    save()')[0]
prefix = prefix.replace("'unattended-s-followups-01.json'", "'unattended-s-spi-boundary-01.json'")
prefix = prefix.replace("'waiting-for-current-S-batch'", "'waiting-for-UART-line-tests'")
exec(compile(prefix, str(helper), 'exec'))

try:
    save()
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.OpenProcess.argtypes = (ctypes.c_uint32, ctypes.c_bool, ctypes.c_uint32)
    kernel.OpenProcess.restype = ctypes.c_void_p
    kernel.WaitForSingleObject.argtypes = (ctypes.c_void_p, ctypes.c_uint32)
    kernel.WaitForSingleObject.restype = ctypes.c_uint32
    kernel.CloseHandle.argtypes = (ctypes.c_void_p,)
    handle = kernel.OpenProcess(0x00100000, False, 24020)
    if not handle:
        raise RuntimeError('original UART line process handle unavailable; review final state')
    try:
        while True:
            result = kernel.WaitForSingleObject(handle, 20000)
            if result == 0:
                break
            if result != 258:
                raise RuntimeError('UART line process wait failed')
            if time.time() >= grant['expires_at_unix']:
                raise RuntimeError('S confirmation ended while prior UART line tests were running')
    finally:
        kernel.CloseHandle(handle)
    previous = json.loads((folder/'unattended-s-uart-line-01.json').read_text())
    if previous['status'] != 'finished-available-uart-line-tests':
        raise RuntimeError('prior UART line tests did not finish with attempted cleanup proven')
    records = json.loads((folder/'spi-boundary-builds.json').read_text())
    if len(records) != 1:
        raise RuntimeError('one exact SPI boundary build registration required')
    build, record = next(iter(records.items()))
    source = record['source']
    passed = []
    for mode in ('short', 'unready'):
        for case, instance in ((6, 0), (7, 20), (8, 21), (9, 22), (10, 30)):
            name = f'spi{instance}-{mode}'
            options = ['--cases', str(case), '--spi-boundary-mode', mode]
            if execute(name+'-preflight-sauto-01', source, 'run_t13_spi_boundary.py', build,
                       ['--phase', 'spi-boundary-preflight', *options], 120):
                passed.append((name, options))
    for name, options in passed:
        execute(name+'-100-sauto-01', source, 'run_t13_spi_boundary.py', build,
                ['--phase', 'spi-boundary', *options], 900)
    report.pop('active', None)
    report['status'] = 'finished-available-spi-boundary-tests'
    save()
except BaseException as error:
    report.update(status='stopped-requires-review', error=f'{type(error).__name__}: {error}')
    save()
    raise
