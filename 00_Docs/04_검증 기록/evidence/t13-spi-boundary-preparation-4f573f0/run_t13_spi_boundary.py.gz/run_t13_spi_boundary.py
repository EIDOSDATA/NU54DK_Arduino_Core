"""! @brief SPI boundary 예행과 명시적 실기를 순서대로 보존합니다. """
from pathlib import Path
helper = Path(__file__).with_name('run_t13_recovery.py')
source = helper.read_text(encoding='utf-8').replace('launch_t13_recovery.py', 'launch_t13_spi_boundary.py')
exec(compile(source, str(helper), 'exec'))
