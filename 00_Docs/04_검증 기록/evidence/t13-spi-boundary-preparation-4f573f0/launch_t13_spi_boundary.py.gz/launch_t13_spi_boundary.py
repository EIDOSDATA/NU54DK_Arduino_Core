"""! @brief 기존 UID·확인서·CI·실기 배타 gate를 보존한 SPI boundary 실행기입니다. """
from pathlib import Path
helper = Path(__file__).with_name('launch_t13_recovery.py')
source = helper.read_text(encoding='utf-8').replace("Path('C:/tr13dev')", "Path('C:/tsspi04')")
source = source.replace("'recovery-builds.json'", "'spi-boundary-builds.json'")
source = source.replace("'pwm-recovery-preflight', 'pwm-recovery'), required=True)",
    "'pwm-recovery-preflight', 'pwm-recovery', 'spi-boundary-preflight', 'spi-boundary'), required=True)")
source = source.replace("parser.add_argument('--fault-mode'",
    "parser.add_argument('--spi-boundary-mode', choices=('short', 'unready'))\nparser.add_argument('--fault-mode'")
source = source.replace("for option in ('fault_mode',", "for option in ('spi_boundary_mode', 'fault_mode',")
assert "'spi-boundary'" in source and "('spi_boundary_mode'," in source
exec(compile(source, str(helper), 'exec'))
