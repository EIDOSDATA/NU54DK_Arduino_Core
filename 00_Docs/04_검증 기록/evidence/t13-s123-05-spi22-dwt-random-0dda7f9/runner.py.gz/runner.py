"""! @brief SPI22 DWT 진단의 preflight와 실기 로그를 분리합니다. """

import os
from pathlib import Path
import sys


LEGACY_WORK = Path(
    "C:/Users/eidos/Documents/Codex/2026-09-07/"
    "00-docs-05-v0-3-0/work"
)
sys.path.insert(0, str(LEGACY_WORK))
from check_pc import run


options = sys.argv[1:]
name = options[options.index("--name") + 1]
launcher = Path(__file__).with_name("launch_t13_spi22_watch_py314.py")
base = [sys.executable, "-E", "-X", "utf8", "-B", launcher]
for mode in ("preflight", "execute"):
    result = run(
        name + "-" + mode,
        [*base, mode, *options],
        os.environ.copy(),
    )
    if result:
        raise SystemExit(result)
