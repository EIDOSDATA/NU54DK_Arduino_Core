"""! @brief exact 0dda image를 SPI22 DWT 진단 실행기로 구동합니다. """

import importlib.util
from pathlib import Path
import sys


CURRENT_SESSION = Path(
    "C:/Users/eidos/GitHub/NU54DK_Arduino_Core/"
    "tests/hil/nu54dk/v04_t13_session.py"
)
sys.path.insert(0, str(CURRENT_SESSION.parent))


def load_current_session_policy():
    """! @brief 시간 만료를 폐기한 현행 S 유지 결선 정책을 exact 실행기에 주입합니다. """
    specification = importlib.util.spec_from_file_location(
        "v04_t13_session", CURRENT_SESSION
    )
    if specification is None or specification.loader is None:
        raise RuntimeError("current T13 session policy cannot be loaded")
    module = importlib.util.module_from_spec(specification)
    sys.modules["v04_t13_session"] = module
    specification.loader.exec_module(module)


load_current_session_policy()

launcher = Path(
    "C:/Users/eidos/Documents/Codex/2026-09-07/"
    "00-docs-05-v0-3-0/work/launch_t13_s123.py"
)
sys.path.insert(0, str(launcher.parent))
source = launcher.read_text(encoding="utf-8")
old_pyocd = "str(SDK/'opt/bin/Scripts/pyocd.exe')"
new_pyocd = (
    "str(Path('C:/Users/eidos/AppData/Local/Python/"
    "pythoncore-3.14-64/Scripts/pyocd.exe'))"
)
if source.count(old_pyocd) != 1:
    raise RuntimeError("pyOCD launcher substitution drift")
source = source.replace(old_pyocd, new_pyocd)
needle = "import v04_t13_session as session\n"
injection = (
    needle
    + "import v04_t13_spi_boundary as spi_boundaries\n"
    + "from spi22_restart_watch_diagnostic import install\n"
    + "install(pair, runner, spi_boundaries)\n"
)
if source.count(needle) != 1:
    raise RuntimeError("SPI22 diagnostic injection point drift")
source = source.replace(needle, injection, 1)
exec(compile(source, str(launcher), "exec"))

