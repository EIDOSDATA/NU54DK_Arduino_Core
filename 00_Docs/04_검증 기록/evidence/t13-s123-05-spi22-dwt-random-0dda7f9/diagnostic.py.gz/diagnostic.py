"""! @brief SPIM22 정상 재시작의 첫 데이터 오류를 DWT와 전체 레지스터로 보존합니다. """

import hashlib
from pathlib import Path
import time
import xml.etree.ElementTree as ET

from elftools.elf.elffile import ELFFile
from pyocd.core.target import Target


SOURCE = "0dda7f9dac30845e4fdb8f9bd28da22a906dcb9d"
BUILD = Path("C:/t5u04")
SVD = Path(
    "C:/ncs/v3.4.0/modules/hal/nordic/nrfx/bsp/stable/mdk/"
    "nrf54l15_application.svd"
)
INSTANCE_INDEX = 3
FAILURE_FAULT_SEED = 3832777470
FAILURE_RESTART_SEED = FAILURE_FAULT_SEED ^ 0x9E3779B9


def debug_layout(path):
    """! @brief exact ELF의 lane과 SPI driver context 주소·구조 배치를 읽습니다. """
    with Path(path).open("rb") as stream:
        elf = ELFFile(stream)
        dwarf = elf.get_dwarf_info()
        structs = {}
        variables = []
        selected_structs = {
            "Lane",
            "SpimContext",
            "SpisContext",
            "BufferPair",
            "BufferRecord",
        }
        for cu in dwarf.iter_CUs():
            cu_name = cu.get_top_DIE().attributes["DW_AT_name"].value.decode()
            for die in cu.iter_DIEs():
                definition = (
                    die.get_DIE_from_attribute("DW_AT_specification")
                    if "DW_AT_specification" in die.attributes
                    else die
                )
                raw_name = definition.attributes.get("DW_AT_name")
                name = raw_name.value.decode(errors="replace") if raw_name else ""
                if (
                    die.tag == "DW_TAG_structure_type"
                    and name in selected_structs
                    and "DW_AT_byte_size" in die.attributes
                ):
                    fields = {}
                    for member in die.iter_children():
                        raw_label = member.attributes.get("DW_AT_name")
                        offset = member.attributes.get("DW_AT_data_member_location")
                        if raw_label and offset and isinstance(offset.value, int):
                            fields[raw_label.value.decode()] = offset.value
                    value = {
                        "size": die.attributes["DW_AT_byte_size"].value,
                        "fields": fields,
                    }
                    if name in structs and structs[name] != value:
                        raise RuntimeError("ambiguous debug structure: " + name)
                    structs[name] = value
                if die.tag == "DW_TAG_variable" and name in ("lanes", "contexts"):
                    location = die.attributes.get("DW_AT_location")
                    if (
                        location
                        and isinstance(location.value, list)
                        and location.value
                        and location.value[0] == 3
                    ):
                        variables.append(
                            {
                                "name": name,
                                "address": int.from_bytes(
                                    bytes(location.value[1:]), "little"
                                ),
                                "cu": cu_name,
                            }
                        )
        required = selected_structs - set(structs)
        if required:
            raise RuntimeError("missing debug structures: " + ",".join(sorted(required)))
        return {"structs": structs, "variables": variables}


def register_map():
    """! @brief Nordic SVD에서 SPI22·GPIO·clock의 부작용 없는 레지스터만 고릅니다. """
    root = ET.parse(SVD).getroot()
    peripherals = {
        node.findtext("name"): node
        for node in root.findall("./peripherals/peripheral")
    }
    result = {}

    def walk(node, base, prefix="", access="read-write"):
        for child in node:
            if child.tag not in ("register", "cluster"):
                continue
            name = child.findtext("name")
            offset = int(child.findtext("addressOffset"), 0)
            count = int(child.findtext("dim", "1"), 0)
            stride = int(child.findtext("dimIncrement", "0"), 0)
            local_access = child.findtext("access", access)
            if child.find("readAction") is not None:
                continue
            for index in range(count):
                label = name.replace("%s", str(index)) if count > 1 else name
                label = prefix + label
                address = base + offset + index * stride
                if child.tag == "cluster":
                    yield from walk(child, address, label + ".", local_access)
                elif local_access != "write-only":
                    yield label, address

    for selected in ("SPIM22", "SPIS22", "P1", "CLOCK"):
        peripheral = peripherals["GLOBAL_" + selected + "_S"]
        base = int(peripheral.findtext("baseAddress"), 0)
        definition = peripheral
        while "derivedFrom" in definition.attrib:
            definition = peripherals[definition.attrib["derivedFrom"]]
        for name, address in walk(definition.find("registers"), base):
            if selected.startswith("SPI"):
                keep = name.startswith(("EVENTS_", "DMA.", "PSEL.", "IFTIMING."))
                keep = keep or name in (
                    "ENABLE",
                    "CONFIG",
                    "PRESCALER",
                    "CSNDUR",
                    "SHORTS",
                    "INTEN",
                    "STATUS",
                    "SEMSTAT",
                    "SEMAPHORE",
                    "DEF",
                    "ORC",
                )
            elif selected == "P1":
                keep = name in ("IN", "OUT", "DIR", "LATCH") or name in {
                    "PIN_CNF[4]",
                    "PIN_CNF[5]",
                    "PIN_CNF[6]",
                    "PIN_CNF[7]",
                }
            else:
                keep = name in (
                    "XO.RUN",
                    "XO.STAT",
                    "PLL.RUN",
                    "PLL.STAT",
                    "LFCLK.RUN",
                    "LFCLK.STAT",
                )
            if keep:
                result[selected + "." + name] = address
    if result.get("SPIM22.ENABLE") != 0x500C8500:
        raise RuntimeError("unexpected SPIM22 SVD layout")
    return result


class WatchDiagnostic:
    """! @brief 정상 재시작에서 lane 오류가 처음 기록되는 CPU 명령에만 멈춥니다. """

    def __init__(self, append, layouts):
        self.append = append
        self.layouts = layouts
        self.devices = []
        self.addresses = {}
        self.registers = register_map()
        self.armed = False
        self.captured = False
        self.raise_pending = False

    def arm(self, devices):
        """! @brief PREPARE가 lane을 초기화한 뒤 START 직전에 오류 write 감시를 겁니다. """
        if self.armed or self.captured:
            raise RuntimeError("SPI22 watchpoint lifecycle violation")
        self.devices = devices
        for device in devices:
            role = device.image["role"]
            if device.image["core_revision"] != SOURCE:
                raise RuntimeError("SPI22 diagnostic source drift")
            info = self.layouts[role]
            lanes = next(
                row["address"]
                for row in info["variables"]
                if row["name"] == "lanes"
            )
            error = lanes + info["structs"]["Lane"]["fields"]["error"]
            if error % 4 != 0 or device.target.read32(error) != 0:
                raise RuntimeError("lane error was not clear before monitored START")
            self.addresses[role] = error
            if not device.target.set_watchpoint(
                error, 4, Target.WatchpointType.WRITE
            ):
                raise RuntimeError("hardware watchpoint unavailable")
            device.target.flush()
            elf = Path(device.image["elf"])
            self.append(
                "debug/armed/role" + str(role),
                {
                    "status": "diagnostic",
                    "source": SOURCE,
                    "instance": 22,
                    "lane_error_address": error,
                    "lane_error_before": 0,
                    "elf_sha256": hashlib.sha256(elf.read_bytes()).hexdigest(),
                    "layout": info,
                },
            )
        self.armed = True

    def disarm(self):
        """! @brief 설치한 감시점만 제거하고 CPU 실행 상태는 건드리지 않습니다. """
        for device in self.devices:
            role = device.image["role"]
            if role in self.addresses:
                device.target.remove_watchpoint(
                    self.addresses[role], 4, Target.WatchpointType.WRITE
                )
                device.target.flush()
        self.armed = False

    @staticmethod
    def _valid_ram(address, size):
        return 0x20000000 <= address and 0 < size <= 8192 and address + size <= 0x20040000

    def _capture_role(self, device):
        role = device.image["role"]
        target = device.target
        info = self.layouts[role]
        lane_address = next(
            row["address"]
            for row in info["variables"]
            if row["name"] == "lanes"
        )
        lane_info = info["structs"]["Lane"]
        driver = "Spim" if role == 1 else "Spis"
        context_info = info["structs"][driver + "Context"]
        context_array = next(
            row["address"]
            for row in info["variables"]
            if row["name"] == "contexts" and row["cu"].endswith("/" + driver + "Fabric.cpp")
        )
        context_address = context_array + INSTANCE_INDEX * context_info["size"]
        names = ["r" + str(index) for index in range(13)] + [
            "sp",
            "lr",
            "pc",
            "xpsr",
            "msp",
            "psp",
            "primask",
            "basepri",
            "faultmask",
            "control",
        ]
        cpu = dict(zip(names, target.read_core_registers_raw(names)))
        selected_prefix = "SPIM22." if role == 1 else "SPIS22."
        row = {
            "status": "diagnostic",
            "role": role,
            "cpu": cpu,
            "lane_error": target.read32(self.addresses[role]),
            "registers": {
                name: target.read32(address)
                for name, address in self.registers.items()
                if name.startswith(selected_prefix)
                or name.startswith("P1.")
                or name.startswith("CLOCK.")
            },
            "scb": {
                hex(address): target.read32(address)
                for address in (
                    0xE000ED04,
                    0xE000ED24,
                    0xE000ED28,
                    0xE000ED2C,
                    0xE000ED30,
                    0xE000EDF0,
                    0xE000EDFC,
                )
            },
            "nvic_enabled": target.read_memory_block32(0xE000E100, 16),
            "nvic_pending": target.read_memory_block32(0xE000E200, 16),
            "nvic_active": target.read_memory_block32(0xE000E300, 16),
            "ram": {
                "lane0": {
                    "address": lane_address,
                    "bytes_hex": bytes(
                        target.read_memory_block8(lane_address, lane_info["size"])
                    ).hex(),
                },
                "driver_context": {
                    "address": context_address,
                    "bytes_hex": bytes(
                        target.read_memory_block8(context_address, context_info["size"])
                    ).hex(),
                },
            },
        }
        data_fault = lane_address + lane_info["fields"]["data_fault"]
        words = target.read_memory_block32(data_fault, 20)
        row["data_fault_words"] = words
        rx_address = words[12]
        rx_size = words[13]
        if self._valid_ram(rx_address, rx_size):
            row["ram"]["fault_rx"] = {
                "address": rx_address,
                "bytes_hex": bytes(
                    target.read_memory_block8(rx_address, rx_size)
                ).hex(),
            }
        for register in ("sp", "msp", "psp"):
            address = cpu[register] & ~3
            if self._valid_ram(address, 256):
                row["ram"][register] = {
                    "address": address,
                    "words": target.read_memory_block32(address, 64),
                }
        return row

    def check(self):
        """! @brief mailbox polling과 같은 스레드에서 첫 halt를 확인해 probe 접근을 직렬화합니다. """
        if not self.armed:
            return 0.0
        started = time.monotonic()
        states = {
            device.image["role"]: device.target.get_state()
            for device in self.devices
        }
        halted = [role for role, state in states.items() if state == Target.State.HALTED]
        if not halted:
            return 0.0
        self.captured = True
        self.raise_pending = True
        self.append(
            "debug/watch-hit",
            {
                "status": "diagnostic",
                "initially_halted_roles": halted,
                "states": {role: str(state) for role, state in states.items()},
                "physical_pass_added": False,
            },
        )
        try:
            for device in self.devices:
                if device.target.get_state() != Target.State.HALTED:
                    device.target.halt()
            for device in self.devices:
                self.append(
                    "debug/capture/role" + str(device.image["role"]),
                    self._capture_role(device),
                )
        finally:
            try:
                self.disarm()
            finally:
                for device in self.devices:
                    if device.target.get_state() == Target.State.HALTED:
                        device.target.resume()
            self.append(
                "debug/resumed-for-stop",
                {
                    "status": "diagnostic",
                    "capture_seconds": time.monotonic() - started,
                    "physical_pass_added": False,
                },
            )
        return time.monotonic() - started


def install(pair, runner, boundaries):
    """! @brief SPIM22 short의 정상 restart 구간에만 DWT 감시를 결합합니다. """
    layouts = {}
    for role, suffix in ((1, "dut"), (2, "peer")):
        paths = list(
            BUILD.glob(
                "**/nucode.v04.t13_s_" + suffix + "/**/zephyr.elf"
            )
        )
        if len(paths) != 1:
            raise RuntimeError("exact SPI22 ELF selection failed")
        layouts[role] = debug_layout(paths[0])

    original_command = pair.Device.command
    original_group = runner.execute_group
    original_start = runner.start_devices
    original_execute = boundaries.execute
    active = {"manager": None, "monitor_group": False}

    class Captured(pair.ProtocolError):
        """! @brief DWT 캡처 완료를 일반 protocol 오류와 구분합니다. """

    def command(device, opcode, values=(), timeout=10):
        manager = active["manager"]
        if manager is None or not manager.armed:
            return original_command(device, opcode, values, timeout)
        if device.poisoned or not 0 < timeout <= 60:
            raise pair.ProtocolError("session is poisoned or timeout invalid")
        device.sequence += 1
        packet = pair.encode(
            device.nonce,
            device.sequence,
            device.image["role"],
            opcode,
            values,
        )
        request = device.image["symbols"]["v04_request"]
        response = device.image["symbols"]["v04_response"]
        try:
            device.target.write32(response, 0)
            device.target.write32(request, 0)
            device.target.write_memory_block8(request + 4, packet[4:])
            device.target.flush()
            device.target.write32(request, pair.MAGIC)
            device.target.flush()
            deadline = time.monotonic() + timeout
            while time.monotonic() < deadline:
                deadline += manager.check()
                if device.target.read32(response):
                    raw = bytes(
                        device.target.read_memory_block8(response, pair.SIZE)
                    )
                    status, output = pair.decode(
                        raw,
                        device.nonce,
                        device.sequence,
                        device.image["role"],
                        opcode,
                    )
                    if manager.raise_pending:
                        manager.raise_pending = False
                        raise Captured(
                            "DWT captured the first SPIM22 restart data error"
                        )
                    if status:
                        raise pair.ProtocolError(
                            "firmware rejected diagnostic mailbox command"
                        )
                    return output
                time.sleep(pair.MAILBOX_POLL_INTERVAL_SECONDS)
            raise pair.ProtocolError("debug mailbox timeout")
        except Captured:
            raise
        except BaseException:
            device.poisoned = True
            raise

    def start(devices, test, append, identifier, **kwargs):
        manager = active["manager"]
        if active["monitor_group"]:
            if test["id"] != 9 or test["name"] != "spim22":
                raise RuntimeError("SPI22 monitored group selection drift")
            manager.append = append
            manager.arm(devices)
        return original_start(devices, test, append, identifier, **kwargs)

    def group(devices, selected, duration, continuity, append, **kwargs):
        monitor = (
            active["manager"] is not None
            and selected["test"]["id"] == 9
            and selected["test"]["name"] == "spim22"
            and duration >= 0.9
        )
        active["monitor_group"] = monitor
        try:
            return original_group(
                devices, selected, duration, continuity, append, **kwargs
            )
        finally:
            active["monitor_group"] = False
            if active["manager"] is not None:
                active["manager"].disarm()

    def execute(devices, test, mode, continuity, append, *, preflight):
        if test["id"] != 9 or mode != "short" or preflight:
            raise RuntimeError("SPI22 DWT diagnostic requires formal short selection")
        manager = WatchDiagnostic(append, layouts)
        active["manager"] = manager
        append(
            "debug/reproduction-input",
            {
                "status": "diagnostic",
                "fault_seed": FAILURE_FAULT_SEED,
                "restart_seed": FAILURE_RESTART_SEED,
                "original_failure_repeat": 51,
                "physical_pass_added": False,
            },
        )

        def diagnostic_append(identifier, row):
            row = dict(row)
            if row.get("status") == "passed":
                row["status"] = "diagnostic-observation"
            for key in row:
                if key.endswith("_pass"):
                    row[key] = False
            append(identifier, row)

        try:
            original_execute(
                devices,
                test,
                mode,
                continuity,
                diagnostic_append,
                preflight=False,
            )
            raise pair.ProtocolError(
                "bounded SPI22 watchpoint diagnostic ended without an error"
            )
        finally:
            manager.disarm()
            for device in devices:
                if device.target.get_state() == Target.State.HALTED:
                    device.target.resume()
            active["manager"] = None

    pair.Device.command = command
    runner.start_devices = start
    runner.execute_group = group
    boundaries.secrets.randbits = lambda bits: FAILURE_FAULT_SEED
    boundaries.execute = execute
