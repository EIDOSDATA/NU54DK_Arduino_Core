"""! @brief 실행기가 종료한 뒤 exact image와 주변장치·모든 연결 pin을 읽기만 합니다. """
import datetime
import hashlib
import json
import logging
import sys
from pathlib import Path
from check_pc import REPO, WORK

logging.disable(logging.CRITICAL)
sys.path.insert(0, str(REPO / 'tests/hil/nu54dk'))
import v04_pair as pair
from v04_protocol import ProbeLocks
from pyocd.core.helpers import ConnectHelper
from serial.tools import list_ports


def inspect(images_path, output_path):
    images = json.loads(Path(images_path).read_text(encoding='utf-8'))
    private = json.loads((WORK / 'current-probe-uids.private.json').read_text(encoding='utf-8-sig'))
    grant = json.loads((WORK / 'common-bundle-session-grant.json').read_text(encoding='utf-8'))
    uids = [private[key].lower() for key in grant['uid_sha256']]
    assert not Path(output_path).exists()
    available = {probe.unique_id.lower() for probe in ConnectHelper.get_all_connected_probes(blocking=False)}
    assert set(uids).issubset(available)
    ports = list_ports.comports()
    catalog = json.loads((REPO / 'tests/hil/nu54dk/v04_common_fixture.json').read_text(encoding='utf-8'))
    bases = {0: 0x5010A000, 1: 0x500D8200, 2: 0x50050400}
    report = {'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'swd_frequency_hz': 10000000, 'reset_halt_resume_flash': False, 'boards': []}
    with ProbeLocks(uids):
        for uid, image in zip(uids, images):
            session = ConnectHelper.session_with_chosen_probe(unique_id=uid, target_override='nrf54l',
                frequency=10000000, blocking=False, no_config=True,
                options={'auto_unlock': False, 'connect_mode': 'attach', 'resume_on_disconnect': False,
                         'cmsis_dap.limit_packets': True})
            assert session is not None
            with session:
                target = session.target
                pair.verify_identity(bytes(target.read_memory_block8(image['symbols']['v04_identity'], 64)),
                                     image['role'], image['core_revision'])
                row = {'role': image['role'], 'uid_sha256': hashlib.sha256(uid.encode()).hexdigest(),
                       'ports': pair.matching_port_names(ports, uid), 'core_revision': image['core_revision'],
                       'cpuid': target.read32(0xE000ED00), 'state': target.get_state().name,
                       'nvic_priority_bytes': target.read_memory_block8(0xE000E400, 271),
                       'nvic_enable_words': target.read_memory_block32(0xE000E100, 9),
                       'nvic_pending_words': target.read_memory_block32(0xE000E200, 9),
                       'aircr': target.read32(0xE000ED0C),
                       'ficr_part': target.read32(0x00FFC31C),
                       'ficr_variant': target.read32(0x00FFC320),
                       'ficr_package': target.read32(0x00FFC324),
                       'backend_packets': session.probe._link._packet_count,
                       'pwm_enable': [target.read32(base + 0x500) for base in (0x500D2000, 0x500D3000, 0x500D4000)],
                       'dppi20_chen': target.read32(0x500C2500), 'dppi30_chen': target.read32(0x50102500),
                       'qdec_enable': [target.read32(base + 0x500) for base in (0x500E0000, 0x500E1000)],
                       'i2s_enable': target.read32(0x500DD500),
                       'gpiote20_configuration': target.read_memory_block32(0x500DA510, 8),
                       'gpiote30_configuration': target.read_memory_block32(0x5010C510, 4), 'pin_cnf': {}}
                for link in catalog['fixtures'][0]['links'][:-1]:
                    net = link['dut' if image['role'] == 1 else 'peer'][2]
                    port, pin = map(int, net[1:].split('.'))
                    row['pin_cnf'][net] = target.read32(bases[port] + 0x80 + pin * 4)
                report['boards'].append(row)
    with Path(output_path).open('x', encoding='utf-8') as stream:
        json.dump(report, stream, indent=2)
    for row in report['boards']:
        assert row['cpuid'] == 0x411FD210 and row['state'] in ('RUNNING', 'SLEEPING') and row['backend_packets'] == 1
        assert row['pwm_enable'] == [0, 0, 0] and row['qdec_enable'] == [0, 0] and row['i2s_enable'] == 0
        assert row['dppi20_chen'] == row['dppi30_chen'] == 0
        assert all(value & 3 == 0 for value in row['gpiote20_configuration'] + row['gpiote30_configuration'])
        assert all(value & 1 == 0 for value in row['pin_cnf'].values())
    print('COMMON_POSTFLIGHT_PASS: ' + str(output_path), flush=True)
    return report


if __name__ == '__main__':
    inspect(sys.argv[1], sys.argv[2])
