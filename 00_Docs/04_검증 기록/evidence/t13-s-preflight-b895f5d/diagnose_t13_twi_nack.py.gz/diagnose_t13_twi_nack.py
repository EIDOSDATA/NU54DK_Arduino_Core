"""! @brief 고정된 P1/P0 400kHz TWI에서 실제 주소·PSEL·idle·event를 비교하는 제한 진단입니다. """
from contextlib import ExitStack
import json
import logging
from pathlib import Path
import sys
import time
from check_pc import REPO, WORK, SDK
sys.path.insert(0, str(REPO/'tests/hil/nu54dk'))
import v04_pair as pair
import v04_t13_session as session
import v04_t13_run as runner
import v04_t13_cases as catalog
from v04_protocol import ProbeLocks
from pyocd.core.helpers import ConnectHelper
logging.disable(logging.CRITICAL)
folder = WORK/'t13-s-20260908'
grant = json.loads((folder/'session-grant-repair1.json').read_text(encoding='utf-8'))
private = json.loads((folder/'probe-uids-local.json').read_text(encoding='utf-8'))
uids = [private[key].lower() for key in grant['uid_sha256']]
images = [pair.inspect_image(REPO, Path('C:/t3f04'), role, family='t13_s') for role in (1, 2)]
session.validate(grant, images, uids)
after_spi = '--after-spi' in sys.argv
after_uart = '--after-uart' in sys.argv
full_prefix = '--full-prefix' in sys.argv
result = {'type': 'T13-S-400kHz-TWI-NACK-register-diagnostic', 'source': images[0]['core_revision'],
          'after_spi20': after_spi,
          'soak_or_recovery_pass': False, 'results': []}
name = 'twi-after-spi-diagnostic-b895f5d-01.json' if after_spi else 'twi-nack-diagnostic-b895f5d-01.json'
if after_uart:
    name = 'twi-after-uart-spi-diagnostic-b895f5d-01.json'
if full_prefix:
    name = 'twi-after-full-prefix-b895f5d-01.json'
with pair.evidence_session(folder/name, result) as journal:
    def append(identifier, observation):
        row = {'id': identifier, **observation}
        result['results'].append(row)
        journal.write(json.dumps(row)+'\n')
        journal.flush()
    with ProbeLocks(uids), ExitStack() as stack:
        devices = []
        for uid, image in zip(uids, images):
            device, flash = pair.boot_exact(stack, ConnectHelper, SDK/'opt/bin/Scripts/pyocd.exe', uid, image,
                                            10000000, cmsis_dap_limit_packets=True)
            session.verify_profile(device)
            devices.append(device)
            append(f'boot/role{image["role"]}', {'flash': flash})
        if after_spi:
            continuity = session.Continuity(grant, images, uids, devices,
                lambda: {p.unique_id.lower() for p in ConnectHelper.get_all_connected_probes(blocking=False)},
                pair.verify_identity)
            for identifier in ([2,3,4,5,6,7,8,9,10] if full_prefix else [2, 7] if after_uart else [7]):
                group = runner.grouped([t for t in catalog.cases() if t['id'] == identifier])[0]
                runner.execute_group(devices, group, 1, continuity, append, preflight=True)
        for case, serial_base, gpio_base, pins in ((16, 0x500C6000, 0x500D8200, [10,14]),
                                                   (19, 0x50104000, 0x5010A000, [0,1])):
            session.validate(grant, images, uids)
            label = f'case{case}'
            try:
                for device in reversed(devices):
                    assert device.command(97, (case, 0xA5C34000+case, 0x53414645), timeout=3) == [1]
                for stage in ('prepared', 'started'):
                    if stage == 'started':
                        for device in reversed(devices):
                            assert device.command(98, timeout=3) == [1]
                        time.sleep(.35)
                    for device in devices:
                        target = device.target
                        offsets = [0x104,0x114,0x13C,0x140,0x200,0x300,0x4D0,0x4D4,0x500,0x524,0x588,0x58C,0x594,0x600,0x604]
                        append(f'{label}/{stage}/role{device.image["role"]}', {'status': 'observation',
                            'engine': device.command(99), 'lane': device.command(100, (0,)),
                            'registers': {hex(offset): target.read32(serial_base+offset) for offset in offsets},
                            'gpio_in': target.read32(gpio_base+0x10),
                            'pin_cnf': [target.read32(gpio_base+0x80+pin*4) for pin in pins]})
            finally:
                assert runner.stop_pair(devices, append, label+'/cleanup')
        for device in devices:
            words = device.command(51)
            append(f'final/role{device.image["role"]}', {'words': words})
            assert words[1:4] == [0,0,0]
for row in result['results']:
    if 'lane' in row:
        print(row['id'], 'engine=',row['engine'][:6], 'lane=', row['lane'][:5],
              'cnf=',row['pin_cnf'], 'regs=',row['registers'])
