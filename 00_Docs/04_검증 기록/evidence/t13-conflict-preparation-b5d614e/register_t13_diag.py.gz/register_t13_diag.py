"""! @brief 최초 오류·자원 충돌 image의 source와 성공 검사를 등록합니다. """
import json
from pathlib import Path
import sys
from check_pc import WORK

repo = Path('C:/tsdiag04')
sys.path.insert(0, str(repo/'tests/hil/nu54dk'))
import v04_pair as pair
source = 'b5d614e3d449b6ad0cbba3513499e0890e1ddc65'
images = [pair.inspect_image(repo, Path('C:/t4k05'), role, family='t13_s') for role in (1, 2)]
assert all(image['core_revision'] == source for image in images)
gates = ['t13-diag-exact-'+name+'-02' for name in ('target', 'style', 'host', 'contract', 'docs')]
assert all(json.loads((WORK/(gate+'.json')).read_text())['exit_code'] == 0 for gate in gates)
ci = json.loads((WORK/'t13-s-20260908/ci-b5d614e-01.json').read_text())
assert ci['source'] == source
assert any(row['name'] == 'Host unit with Windows PowerShell contracts' and
           row['conclusion'] == 'success' for row in ci['checks'])
path = WORK/'t13-s-20260908/recovery-builds.json'
records = json.loads(path.read_text())
assert 'C:/t4k05' not in records
records['C:/t4k05'] = {'source': source, 'repository': str(repo), 'local_gates': gates,
    'remote_exact_host': 'ci-b5d614e-01; success',
    'purpose': 'first payload mismatch provenance and P1 UART21/22/30 atomic resource rejection'}
path.write_text(json.dumps(records, indent=2)+'\n')
print('registered C:/t4k05; no physical access')
