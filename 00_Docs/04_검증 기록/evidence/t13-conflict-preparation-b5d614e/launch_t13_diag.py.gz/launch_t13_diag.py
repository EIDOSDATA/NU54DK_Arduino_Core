"""! @brief exact source·image·CI·현재 확인서 검사를 보존하여 추가 진단을 실행합니다. """
from pathlib import Path
helper = Path(__file__).with_name('launch_t13_recovery.py')
source = helper.read_text(encoding='utf-8').replace("Path('C:/tr13dev')", "Path('C:/tsdiag04')")
source = source.replace("'pwm-recovery-preflight', 'pwm-recovery'), required=True)",
    "'pwm-recovery-preflight', 'pwm-recovery', 'conflict-preflight', 'resource-conflict'), required=True)")
source = source.replace("parser.add_argument('--pwm-diagnostic-route'",
    "parser.add_argument('--conflict-mode', type=int, choices=(1, 2, 3))\nparser.add_argument('--pwm-diagnostic-route'")
source = source.replace("'pwm_diagnostic_route', 'pwm_recovery_mode'):",
    "'pwm_diagnostic_route', 'pwm_recovery_mode', 'conflict_mode'):")
assert "'resource-conflict'" in source and "getattr(args, option)" in source
exec(compile(source, str(helper), 'exec'))
