"""! @brief 기존 후속 배치가 종료된 뒤 자원 충돌·최초 SPI 오류를 제한 시간 안에서 검사합니다. """
from pathlib import Path

helper = Path(__file__).with_name('unattended_t13_followups.py')
prefix = helper.read_text(encoding='utf-8').split('\ntry:\n    save()')[0]
prefix = prefix.replace("'unattended-s-followups-01.json'", "'unattended-s-diagnostics-01.json'")
prefix = prefix.replace("'waiting-for-current-S-batch'", "'waiting-for-TWIM-and-power-followups'")
exec(compile(prefix, str(helper), 'exec'))

try:
    save()
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.OpenProcess.argtypes = (ctypes.c_uint32, ctypes.c_bool, ctypes.c_uint32)
    kernel.OpenProcess.restype = ctypes.c_void_p
    kernel.WaitForSingleObject.argtypes = (ctypes.c_void_p, ctypes.c_uint32)
    kernel.WaitForSingleObject.restype = ctypes.c_uint32
    kernel.CloseHandle.argtypes = (ctypes.c_void_p,)
    handle = kernel.OpenProcess(0x00100000, False, 3136)
    if not handle:
        raise RuntimeError('follow-up process handle unavailable; inspect its final state')
    try:
        while True:
            result = kernel.WaitForSingleObject(handle, 20000)
            if result == 0:
                break
            if result != 258:
                raise RuntimeError('follow-up process wait failed')
            if time.time() >= grant['expires_at_unix']:
                raise RuntimeError('S confirmation ended while follow-ups were running')
    finally:
        kernel.CloseHandle(handle)
    previous = json.loads((folder/'unattended-s-followups-01.json').read_text())
    if previous['status'] != 'finished-available-followups':
        raise RuntimeError('prior follow-ups did not finish with attempted cleanup proven')

    source = 'b5d614e3d449b6ad0cbba3513499e0890e1ddc65'
    build = 'C:/t4k05'
    records = json.loads((folder/'recovery-builds.json').read_text())
    if records.get(build, {}).get('source') != source:
        raise RuntimeError('diagnostic exact build registration is not ready')
    passed = []
    for case, instance in ((3, 21), (4, 22), (5, 30)):
        for role in (1, 2):
            for mode in ((1,) if instance == 30 else (1, 2, 3)):
                options = ['--cases', str(case), '--fault-role', str(role), '--conflict-mode', str(mode)]
                name = f'conflict{instance}-r{role}-m{mode}'
                if execute(name+'-preflight-sauto-01', source, 'run_t13_diag.py', build,
                           ['--phase', 'conflict-preflight', *options], 120):
                    passed.append((name, options))

    for instance in (20, 21, 22):
        execute(f'serial{instance}-first-fault-sauto-01', source, 'run_t13_diag.py', build,
                ['--phase', 'handover', '--handover-instance', str(instance)], 900)

    flow_passed = []
    flow_registry = folder/'flow-builds.json'
    if flow_registry.is_file():
        flow_records = json.loads(flow_registry.read_text())
        if len(flow_records) != 1:
            raise RuntimeError('one exact CTS build registration required')
        flow_build, flow_record = next(iter(flow_records.items()))
        flow_source = flow_record['source']
        for case, instance in ((2, 20), (3, 21), (4, 22), (5, 30)):
            for role in (1, 2):
                name = f'flow{instance}-r{role}'
                options = ['--cases', str(case), '--fault-role', str(role)]
                if execute(name+'-preflight-sauto-01', flow_source, 'run_t13_flow.py', flow_build,
                           ['--phase', 'flow-preflight', *options], 120):
                    flow_passed.append((name, options))
    else:
        report['CTS'] = 'not-started; exact image registration not ready'
    for index in range(max(len(passed), len(flow_passed))):
        if index < len(passed):
            name, options = passed[index]
            execute(name+'-100-sauto-01', source, 'run_t13_diag.py', build,
                    ['--phase', 'resource-conflict', *options], 600)
        if index < len(flow_passed):
            name, options = flow_passed[index]
            execute(name+'-100-sauto-01', flow_source, 'run_t13_flow.py', flow_build,
                    ['--phase', 'uart-flow', *options], 900)
    report.pop('active', None)
    report['status'] = 'finished-available-diagnostics'
    save()
except BaseException as error:
    report.update(status='stopped-requires-review', error=f'{type(error).__name__}: {error}')
    save()
    raise
