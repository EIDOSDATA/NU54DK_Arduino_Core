"""! @brief 현재 3f4a1890 S 이미지를 재플래시하지 않고 전체 17개 결선을 검사합니다. """

from contextlib import ExitStack
import importlib.util
from pathlib import Path
import secrets
import sys
import time


LEGACY_WORK = Path(
    "C:/Users/eidos/Documents/Codex/2026-09-07/00-docs-05-v0-3-0/work"
)
EXACT_REPO = Path(
    "C:/Users/eidos/Documents/Codex/2026-09-09/new-chat/work/t13-s-3f4a1890"
)
CURRENT_REPO = Path("C:/Users/eidos/GitHub/NU54DK_Arduino_Core")
SOURCE = "3f4a18906f6d72df45f5a07f901b6a7aef716a2a"
OUTPUT_NAME = "s123-full-s-wiring-readonly-review-20260909-02.json"

sys.path.insert(0, str(LEGACY_WORK))
sys.path.insert(0, str(EXACT_REPO / "tests/hil/nu54dk"))

import v04_pair as pair
import v04_t13_cases
import v04_t13_plan
import v04_protocol
import v04_wiring


def load_current_session_policy():
    """! @brief 시간 만료를 폐기한 현행 T13 결선 정책만 exact 실행기에 주입합니다. """
    path = CURRENT_REPO / "tests/hil/nu54dk/v04_t13_session.py"
    specification = importlib.util.spec_from_file_location("v04_t13_session", path)
    if specification is None or specification.loader is None:
        raise RuntimeError("current T13 session policy cannot be loaded")
    module = importlib.util.module_from_spec(specification)
    sys.modules["v04_t13_session"] = module
    specification.loader.exec_module(module)
    return module


session = load_current_session_policy()


def boot_current(stack: ExitStack, connect_helper, _pyocd: Path, uid: str, image: dict,
                 swd_frequency_hz: int, **options):
    """! @brief flash 쓰기 없이 현재 image를 reset·identity 검증 후 시작합니다. """
    session_options = {
        "auto_unlock": False,
        "connect_mode": "attach",
        "resume_on_disconnect": False,
    }
    if options.get("cmsis_dap_limit_packets"):
        session_options["cmsis_dap.limit_packets"] = True
    handle = connect_helper.session_with_chosen_probe(
        unique_id=uid,
        target_override="nrf54l",
        frequency=swd_frequency_hz,
        blocking=False,
        no_config=True,
        options=session_options,
    )
    if handle is None:
        raise pair.ProtocolError("selected probe disappeared before full wiring review")
    stack.enter_context(handle)
    target = handle.target
    target.reset_and_halt()
    if target.get_state().name != "HALTED" or target.read32(0xE000ED00) != 0x411FD210:
        raise pair.ProtocolError("controlled read-only start CPU identity failed")
    for address in image["symbols"].values():
        target.write32(address, 0)
    target.flush()
    target.resume()
    deadline = time.monotonic() + 5
    while target.read32(image["symbols"]["v04_identity"]) != pair.MAGIC:
        if time.monotonic() > deadline:
            raise pair.ProtocolError("current firmware boot identity timeout; no flash performed")
        time.sleep(0.01)
    raw = bytes(target.read_memory_block8(image["symbols"]["v04_identity"], 64))
    pair.verify_identity(raw, image["role"], SOURCE)
    return pair.Device(target, image, secrets.token_bytes(16)), {
        "operation": "not-performed",
        "sector_flash": False,
        "reason": "current exact 3f4a1890 S runtime identity verified",
    }


pair.boot_exact = boot_current


def generated_source():
    """! @brief 보존된 전수 검사기에서 현행 source·build·정책의 실행 원본을 생성합니다. """
    helper = LEGACY_WORK / "audit_t13_all_gpio.py"
    source = helper.read_text(encoding="utf-8")
    replacements = (
        ("C:/tr13dev", str(EXACT_REPO).replace("\\", "/")),
        ("C:/t4c04", "C:/t5t04"),
        ("session-grant-repair3.json", "session-grant-s123-02.json"),
        ("43bc0320d6681d57d2ec1cd569fef35f7dd8ec0d", SOURCE),
        ("all-gpio-audit-43bc032-attempt2.json", OUTPUT_NAME),
        (
            "User paused T13 and requested all GPIO audit; single open-drain only",
            "User requested full maintained-S GPIO review; single open-drain only",
        ),
        (
            "Pause protocol HIL; inspect every currently wired S GPIO",
            "Inspect every maintained S GPIO before remaining protocol HIL",
        ),
        ("t13_traffic_paused_by_user=True", "t13_traffic_paused_by_user=False"),
        (
            "All-GPIO audit ended; inspect full matrix and both STOP; do not resume protocol HIL",
            "Full maintained-S GPIO review ended; inspect matrix and both STOP before protocol HIL",
        ),
        (".read_text())", ".read_text(encoding='utf-8'))"),
    )
    for before, after in replacements:
        if before not in source:
            raise RuntimeError(f"full checker source marker missing: {before}")
        source = source.replace(before, after)
    return helper, source


def verify_generated(helper: Path, source: str):
    """! @brief 하드웨어 실행 전에 full-17·340회·no-flash·현행 정책 표식을 검증합니다. """
    compile(source, str(helper), "exec")
    required = (
        str(EXACT_REPO).replace("\\", "/"),
        "C:/t5t04",
        "session-grant-s123-02.json",
        SOURCE,
        OUTPUT_NAME,
        "for controller_role in (1, 2):",
        "for repetition in range(1, 11):",
        "for net in range(17):",
        "'planned_pulses': 340",
    )
    if not all(marker in source for marker in required):
        raise RuntimeError("generated full checker is missing a required marker")
    if pair.boot_exact is not boot_current:
        raise RuntimeError("read-only boot override is not active")
    print("FULL_S_CHECKER_VALID nets=17 directions=2 repeats=10 pulses=340 flash=readonly")


if __name__ == "__main__":
    base, generated = generated_source()
    verify_generated(base, generated)
    exec(compile(generated, str(base), "exec"))
