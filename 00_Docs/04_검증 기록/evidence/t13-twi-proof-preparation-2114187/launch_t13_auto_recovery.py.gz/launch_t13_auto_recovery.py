"""! @brief 동일한 실행 경계를 유지하며 TWIM 계측 전용 clean checkout을 선택합니다. """
from pathlib import Path
helper = Path(__file__).with_name('launch_t13_recovery.py')
source = helper.read_text(encoding='utf-8').replace("Path('C:/tr13dev')", "Path('C:/tsauto04')")
exec(compile(source, str(helper), 'exec'))
