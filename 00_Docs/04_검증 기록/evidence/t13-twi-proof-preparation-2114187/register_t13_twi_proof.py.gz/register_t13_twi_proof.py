"""! @brief TWIM RX 계측의 exact build·필수 검사를 등록하며 보드에 접근하지 않습니다. """
import json
from pathlib import Path
import sys
from check_pc import WORK

repo = Path('C:/tsauto04')
sys.path.insert(0, str(repo/'tests/hil/nu54dk'))
import v04_pair as pair
source = '21141876d076937085b86afead3339a9a4608bc2'
images = [pair.inspect_image(repo, Path('C:/t4i04'), role, family='t13_s') for role in (1, 2)]
assert all(image['core_revision'] == source for image in images)
gates = ['t13-twi-proof-target-01', 't13-twi-proof-exact-style-01',
         't13-twi-proof-exact-focused-host-01', 't13-twi-proof-exact-contract-01',
         't13-twi-proof-exact-docs-01']
assert all(json.loads((WORK/(gate+'.json')).read_text())['exit_code'] == 0 for gate in gates)
ci = json.loads((WORK/'t13-s-20260908/ci-2114187-01.json').read_text())
assert any(row['name'] == 'Host unit with Windows PowerShell contracts' and
           row['conclusion'] == 'success' for row in ci['checks'])
path = WORK/'t13-s-20260908/recovery-builds.json'
records = json.loads(path.read_text())
assert 'C:/t4i04' not in records
records['C:/t4i04'] = {'source': source, 'repository': str(repo), 'local_gates': gates,
    'local_full_host': '42/43; Windows4551 generated C++ execution blocked; no policy change',
    'remote_exact_host': 'ci-2114187-01;100 groups/773 tests PASS',
    'purpose': 'mode4 raw RX provenance; original partial-DMA oracle unchanged'}
path.write_text(json.dumps(records, indent=2)+'\n')
print('registered C:/t4i04; no physical access')
