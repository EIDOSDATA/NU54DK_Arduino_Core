"""! @brief 완료 원본만 감사하며 부분 실패를 전체 PASS로 바꾸지 않습니다. """
import collections
import datetime
import hashlib
import itertools
import json
from check_pc import WORK

report = {'observed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'whole_t12_complete': False, 't13_physical_executed': False, 'campaigns': []}
definitions = (
    ('common-gpio-hardware-4e48252', {'V04-WIRING': 105, 'V04-COMMON-GPIO': 342,
                                   'V04-COMMON-GPIOTE-TASK': 720, 'V04-COMMON-GPIOTE-EDGE': 1440}),
    ('common-signals-hardware-3334b17', {'V04-WIRING': 105, 'V04-PWM-CAPTURE': 675,
                                      'V04-COMMON-PWM-MODES': 1}),
    ('common-additional-hardware-0db0689', {'V04-WIRING': 105, 'V04-COMMON-PWM-MODES': 288,
                                         'V04-COMMON-QDEC': 18}),
    ('common-qdec-i2s-hardware-b5c86a4', {'V04-WIRING': 105, 'V04-COMMON-QDEC': 26}),
)
for name, expected in definitions:
    folder = WORK / name
    raw = (folder / 'result.json').read_bytes()
    campaign = json.loads(raw)
    journal = [json.loads(line) for line in (folder / 'result.json.jsonl').read_text(encoding='utf-8').splitlines()]
    assert campaign['results'] == journal
    passed = [row['id'] for row in journal if row.get('status') == 'passed']
    assert len(passed) == len(set(passed))
    counts = collections.Counter(key.split('/')[0] for key in passed)
    assert dict(counts) == expected, (name, counts)
    row = {'campaign': name, 'source': campaign['core_revision'], 'status': campaign['status'],
           'result_sha256': hashlib.sha256(raw).hexdigest(), 'passed_unique_ids': dict(counts),
           'failures': [row for row in journal if row.get('status') == 'failed']}
    if name == 'common-additional-hardware-0db0689':
        expected_vectors = {(*identity, triggered, idle, repeats, delay, plays, dppi)
                            for identity in itertools.product((20, 21, 22), range(4), (1000, 4000))
                            for idle, dppi in itertools.product((0, 1), repeat=2)
                            for triggered, repeats, delay, plays in ((0, 0, 0, 52), (0, 9, 3, 4), (1, 0, 0, 1))}
        actual_vectors = {tuple(map(int, key.split('/')[1:])) for key in passed if key.startswith('V04-COMMON-PWM-MODES/')}
        assert actual_vectors == expected_vectors
        idle_results = collections.Counter()
        for entry in journal:
            if entry['id'].startswith('V04-COMMON-PWM-MODES/') and entry['id'].endswith('/raw'):
                vector = tuple(map(int, entry['id'].split('/')[1:10]))
                if vector[3] != 0:
                    continue
                idle = vector[4]
                assert entry['receiver'][5:7] == [idle, idle]
                assert [state[0] for state in entry['modes']] == [idle, idle]
                idle_results[str(idle)] += 1
        assert dict(idle_results) == {'0': 96, '1': 96}
        row['finite_terminal_idle_offline_audit'] = dict(idle_results)
        row['finite_terminal_idle_note'] = 'Captured192 finite raw traces; checked after execution, not a claim that original Host asserted final idle.'
    report['campaigns'].append(row)
output = WORK / 'common-completed-source-audit.json'
with output.open('x', encoding='utf-8') as stream:
    json.dump(report, stream, ensure_ascii=False, indent=2)
print(json.dumps(report, ensure_ascii=False))
