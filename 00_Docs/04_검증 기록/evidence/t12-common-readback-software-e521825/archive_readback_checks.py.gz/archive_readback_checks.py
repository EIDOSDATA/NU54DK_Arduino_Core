"""! @brief source를 고정한 최신 software 검사와 별도 원본 감사를 압축 보존합니다. """
import datetime
import gzip
import hashlib
import json
import re
import subprocess
from check_pc import REPO, WORK

revision = 'e5218255b3796d660a62da7c2dc518b6c1371b66'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == revision
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=REPO, text=True).strip()
names = ['common-qdec-readback-final-host', 'common-qdec-readback-exact-target', 'common-readback-style']
names += ['common-readback-software-' + gate for gate in ('contract', 'package', 'inventory', 'docs')]
files = []
checks = []
for name in names:
    record = json.loads((WORK / (name + '.json')).read_text())
    log = (WORK / (name + '.log')).read_bytes()
    assert record['exit_code'] == 0
    assert hashlib.sha256(log).hexdigest() == record['log_sha256']
    row = dict(record)
    if name.endswith('-host'):
        text = log.decode('utf-8')
        groups = list(map(int, re.findall(r'^Ran (\d+) tests? in ', text, re.M)))
        skipped = sum(map(int, re.findall(r'^OK \(skipped=(\d+)\)', text, re.M)))
        assert len(groups) == 91 and sum(groups) == 720 and skipped == 1
        assert 'FAILED (' not in text
        row.update(groups=len(groups), total=sum(groups), passed=sum(groups)-skipped, conditional_skipped=skipped)
    checks.append(row)
    files.extend([WORK / (name + suffix) for suffix in ('.json', '.log')])
files.extend([WORK / 'common-completed-source-audit.json', WORK / 'audit_completed_common.py',
              WORK / 'archive_readback_checks.py'])
private = json.loads((WORK / 'current-probe-uids.private.json').read_text(encoding='utf-8-sig'))
destination = WORK / 'evidence-staging/t12-common-readback-software-e521825'
assert not destination.exists()
destination.mkdir(parents=True)
manifest = {'schema_version': 1, 'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'source': revision, 'scope': 'Host/affected pair build/style/contract/package/inventory/docs only',
            'hardware_pass_claim': False, 'whole_t12_complete': False, 't13_physical_executed': False,
            'checks': checks, 'files': []}
for source in files:
    raw = source.read_bytes()
    for uid in private.values():
        assert uid.lower().encode() not in raw.lower(), source.name
    compressed = gzip.compress(raw, mtime=0)
    (destination / (source.name + '.gz')).write_bytes(compressed)
    manifest['files'].append({'path': source.name + '.gz', 'bytes': len(raw),
                              'raw_sha256': hashlib.sha256(raw).hexdigest(),
                              'gzip_sha256': hashlib.sha256(compressed).hexdigest()})
(destination / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print(json.dumps({'destination': str(destination), 'files': len(files), 'checks': len(checks)}))
