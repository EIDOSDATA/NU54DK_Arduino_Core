"""! @brief 현재 S 배치 종료 뒤 검사된 TWIM 계측·power 단계만 유한 실행합니다. """
import ctypes
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import sys
import time
from check_pc import REPO, WORK, PYTHON

folder = WORK/'t13-s-20260908'
output = folder/'unattended-s-followups-01.json'
assert not output.exists()
grant = json.loads((folder/'session-grant-repair3.json').read_text())
report = {'status': 'waiting-for-current-S-batch', 'jobs': [],
          'expires_at_unix': grant['expires_at_unix'], 'until': 'before-U-rewiring'}


def save():
    report['observed_at_utc'] = datetime.now(timezone.utc).isoformat()
    output.write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report), flush=True)


def execute(name, source, script, build, options, required):
    state = json.loads((WORK/'current_common_task_state.json').read_text(encoding='utf-8'))['active_t13_s']
    if any(state.get(key) for key in ('hardware_running', 't13_traffic_paused_by_user', 'requires_wiring_repair')):
        raise RuntimeError('active hardware, user pause or unresolved wiring prevents follow-up')
    if grant['expires_at_unix'] - time.time() < required:
        report['jobs'].append({'name': name, 'status': 'not-started-insufficient-session-time'})
        save()
        return False
    report.update(status='running', active=name)
    save()
    result = subprocess.run([str(PYTHON), '-X', 'utf8', '-B', str(WORK/script),
                             '--build', build, '--name', name, *options], cwd=REPO)
    path = folder/name/'result.json'
    data = json.loads(path.read_text()) if path.is_file() else {}
    executed = (WORK/(name+'-execute.json')).is_file()
    outcomes = [item for row in data.get('results', []) if row.get('status') == 'cleanup'
                for item in row.get('outcomes', [])]
    stopped = bool(outcomes and all(row.get('stopped') for row in outcomes))
    report['jobs'].append({'name': name, 'source': source, 'exit_code': result.returncode,
        'status': data.get('status', 'preflight-failed'), 'error': data.get('error'),
        'cleanup_proven': stopped, 'executed': executed})
    save()
    if executed:
        archived = subprocess.run([str(PYTHON), '-X', 'utf8', '-B',
            str(WORK/'archive_t13_campaign.py'), name, 't13-'+name+'-'+source[:7]], cwd=REPO)
        if archived.returncode:
            raise RuntimeError('follow-up archive failed; original requires review')
        if not stopped:
            raise RuntimeError('follow-up cleanup unproven; physical queue stopped')
    return result.returncode == 0 and data.get('status') == 'passed'


try:
    save()
    # @brief 처음 연 process handle을 유지하여 PID 재사용을 현재 실기 프로세스로 오인하지 않습니다.
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.OpenProcess.argtypes = (ctypes.c_uint32, ctypes.c_bool, ctypes.c_uint32)
    kernel.OpenProcess.restype = ctypes.c_void_p
    kernel.WaitForSingleObject.argtypes = (ctypes.c_void_p, ctypes.c_uint32)
    kernel.WaitForSingleObject.restype = ctypes.c_uint32
    kernel.CloseHandle.argtypes = (ctypes.c_void_p,)
    handle = kernel.OpenProcess(0x00100000, False, 13888)
    if not handle:
        raise RuntimeError('original batch process handle unavailable; inspect its final state')
    try:
        while True:
            result = kernel.WaitForSingleObject(handle, 20000)
            if result == 0:
                break
            if result != 258:
                raise RuntimeError('original process wait failed')
            if time.time() >= grant['expires_at_unix']:
                raise RuntimeError('S confirmation ended while prior batch was running')
    finally:
        kernel.CloseHandle(handle)
    previous = json.loads((folder/'unattended-s-01.json').read_text())
    if previous['status'] != 'finished-available-fixed-S-jobs':
        raise RuntimeError('prior batch did not finish with all attempted cleanup proven')

    for case, instance in ((16, 20), (17, 21), (18, 22), (19, 30)):
        execute(f'twi{instance}-proof-sauto-01', '21141876d076937085b86afead3339a9a4608bc2',
            'run_t13_auto_recovery.py', 'C:/t4i04', ['--phase', 'serial-fault', '--cases', str(case),
            '--fault-mode', '4'], 300)

    source = 'de5ad42ffdc8d38af04ee0d9cf1f7569e2c7e40f'
    ready = (folder/'power-builds.json').is_file()
    if ready:
        bridge = execute('power-bridge-sauto-01', source, 'run_t13_power.py', 'C:/t4p04',
                         ['--phase', 'bridge'], 60)
        if bridge:
            passed = {}
            for phase in ('timer', 'gpio'):
                passed[phase] = execute('power-'+phase+'-preflight-sauto-01', source,
                    'run_t13_power.py', 'C:/t4p04', ['--phase', phase, '--repeats', '1'], 60)
            for phase in ('timer', 'gpio'):
                if passed[phase]:
                    execute('power-'+phase+'-100-sauto-01', source, 'run_t13_power.py', 'C:/t4p04',
                            ['--phase', phase, '--repeats', '100'], 600)
        else:
            report['power_dependent_phases'] = 'not-started; bridge normal-mode proof failed'
    else:
        report['power_dependent_phases'] = 'not-started; exact build registration not ready'
    report.pop('active', None)
    report['status'] = 'finished-available-followups'
    save()
except BaseException as error:
    report.update(status='stopped-requires-review', error=f'{type(error).__name__}: {error}')
    save()
    raise
