"""! @brief power 예행·실행 원본을 분리하여 저장합니다. """
from pathlib import Path
helper = Path(__file__).with_name('run_t13_recovery.py')
source = helper.read_text(encoding='utf-8').replace('launch_t13_recovery.py', 'launch_t13_power.py')
exec(compile(source, str(helper), 'exec'))
