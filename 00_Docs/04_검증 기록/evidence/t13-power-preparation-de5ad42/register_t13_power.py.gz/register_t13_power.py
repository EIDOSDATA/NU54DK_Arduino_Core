"""! @brief power와 일반 S의 exact build 및 원격 Host 성공 후에만 실행 이미지를 등록합니다. """
import json
from pathlib import Path
import sys
from check_pc import WORK

repo = Path('C:/tspow04')
sys.path.insert(0, str(repo/'tests/hil/nu54dk'))
import v04_pair as pair
source = 'de5ad42ffdc8d38af04ee0d9cf1f7569e2c7e40f'
for family, root in (('t13_power_s', 'C:/t4p04'), ('t13_s', 'C:/t4j04')):
    images = [pair.inspect_image(repo, Path(root), role, family=family) for role in (1, 2)]
    assert all(image['core_revision'] == source for image in images)
    for image in images:
        config = (image['path'].parent/'.config').read_text()
        assert ('CONFIG_NUCODE_T13_POWER=y' in config) == (family == 't13_power_s')
        if family == 't13_power_s':
            assert 'CONFIG_RETAINED_MEM_NRF_RAM_CTRL=y' in config
            assert 'CONFIG_POWEROFF=y' in config
gates = ['t13-power-exact-target-02', 't13-power-exact-normal-target-01',
         't13-power-exact-host-01', 't13-power-exact-style-01',
         't13-power-exact-docs-01', 't13-power-exact-contract-01', 't13-power-matrix-host-01']
assert all(json.loads((WORK/(gate+'.json')).read_text())['exit_code'] == 0 for gate in gates)
ci = json.loads((WORK/'t13-s-20260908/ci-de5ad42-01.json').read_text())
assert any(row['name'] == 'Host unit with Windows PowerShell contracts' and
           row['conclusion'] == 'success' for row in ci['checks'])
path = WORK/'t13-s-20260908/power-builds.json'
assert not path.exists()
path.write_text(json.dumps({'C:/t4p04': {'source': source, 'repository': str(repo),
    'local_gates': gates, 'remote_exact_host': 'ci-de5ad42-01;101 groups/778 tests PASS',
    'normal_image_regression_build': 'C:/t4j04',
    'scope': 'S UART21/P1.06-07 relay; B normal debug detach proof; timer/P1.14 wake'}}, indent=2)+'\n')
print('registered C:/t4p04; no physical access')
