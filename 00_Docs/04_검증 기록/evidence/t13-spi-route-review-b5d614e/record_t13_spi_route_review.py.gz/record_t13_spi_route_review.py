"""! @brief 회로도 대조와 실제 첫 오류 GPIO의 추론 경계를 보존합니다. """
import hashlib
import json
from pathlib import Path
from datetime import datetime, timezone

repo = Path('C:/Users/eidos/GitHub/NU54DK_Arduino_Core')
path = repo/'board_package/NU54DK_Zephyr_DTS/NU54-DK Schematic.pdf'
folder = Path(__file__).parent/'t13-s-20260908'
output = folder/'spi-route-review-2105-01.json'
assert not output.exists()
report = {'observed_at_utc': datetime.now(timezone.utc).isoformat(), 'physical_access': False,
    'board_source': 'fe65f2f0880bd05b32e562d9bf1ee59142b4f4d3',
    'schematic': str(path.relative_to(repo)), 'pdf_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
    'viewed_pages': [1, 6], 'rendered_pages': {},
    'facts': ['Sheet1: P1.07 via SB12 to UARTE_CTS. P1.06 via SB11 to UARTE_RTS.',
              'Sheet6: UARTE_CTS is U7 SN74AVC4T245 A-side; output enable shares DISABLE_UART.',
              'Sheet1: LED1=P2.09, LED2=P1.10, LED3=P2.07, LED4=P1.14; none is P1.07.',
              'Current S tests retain the owner-confirmed DAP UART disabled state; no new switch operation.'],
    'observations': ['b5d614e SPI20 reversed A SPIS RX and SPI21/22 normal A SPIM RX first mismatches share B P1.06 to A P1.07.',
                     'Digital wiring checks do not independently measure8MHz edge/hold margins.'],
    'unproven': ['Actual board jumper state beyond owner declaration and digital checks',
                 'Capacitance, ringing, signal timing, physical source of the data mismatch',
                 'That the separate I2S B receiver mismatch has the same root cause'],
    'next_evidence': ['Compare fixed route at lower SPI clock or controlled RX delay in a separate diagnostic source.',
                      'Keep all payload/guard/cleanup checks and distinguish diagnostic clock from8MHz qualification.',
                      'No core timing workaround or LED-load cause asserted from this schematic review.']}
for page in (1, 6):
    rendered = Path(__file__).parent/f'common-fixture-review/page-{page}.png'
    report['rendered_pages'][str(page)] = hashlib.sha256(rendered.read_bytes()).hexdigest()
output.write_text(json.dumps(report, indent=2)+'\n')
print('schematic route review preserved; no physical access')
