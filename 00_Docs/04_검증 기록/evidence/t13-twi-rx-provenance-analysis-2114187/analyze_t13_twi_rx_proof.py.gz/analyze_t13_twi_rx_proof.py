"""! @brief 끝난 TWIM 진단 원본에서 이전 AMOUNT·새 RX 이벤트·RAM을 읽기만 대조합니다. """
from datetime import datetime, timezone
import json
import sys
from check_pc import WORK

folder = WORK/'t13-s-20260908'
target = folder/(sys.argv[1]+'.json')
assert not target.exists()
report = {'physical_access': False, 'observed_at_utc': datetime.now(timezone.utc).isoformat(),
          'historical_verdicts_unchanged': True, 'campaigns': []}
queue = json.loads((folder/'unattended-s-followups-01.json').read_text())
for job in queue['jobs']:
    if not job['name'].startswith('twi') or not job['executed']:
        continue
    data = json.loads((folder/job['name']/'result.json').read_text())
    assert data['status'] in ('passed', 'failed')
    records = {row['id']: row for row in data['results']}
    observed = []
    for identifier, row in records.items():
        suffix = '/final/role1/twi-rx-provenance'
        if not identifier.endswith(suffix):
            continue
        stem = identifier[:-len(suffix)]
        proof = row['words']
        words = records[stem+'/final/role1/fault']['words']
        observed.append({'id': stem, 'raw_proof': proof, 'fault': words,
            'previous_rx_amount': proof[3], 'terminal_rx_amount': proof[16],
            'rx_start_end_events_all_clear': proof[4:10] == [0]*6,
            'whole_rx_ram_unchanged': proof[10] == 1,
            'rx_amount_equal_previous': proof[16] == proof[3],
            'partial_tx': 0 < proof[15] < proof[17],
            'same_terminal_event': proof[12:15] == words[12:15] and proof[15:17] == words[16:18]})
    report['campaigns'].append({'name': job['name'], 'source': data['core_revision'],
        'status': data['status'], 'cleanup_proven': job['cleanup_proven'], 'observations': observed})
target.write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps(report))
