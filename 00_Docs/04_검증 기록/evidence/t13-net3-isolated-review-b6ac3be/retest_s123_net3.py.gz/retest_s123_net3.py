"""! @brief 새 LOW 전달 실패의 동일 한 선만 등록된 exact image로 재검사합니다. """
import json
import subprocess
from pathlib import Path
from check_pc import WORK

FOLDER = WORK / 't13-s-20260908'
SOURCE = 'b6ac3befdc86daa058a9225abbdcf7b275f6de8f'
registration = json.loads((FOLDER / 'parity-builds.json').read_text(encoding='utf-8'))
record = registration['C:/t5f15']
assert record['source'] == SOURCE
for name in record['local_gates']:
    assert json.loads((WORK / (name + '.json')).read_text(encoding='utf-8'))['exit_code'] == 0
checks = json.loads(subprocess.check_output([
    'C:/Program Files/GitHub CLI/gh.exe', 'api',
    'repos/EIDOSDATA/NU54DK_Arduino_Core/commits/' + SOURCE + '/check-runs']))['check_runs']
host = max((row for row in checks if row['name'] == 'Host unit with Windows PowerShell contracts'),
           key=lambda row: row['id'])
assert host['status'] == 'completed' and host['conclusion'] == 'success'
state_path = WORK / 'current_common_task_state.json'
state = json.loads(state_path.read_text(encoding='utf-8'))
assert not state['active_t13_s']['hardware_running']
state['active_t13_s'].update(requires_wiring_repair=True,
    checkpoint='Net3 LOW mismatch requires isolated diagnosis; protocol HIL held pending evidence review')
state_path.write_text(json.dumps(state, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
helper = WORK / 'retest_failed_t13_gpio.py'
source = helper.read_text(encoding='utf-8')
for before, after in (
    ('C:/tr13dev', 'C:/tpar04'), ('C:/t4c04', 'C:/t5f15'),
    ('session-grant-repair3.json', 'session-grant-s123-01.json'),
    ('43bc0320d6681d57d2ec1cd569fef35f7dd8ec0d', SOURCE),
    ('p204-p202-retest-43bc032-attempt1.json', 's123-net3-retest-b6ac3be-01.json'),
    ('net 15', 'net 3'), ('A P2.04 to B P2.02', 'A P1.04 to B P1.05'),
    ("'driven_net_indices_zero_based': [14]", "'driven_net_indices_zero_based': [2]"),
    ('for net in (14,):', 'for net in (2,):'),
    ('t13_traffic_paused_by_user=True', 't13_traffic_paused_by_user=False'),
    ('User requested only failed net 3 retest; T13 remains paused; single open-drain only',
     'Approved S continuation: isolate failed net3 only; protocol held; single open-drain only')):
    assert before in source, before
    source = source.replace(before, after)
assert not (FOLDER / 's123-net3-retest-b6ac3be-01.json').exists()
exec(compile(source, str(helper), 'exec'))
