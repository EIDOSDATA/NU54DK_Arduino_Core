"""! @brief 전체 S 재검사의 비실기 gate와 실제 실행을 순서대로 보존합니다. """
from pathlib import Path
helper = Path(__file__).with_name('run_t13_parity.py')
source = helper.read_text(encoding='utf-8').replace('launch_t13_parity.py', 'launch_s123_wiring_review.py')
exec(compile(source, str(helper), 'exec'))
