"""! @brief 진단 대기 상태에서는 기존 exact 결선 검사만 허용합니다. """
from pathlib import Path

helper = Path(__file__).with_name('launch_t13_parity.py')
source = helper.read_text(encoding='utf-8')
source = source.replace("choices=('preflight', 'soak'", "choices=('wiring', 'preflight', 'soak'")
source = source.replace("if args.phase not in ('stream-fault-preflight'", "if args.phase not in ('wiring', 'stream-fault-preflight'")
source = source.replace("args = parser.parse_args()", "args = parser.parse_args()\nif args.phase != 'wiring' or args.cases:\n    raise SystemExit('Only full S wiring review is allowed')")
source = source.replace("if args.mode == 'execute' and state['active_t13_s'].get('requires_wiring_repair'):",
    "if args.mode == 'execute' and args.phase != 'wiring' and state['active_t13_s'].get('requires_wiring_repair'):")
exec(compile(source, str(helper), 'exec'))
