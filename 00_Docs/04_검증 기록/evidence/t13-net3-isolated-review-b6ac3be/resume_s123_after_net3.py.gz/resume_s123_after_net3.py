"""! @brief 새 한 선·전체 결선 증거를 확인하고 미실행 잔여만 준비합니다. """
import datetime
import json
from check_pc import WORK

folder = WORK / 't13-s-20260908'
isolated = json.loads((folder / 's123-net3-retest-b6ac3be-01.json').read_text(encoding='utf-8'))
assert isolated['status'] == 'passed' and isolated['completed_pulses'] == 20
assert isolated['mismatch_count'] == 0
assert all(not (value & 1) for row in isolated['postflight'] for value in row['pin_cnf'].values())
full = json.loads((folder / 'net3-full-s-wiring-review-01/result.json').read_text(encoding='utf-8'))
assert full['status'] == 'passed' and full['phase'] == 'wiring'
passed = [row for row in full['results'] if row.get('status') == 'passed']
assert len(passed) == 105 and all(row['id'].startswith('V04-WIRING/') for row in passed)
cleanups = [row for row in full['results'] if row.get('status') == 'cleanup']
assert len(cleanups) == 3
assert all({outcome['role'] for outcome in row['outcomes']} == {1, 2} and
           all(outcome['stopped'] for outcome in row['outcomes']) for row in cleanups)
path = folder / 's123-existing42-02.json'
with path.with_suffix('.before-net3-review.json').open('xb') as output:
    output.write(path.read_bytes())
batch = json.loads(path.read_text(encoding='utf-8'))
row = batch['conditions'][-1]
assert row['condition'] == 'break-c2-r2' and row['status'] == 'running'
row.update(status='not-run', reason='Net3 wiring precheck failed before UART recovery started',
           wiring_attempt='s123-02-break-c2-r2-preflight-01')
batch.update(reviewed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
             subsequent_wiring='net3-full-s-wiring-review-01', physical_pass_added=False)
path.write_text(json.dumps(batch, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
finished = {row['condition'] for row in batch['conditions'] if row['status'] != 'not-run'}
helper = WORK / 'run_t13_remaining42.py'
source = helper.read_text(encoding='utf-8').replace('s123-existing42-02.json', 's123-existing30-03.json')
source = source.replace("report = {'scope':", "items = [item for item in items if item[0] not in " + repr(finished) + "]\nassert len(items) == 30\nreport = {'scope':")
source = source.replace('s123-02-', 's123-03-').replace('Remaining S42 after CTS12', 'Remaining unexecuted S30 after full wiring review')
with (WORK / 'run_t13_remaining30.py').open('x', encoding='utf-8') as output:
    output.write(source)
state_path = WORK / 'current_common_task_state.json'
state = json.loads(state_path.read_text(encoding='utf-8'))
assert not state['active_t13_s']['hardware_running']
state['active_t13_s'].update(requires_wiring_repair=False,
    checkpoint='Isolated net3 20/20 and new full wiring105/105 passed; only unexecuted S30 resume',
    last_wiring_review='net3-full-s-wiring-review-01')
state_path.write_text(json.dumps(state, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print('Verified both-board GPIO return; prepared 30 unexecuted conditions; original wiring failure preserved')
