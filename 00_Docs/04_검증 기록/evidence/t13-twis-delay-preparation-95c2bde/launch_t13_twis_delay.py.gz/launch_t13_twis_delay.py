"""! @brief TWIS 최초 write 요청의2ms 공급 지연을 기존 보호 조건과 함께 검사합니다. """
from pathlib import Path
helper = Path(__file__).with_name('launch_t13_recovery.py')
source = helper.read_text(encoding='utf-8').replace("Path('C:/tr13dev')", "Path('C:/tstwd04')")
source = source.replace("'recovery-builds.json'", "'twis-delay-builds.json'")
source = source.replace("'pwm-recovery-preflight', 'pwm-recovery'), required=True)",
    "'pwm-recovery-preflight', 'pwm-recovery', 'twis-delay-preflight', 'twis-delay'), required=True)")
assert "'twis-delay'" in source
exec(compile(source, str(helper), 'exec'))
