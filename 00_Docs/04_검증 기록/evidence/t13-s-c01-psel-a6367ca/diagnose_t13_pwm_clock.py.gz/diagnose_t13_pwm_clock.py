"""! @brief 동일 승인 시험에서 HFXO 참조 유무를 10초씩 비교하고 최초 실패를 보존합니다. """
import argparse
from contextlib import ExitStack
import json
import logging
from pathlib import Path
import sys
import time
import subprocess
from check_pc import REPO, WORK, SDK
sys.path.insert(0, str(REPO/'tests/hil/nu54dk'))
import v04_pair as pair
import v04_t13_cases as catalog
import v04_t13_run as runner
import v04_t13_session as session
import v04_wiring as wiring
from v04_protocol import ProbeLocks, ProtocolError
from pyocd.core.helpers import ConnectHelper
logging.disable(logging.CRITICAL)
parser = argparse.ArgumentParser()
parser.add_argument('--build', required=True, type=Path)
parser.add_argument('--name', required=True)
parser.add_argument('--source', required=True)
parser.add_argument('--case', type=int, choices=(25, 101), default=25)
parser.add_argument('--gate-prefix', default='t13-s-pwm-clock')
parser.add_argument('--remote-host', action='store_true')
args = parser.parse_args()
for suffix in ('host-01', 'full-host-01', 'style-01', 'docs-01', 'exact-target-01'):
    if suffix == 'full-host-01' and args.remote_host:
        continue
    gate = args.gate_prefix+'-'+suffix
    assert json.loads((WORK/(gate+'.json')).read_text(encoding='utf-8'))['exit_code'] == 0, gate
folder = WORK/'t13-s-20260908'
private = json.loads((folder/'probe-uids-local.json').read_text(encoding='utf-8'))
grant = json.loads((folder/'session-grant-repair1.json').read_text(encoding='utf-8'))
uids = [private[key].lower() for key in grant['uid_sha256']]
images = [pair.inspect_image(REPO, args.build, role, family='t13_s') for role in (1, 2)]
assert all(image['core_revision'] == args.source for image in images)
host_gate = None
if args.remote_host:
    checks = json.loads(subprocess.check_output(['C:/Program Files/GitHub CLI/gh.exe', 'api',
        'repos/EIDOSDATA/NU54DK_Arduino_Core/commits/'+args.source+'/check-runs'], cwd=REPO))['check_runs']
    host = [row for row in checks if row['name'] == 'Host unit with Windows PowerShell contracts']
    assert len(host) == 1 and host[0]['status'] == 'completed' and host[0]['conclusion'] == 'success'
    host_gate = {'source': args.source, **{key: host[0][key] for key in ('name', 'status', 'conclusion', 'html_url')}}
session.validate(grant, images, uids)
evidence = {'type': 'bounded-clock-comparison', 'source': args.source, 'soak_pass': False,
            'duration_per_mode_seconds': 10, 'case_id': args.case, 'remote_host_gate': host_gate,
            'images': json.loads(json.dumps(images, default=str)), 'results': []}
output = folder/args.name
output.mkdir(exist_ok=False)
(output/'images.json').write_text(json.dumps(images, default=str, indent=2), encoding='utf-8')
with pair.evidence_session(output/'result.json', evidence) as journal, ProbeLocks(uids), ExitStack() as stack:
    def append(identifier, row):
        entry = {'id': identifier, **row}
        evidence['results'].append(entry)
        journal.write(json.dumps(entry, ensure_ascii=False)+'\n')
        journal.flush()
    def available():
        return {probe.unique_id.lower() for probe in ConnectHelper.get_all_connected_probes(blocking=False)}
    devices = []
    for uid, image in zip(uids, images):
        session.validate(grant, images, uids)
        device, flash = pair.boot_exact(stack, ConnectHelper, SDK/'opt/bin/Scripts/pyocd.exe', uid,
            image, 10000000, cmsis_dap_limit_packets=True)
        devices.append(device)
        append(f'flash/role{image["role"]}', {'status': 'input', 'flash': flash})
        session.verify_profile(device)
    continuity = session.Continuity(grant, images, uids, devices, available, pair.verify_identity)
    wiring.run_checks(devices, append, continuity.check)
    test = next(row for row in catalog.cases() if row['id'] == args.case)
    for mode in (0, 1):
        label = f'{test["name"]}/crystal{mode}'
        continuity.check()
        failure = None
        try:
            for device in devices:
                assert device.command(106, (mode,), timeout=2) == [1]
            for device in reversed(devices):
                assert device.command(97, (args.case, 12345+mode, 0x53414645), timeout=3) == [1]
            for device in reversed(devices):
                assert device.command(98, timeout=2) == [1]
            for device in devices:
                clock = device.command(107, (0,), timeout=2)
                append(label+f'/begin/clock{device.image["role"]}',
                       {'status': 'observation', 'words': clock})
                assert clock[:2] == [mode, mode]
                if mode:
                    assert clock[2] != 0
            start = time.monotonic()
            time.sleep(.3)
            tick = 0
            while time.monotonic()-start < 10:
                continuity.check()
                runner.snapshots(devices, test, 12345+mode, append, label+f'/sample{tick}')
                for device in devices:
                    append(label+f'/sample{tick}/clock{device.image["role"]}',
                           {'status': 'observation', 'words': device.command(107, (0,), timeout=2)})
                    assert device.command(103, timeout=2) == [1]
                tick += 1
                time.sleep(.5)
        except BaseException as error:
            failure = f'{type(error).__name__}: {error}'
            append(label+'/failure', {'status': 'failed', 'error': failure})
        finally:
            for device in devices:
                for page in range(5):
                    try:
                        append(label+f'/trace/role{device.image["role"]}/page{page}',
                               {'status': 'observation', 'words': device.command(107, (page,), timeout=2)})
                    except BaseException as error:
                        append(label+'/trace-unproven', {'status': 'unproven', 'error': str(error)})
                        break
            stopped = runner.stop_pair(devices, append, label+'/cleanup')
            idle = runner.idle_pins(devices, append, label+'/pins')
            for device in devices:
                clock = device.command(107, (0,), timeout=2)
                append(label+f'/stopped/clock{device.image["role"]}',
                       {'status': 'observation', 'words': clock})
                assert clock[1] == 0, 'PWM clock reference not released'
        append(label+'/comparison', {'status': 'diagnostic', 'observed_failure': failure,
                                     'stopped': stopped, 'pins_idle': idle, 'formal_t13_pass': False})
        print(json.dumps({'mode': mode, 'failure': failure, 'stopped': stopped, 'idle': idle}), flush=True)
        if not stopped or not idle:
            raise ProtocolError('clock diagnostic cleanup unproven')
