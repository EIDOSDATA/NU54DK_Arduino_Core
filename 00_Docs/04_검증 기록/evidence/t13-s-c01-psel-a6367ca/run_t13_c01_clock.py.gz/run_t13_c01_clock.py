"""! @brief C01 제한 clock 비교의 현재 상태·출력·실패를 기록합니다. """
import json
import os
from check_pc import PYTHON, WORK, run
state_path = WORK/'current_common_task_state.json'
name = 'c01-clock-comparison-a6367ca-01'
state = json.loads(state_path.read_text(encoding='utf-8-sig'))
state['active_t13_s'].update(hardware_running=True,
    source='a6367caf42578d8dd825186d229cfa902a82a562', build_root='C:/t3m04',
    phase='bounded-c01-clock-diagnostic', campaign=str(WORK/'t13-s-20260908'/name))
state_path.write_text(json.dumps(state, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
try:
    result = run(name+'-execution', (PYTHON, '-X', 'utf8', '-B', WORK/'run_ncs.py',
        'diagnose_t13_pwm_clock.py', '--build', 'C:/t3m04', '--name', name,
        '--source', 'a6367caf42578d8dd825186d229cfa902a82a562', '--case', '101',
        '--gate-prefix', 't13-s-general-clock', '--remote-host'), os.environ.copy())
finally:
    state = json.loads(state_path.read_text(encoding='utf-8'))
    state['active_t13_s'].update(hardware_running=False,
        checkpoint='C01 clock comparison ended; inspect first failures and both cleanup results')
    state_path.write_text(json.dumps(state, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
raise SystemExit(result)
