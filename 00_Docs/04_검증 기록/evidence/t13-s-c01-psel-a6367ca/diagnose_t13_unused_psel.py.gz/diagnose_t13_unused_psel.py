"""! @brief SPI21 전후 C01 준비 상태의 PSEL을 읽고 C01 송수신은 시작하지 않습니다. """
import json
import logging
import subprocess
import sys
from contextlib import ExitStack
from check_pc import REPO, WORK, SDK
sys.path.insert(0, str(REPO/'tests/hil/nu54dk'))
import v04_pair as pair
import v04_t13_cases as catalog
import v04_t13_run as runner
import v04_t13_session as session
import v04_wiring as wiring
from v04_protocol import ProbeLocks, ProtocolError
from pyocd.core.helpers import ConnectHelper
logging.disable(logging.CRITICAL)
folder = WORK/'t13-s-20260908'
source = 'a6367caf42578d8dd825186d229cfa902a82a562'
for suffix in ('host-01', 'style-01', 'docs-02', 'exact-target-01'):
    assert json.loads((WORK/('t13-s-general-clock-'+suffix+'.json')).read_text(encoding='utf-8'))['exit_code'] == 0
checks = json.loads(subprocess.check_output(['C:/Program Files/GitHub CLI/gh.exe', 'api',
    'repos/EIDOSDATA/NU54DK_Arduino_Core/commits/'+source+'/check-runs'], cwd=REPO))['check_runs']
assert any(row['name'] == 'Host unit with Windows PowerShell contracts' and
           row['conclusion'] == 'success' for row in checks)
private = json.loads((folder/'probe-uids-local.json').read_text(encoding='utf-8'))
grant = json.loads((folder/'session-grant-repair1.json').read_text(encoding='utf-8'))
uids = [private[key].lower() for key in grant['uid_sha256']]
images = [pair.inspect_image(REPO, __import__('pathlib').Path('C:/t3m04'), role, family='t13_s') for role in (1, 2)]
assert all(image['core_revision'] == source for image in images)
session.validate(grant, images, uids)
output = folder/'unused-psel-a6367ca-01'
output.mkdir(exist_ok=False)
(output/'images.json').write_text(json.dumps(images, default=str, indent=2), encoding='utf-8')
evidence = {'type': 'prepare-only-unused-psel-diagnostic', 'source': source,
            'C01_started': False, 'formal_t13_pass': False, 'results': []}
with pair.evidence_session(output/'result.json', evidence) as journal, ProbeLocks(uids), ExitStack() as stack:
    def append(identifier, row):
        entry = {'id': identifier, **row}
        evidence['results'].append(entry)
        journal.write(json.dumps(entry, ensure_ascii=False)+'\n')
        journal.flush()
    devices = []
    for uid, image in zip(uids, images):
        session.validate(grant, images, uids)
        device, flash = pair.boot_exact(stack, ConnectHelper, SDK/'opt/bin/Scripts/pyocd.exe', uid,
            image, 10000000, cmsis_dap_limit_packets=True)
        devices.append(device)
        append(f'flash/role{image["role"]}', {'status': 'input', 'flash': flash})
        session.verify_profile(device)
    def available():
        return {probe.unique_id.lower() for probe in ConnectHelper.get_all_connected_probes(blocking=False)}
    continuity = session.Continuity(grant, images, uids, devices, available, pair.verify_identity)
    wiring.run_checks(devices, append, continuity.check)
    for phase in ('cold', 'after-spi21'):
        if phase == 'after-spi21':
            spi = next(row for row in catalog.cases() if row['id'] == 8)
            runner.execute_group(devices, runner.grouped([spi])[0], 3, continuity, append, preflight=True)
        continuity.check()
        try:
            for device in reversed(devices):
                assert device.command(106, (1,), timeout=2) == [1]
                assert device.command(97, (101, 88231, 0x53414645), timeout=3) == [1]
            for device in devices:
                for instance, base in ((20, 0x500C6000), (21, 0x500C7000), (22, 0x500C8000)):
                    row = {'status': 'observation', 'role': device.image['role'], 'instance': instance,
                           'enable': device.target.read32(base+0x500),
                           'config': device.target.read32(base+0x56C),
                           'psel_600_610': list(device.target.read_memory_block32(base+0x600, 5))}
                    append(phase+f'/role{device.image["role"]}/serial{instance}', row)
                    if instance == 21:
                        print(json.dumps({'phase': phase, **row}), flush=True)
        finally:
            stopped = runner.stop_pair(devices, append, phase+'/cleanup')
            idle = runner.idle_pins(devices, append, phase+'/pins')
        if not stopped or not idle:
            raise ProtocolError('prepare-only diagnostic cleanup unproven')
