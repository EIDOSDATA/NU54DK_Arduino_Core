"""! @brief 동시 CTS 배치 뒤 확인 잔여시간 안에서 단독 UART RX 공급 지연을 검사합니다. """
from pathlib import Path

helper = Path(__file__).with_name('unattended_t13_followups.py')
prefix = helper.read_text(encoding='utf-8').split('\ntry:\n    save()')[0]
prefix = prefix.replace("'unattended-s-followups-01.json'", "'unattended-s-rx-delay-01.json'")
prefix = prefix.replace("'waiting-for-current-S-batch'", "'waiting-for-concurrent-flow-tests'")
exec(compile(prefix, str(helper), 'exec'))

try:
    save()
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.OpenProcess.argtypes = (ctypes.c_uint32, ctypes.c_bool, ctypes.c_uint32)
    kernel.OpenProcess.restype = ctypes.c_void_p
    kernel.WaitForSingleObject.argtypes = (ctypes.c_void_p, ctypes.c_uint32)
    kernel.WaitForSingleObject.restype = ctypes.c_uint32
    kernel.CloseHandle.argtypes = (ctypes.c_void_p,)
    handle = kernel.OpenProcess(0x00100000, False, 27352)
    if not handle:
        raise RuntimeError('original concurrent CTS process handle unavailable; review final state')
    try:
        while True:
            result = kernel.WaitForSingleObject(handle, 20000)
            if result == 0:
                break
            if result != 258:
                raise RuntimeError('concurrent CTS process wait failed')
            if time.time() >= grant['expires_at_unix']:
                raise RuntimeError('S confirmation ended while prior concurrent CTS tests were running')
    finally:
        kernel.CloseHandle(handle)
    previous = json.loads((folder/'unattended-s-concurrent-flow-01.json').read_text())
    if previous['status'] != 'finished-available-concurrent-flow-tests':
        raise RuntimeError('prior concurrent CTS tests did not finish with attempted cleanup proven')
    records = json.loads((folder/'rx-delay-builds.json').read_text())
    if len(records) != 1:
        raise RuntimeError('one exact RX delay build registration required')
    build, record = next(iter(records.items()))
    source = record['source']
    passed = []
    for case in (2, 3, 4, 5):
        for role in (1, 2):
            name = f'uartrx{case}-r{role}'
            options = ['--cases', str(case), '--fault-role', str(role)]
            if execute(name+'-preflight-sauto-01', source, 'run_t13_rx_delay.py', build,
                       ['--phase', 'rx-delay-preflight', *options], 120):
                passed.append((name, options))
    for name, options in passed:
        execute(name+'-100-sauto-01', source, 'run_t13_rx_delay.py', build,
                ['--phase', 'rx-delay', *options], 900)
    report.pop('active', None)
    report['status'] = 'finished-available-rx-delay-tests'
    save()
except BaseException as error:
    report.update(status='stopped-requires-review', error=f'{type(error).__name__}: {error}')
    save()
    raise
