"""! @brief 실기 원본의 두 역할 STOP·clock·GPIO 반환을 읽기 전용으로 다시 대조합니다. """
import gzip
import json
from pathlib import Path
from datetime import datetime, timezone
import sys
from check_pc import REPO, WORK

output = WORK/'t13-s-20260908'/(sys.argv[1]+'.json')
assert not output.exists()
report = {'observed_at_utc': datetime.now(timezone.utc).isoformat(), 'physical_access': False, 'campaigns': []}
for manifest_path in sorted((REPO/'00_Docs/04_검증 기록/evidence').glob('t13-*-sauto-01-*/manifest.json')):
    manifest = json.loads(manifest_path.read_text())
    data = json.loads(gzip.decompress((manifest_path.parent/'result.json.gz').read_bytes()))
    rows = data['results']
    cleanups = [row for row in rows if row['status'] == 'cleanup' and row.get('outcomes')]
    assert cleanups
    for row in cleanups:
        assert sorted(item['role'] for item in row['outcomes']) == [1, 2], row['id']
        for outcome in row['outcomes']:
            assert outcome['stopped'], row['id']
            if 'clock' in outcome:
                assert outcome['clock'][1] == 0
            if 'pin_cnf' in outcome:
                assert len(outcome['pin_cnf']) == 17 and all(value & 0xD == 0 for value in outcome['pin_cnf'])
    ordinary = not data['phase'] in ('bridge', 'timer', 'gpio')
    intermediate = [row for row in rows if 'idle' in row]
    assert all(row['idle'] is True for row in intermediate)
    if ordinary:
        if data['status'] == 'passed':
            final = [row for row in rows if row['id'].startswith('T13-S/final-pins/role')]
        else:
            last_cleanup = max(index for index, row in enumerate(rows) if row is cleanups[-1])
            final = [row for row in rows[last_cleanup+1:] if 'idle' in row]
        assert sorted(row['id'].rsplit('role', 1)[1] for row in final) == ['1', '2'], manifest_path
        assert all(row['words'][1:4] == [0, 0, 0] and row['words'][7] == 0 for row in final)
    report['campaigns'].append({'archive': manifest_path.parent.name, 'source': manifest['source'],
        'original_status': data['status'], 'both_role_cleanup_groups': len(cleanups),
        'intermediate_idle_records': len(intermediate), 'final_pin_return_proven': True})
report['archives_verified'] = len(report['campaigns'])
output.write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps({'archives_verified': report['archives_verified'], 'all_final_pin_return_proven': True}))
