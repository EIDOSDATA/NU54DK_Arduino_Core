"""! @brief 실기 대열의 완료·실패·미시작을 합격 수와 구분해 읽기 전용으로 집계합니다. """
from collections import Counter
from datetime import datetime, timezone
import json
from pathlib import Path
import re
import sys

folder = Path(__file__).parent/'t13-s-20260908'
label = sys.argv[1]
assert re.fullmatch('[a-z0-9-]+', label)
output = folder/(label+'.json')
assert not output.exists()
report = {'observed_at_utc': datetime.now(timezone.utc).isoformat(),
          'physical_access': False, 'full_T13_complete': False, 'queues': [], 'groups': {}}
jobs = []
for path in sorted({*folder.glob('unattended-s-*-01.json'), folder/'unattended-s-01.json'}):
    state = json.loads(path.read_text())
    rows = state.get('jobs', [])
    report['queues'].append({'checkpoint': path.name, 'status': state['status'],
        'active': state.get('active'), 'error': state.get('error'), 'jobs': rows,
        'expires_at_unix': state.get('expires_at_unix')})
    jobs.extend(rows)
assert len({row['name'] for row in jobs}) == len(jobs)
for key, expression, planned in [('conflict_preflight', r'conflict.+-preflight-sauto-01', 14),
                                 ('conflict_100', r'conflict.+-100-sauto-01', 14),
                                 ('old_cts_preflight', r'flow\d+-r\d-preflight-sauto-01', 8),
                                 ('new_cts_preflight', r'flowbound-.+-preflight-sauto-01', 12),
                                 ('new_cts_100', r'flowbound-.+-100-sauto-01', 12)]:
    rows = [row for row in jobs if re.fullmatch(expression, row['name'])]
    counts = Counter(row['status'] for row in rows)
    report['groups'][key] = {'planned_conditions': planned, 'reported_conditions': len(rows),
        'status_counts': counts, 'passed_percent': round(counts['passed']*100/planned, 1),
        'note': 'A preflight is not a 100-repeat qualification; omitted active/unstarted jobs are not failures'}
output.write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps({'groups': report['groups'], 'queues': [
    {'name': row['checkpoint'], 'status': row['status'], 'active': row['active']} for row in report['queues']]}))
