"""! @brief 기존 UART 예행의 ARM 이전 ENABLE0·클록·종료 원본을 대조합니다. """
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

folder = Path(__file__).parent/'t13-s-20260908'
output = folder/'uart-arm-analysis-final-01.json'
assert not output.exists()
queue = json.loads((folder/'unattended-s-uart-line-01.json').read_text())
assert queue['status'] == 'finished-available-uart-line-tests'
report = {'observed_at_utc': datetime.now(timezone.utc).isoformat(), 'physical_access': False,
          'source': '93e38ff6176ac54bf8bf87fa7477933875ccae96', 'campaigns': [],
          'conclusion': 'The pre-RX ARM guard rejects ENABLE0 left by nrfx prepare_tx; no injected fault was reached',
          'rerun_required': True}
for job in queue['jobs']:
    if not job.get('executed'):
        continue
    path = folder/job['name']/'result.json'
    raw = path.read_bytes()
    data = json.loads(raw)
    assert data['status'] == 'failed' and data['error'].endswith('precision clock/arm failed')
    rows = data['results']
    prepared = [r for r in rows if '/repeat001/prepared/' in r['id'] and r['id'].endswith('/pins')]
    clock = [r for r in rows if '/repeat001/clock/' in r['id']]
    stopped = [r for r in rows if '/after-stop/' in r['id']]
    assert len(prepared) == 2 and all(r['words'][1] == 1 and r['words'][6] == 0 for r in prepared)
    assert len(clock) == 1 and clock[0]['words'][:3] == [1, 1, 65537]
    assert len(stopped) == 2 and all(r['words'][2:4] == [0, 0] and r['words'][19] == 1 for r in stopped)
    assert job['cleanup_proven']
    report['campaigns'].append({'name': job['name'], 'result_sha256': hashlib.sha256(raw).hexdigest(),
        'prepared_pins': prepared, 'clock': clock, 'after_stop': stopped,
        'original_status': 'failed', 'injected_fault_observed': False})
assert len(report['campaigns']) == 9
report['reference_files'] = []
for name in ('C:/tsline04/tests/zephyr/v04_t13_hil/src/uart_fault.cpp',
             'C:/ncs/v3.4.0/modules/hal/nordic/nrfx/drivers/src/nrfx_uarte.c'):
    path = Path(name)
    report['reference_files'].append({'path': name, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
output.write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps({'campaigns_analyzed': len(report['campaigns']), 'all_stopped': True}))
