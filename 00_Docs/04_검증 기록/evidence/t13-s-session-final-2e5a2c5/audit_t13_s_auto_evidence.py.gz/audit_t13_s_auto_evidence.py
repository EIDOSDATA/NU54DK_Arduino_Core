"""! @brief 종료된 자동 실기 archive의 해시·source·판정·양쪽 STOP을 읽기 전용 감사합니다. """
from collections import Counter
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import re
import sys
from check_pc import REPO, WORK

label = sys.argv[1]
assert re.fullmatch('[a-z0-9-]+', label)
output = WORK/'t13-s-20260908'/(label+'.json')
assert not output.exists()
root = REPO/'00_Docs/04_검증 기록/evidence'
report = {'kind': 'read-only-archive-audit', 'observed_at_utc': datetime.now(timezone.utc).isoformat(),
          'physical_access': False, 'campaigns': []}
for path in sorted(root.glob('t13-*-sauto-01-*/manifest.json')):
    manifest = json.loads(path.read_text())
    raw_result = None
    for item in manifest['files']:
        packed = (path.parent/item['file']).read_bytes()
        assert hashlib.sha256(packed).hexdigest() == item['gzip_sha256'], path
        raw = gzip.decompress(packed)
        assert len(raw) == item['bytes'] and hashlib.sha256(raw).hexdigest() == item['sha256'], path
        if item['file'] == 'result.json.gz':
            raw_result = json.loads(raw)
    assert raw_result and raw_result['core_revision'] == manifest['source'], path
    assert raw_result['status'] == manifest['status'] and manifest['physical_executed'], path
    assert raw_result['phase'] == manifest['phase'] and raw_result['status'] in ('passed', 'failed'), path
    outcomes = [entry for row in raw_result['results'] if row.get('status') == 'cleanup'
                for entry in row.get('outcomes', [])]
    assert {row['role'] for row in outcomes} == {1, 2}, path
    assert all(row.get('stopped') for row in outcomes), path
    flags = Counter(key for row in raw_result['results'] if row.get('status') == 'passed'
                    for key, value in row.items() if key.startswith('planned_') and value is True)
    report['campaigns'].append({'archive': path.parent.name, 'source': manifest['source'],
        'phase': manifest['phase'], 'status': manifest['status'], 'files_verified': len(manifest['files']),
        'all_cleanup_proven': True, 'passed_result_flags': dict(flags),
        'note': 'Step/repeat flags are not a count of fully qualified conditions'})
report['archives_verified'] = len(report['campaigns'])
output.write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps({'archives_verified': report['archives_verified'], 'output': str(output)}))
