"""! @brief C01 고구동 비교 종료 뒤 STOP 상태를 reset 없이 보존합니다. """

from pathlib import Path


work = Path(__file__).resolve().parent
source_path = work / 'read_cts_c101_failure_state.py'
source = source_path.read_text(encoding='utf-8')
source = source.replace(
    "CAMPAIGN = 'cts-c101-r1-834e-preflight-02'",
    "CAMPAIGN = 'cts-c101-r1-834e-driveh-watch-01'",
)
exec(compile(source, str(source_path), 'exec'))
