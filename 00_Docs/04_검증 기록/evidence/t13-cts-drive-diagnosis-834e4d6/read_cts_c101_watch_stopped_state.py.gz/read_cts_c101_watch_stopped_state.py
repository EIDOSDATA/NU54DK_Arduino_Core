"""! @brief C01 watchpoint 진단 종료 뒤 잔류 RAM을 원본 helper로 보존합니다. """
from pathlib import Path


work = Path(__file__).resolve().parent
source_path = work / 'read_cts_c101_failure_state.py'
source = source_path.read_text(encoding='utf-8')
source = source.replace(
    "CAMPAIGN = 'cts-c101-r1-834e-preflight-02'",
    "CAMPAIGN = 'cts-c101-r1-834e-watch-01'",
)
source = source.replace(
    "f'{CAMPAIGN}-stopped-debugger-state-01.json'",
    "f'{CAMPAIGN}-stopped-debugger-state-01.json'",
)
exec(compile(source, str(source_path), 'exec'))
