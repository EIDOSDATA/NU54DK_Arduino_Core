"""! @brief C01 S0S1 실패와 H0H1 비교 결과를 독립 대조합니다. """

import hashlib
import json
from pathlib import Path

from check_pc import WORK


folder = WORK / 't13-s-20260908'
standard_folder = folder / 'cts-c101-r1-834e-watch-01'
high_folder = folder / 'cts-c101-r1-834e-driveh-watch-01'
standard_path = standard_folder / 'result.json'
standard_stop_path = folder / 'cts-c101-r1-834e-watch-01-stopped-debugger-state-01.json'
high_path = high_folder / 'result.json'
high_stop_path = folder / 'cts-c101-r1-834e-driveh-watch-01-stopped-debugger-state-01.json'
output = high_folder / 'diagnostic-audit.json'
assert not output.exists()

standard = json.loads(standard_path.read_text(encoding='utf-8'))
standard_stop = json.loads(standard_stop_path.read_text(encoding='utf-8'))
high = json.loads(high_path.read_text(encoding='utf-8'))
high_stop = json.loads(high_stop_path.read_text(encoding='utf-8'))
assert standard['core_revision'] == high['core_revision'] == \
    '834e4d61bc5e1b893ba41f0273a135c170c67d48'
identity_fields = ('role', 'uid_sha256', 'hex_sha256', 'elf_sha256', 'record_sha256')
assert [tuple(device[field] for field in identity_fields) for device in standard['devices']] == [
    tuple(device[field] for field in identity_fields) for device in high['devices']
]
standard_results = standard['results']
high_results = high['results']
watch_hits = [row for row in standard_results if row['id'].endswith('debug/watch-hit')]
captures = [row for row in standard_results if '/debug/capture/' in row['id']]
drive_rows = [row for row in high_results if row['id'].endswith('debug/drive/role2-p1.6')]
high_watch_hits = [row for row in high_results if row['id'].endswith('debug/watch-hit')]
measurements = [row for row in high_results if row['status'] == 'measurement-complete']
assert len(watch_hits) == 1 and watch_hits[0]['initially_halted_roles'] == [1]
assert len(captures) == 2
assert next(row for row in captures if row['id'].endswith('role1'))['lane_error'] == 25
assert next(row for row in captures if row['id'].endswith('role2'))['lane_error'] == 0
standard_role1 = next(row for row in standard_stop['devices'] if row['role'] == 1)
assert standard_role1['lane_summaries'][1]['error'] == 25
assert standard_role1['lane_summaries'][1]['driver_error'] == 4
assert standard_role1['registers']['UARTE21.DMA.RX.AMOUNT'] == 4
assert len(drive_rows) == 2 and not high_watch_hits and len(measurements) == 2
assert all(row['before'] == 3 and row['after'] == 0x503 for row in drive_rows)
assert all(row['drive_before'] == 'S0S1' and row['drive_after'] == 'H0H1'
           for row in drive_rows)
for device in high_stop['devices']:
    assert device['state_before'] == device['state_after'] == 'SLEEPING'
    assert device['lane_count'] == 0
    assert all(row['error'] == 0 and row['active'] == 0
               for row in device['lane_summaries'])
    assert all(row['active'] == 0 and row['tx_active'] == 0 and row['rx_active'] == 0
               for row in device['context_summaries'])
    assert device['registers']['UARTE21.ENABLE'] == 0
    assert device['registers']['UARTE21.ERRORSRC'] == 0
    assert device['registers']['P1.PIN_CNF[6]'] == 0
    assert device['registers']['P1.PIN_CNF[7]'] == 0

paths = (standard_path, standard_stop_path, high_path, high_stop_path)
audit = {
    'schema_version': 1,
    'source': standard['core_revision'],
    'diagnostic_only': True,
    'physical_pass_added': False,
    'controlled_variable': 'role2 P1.6 TX drive S0S1 versus H0H1',
    'standard_drive': {
        'watch_hits': len(watch_hits),
        'first_halted_role': 1,
        'lane': 1,
        'instance': 21,
        'lane_error': 25,
        'driver_error_mask': 4,
        'rx_amount_at_stop': 4,
    },
    'high_drive': {
        'watch_hits': 0,
        'independent_start_windows': len(measurements),
        'drive_register_before': 3,
        'drive_register_during': 0x503,
        'stopped_sleeping_devices': 2,
        'stopped_active_contexts': 0,
        'stopped_lane_errors': 0,
        'stopped_pin_configuration': 0,
    },
    'files': [
        {
            'path': str(path),
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
        }
        for path in paths
    ],
}
output.write_text(json.dumps(audit, indent=2) + '\n', encoding='utf-8')
print(json.dumps(audit, indent=2))
