"""! @brief C01의 UART21 첫 오류 latch에서 활성 레지스터를 보존합니다. """
import hashlib
from pathlib import Path
import time
import xml.etree.ElementTree as ET

from pyocd.core.target import Target

from inspect_t13_debug_layout import layout
import t13_uart_watch_diagnostic as base


SOURCE = '834e4d61bc5e1b893ba41f0273a135c170c67d48'
BUILD = Path('C:/t5e17')
SVD = Path(
    'C:/ncs/v3.4.0/modules/hal/nordic/nrfx/bsp/stable/mdk/'
    'nrf54l15_application.svd')
LAYOUTS = {}


def register_map():
    """! @brief 기본 읽기 전용 목록을 모든 C01 UART와 P0까지 확장합니다. """
    registers = base.register_map()
    root = ET.parse(SVD).getroot()
    peripherals = {
        node.findtext('name'): int(node.findtext('baseAddress'), 0)
        for node in root.findall('./peripherals/peripheral')
    }
    for target in ('UARTE21', 'UARTE22', 'UARTE30'):
        source_base = peripherals['GLOBAL_UARTE20_S']
        target_base = peripherals['GLOBAL_' + target + '_S']
        registers.update({
            name.replace('UARTE20.', target + '.', 1): address - source_base + target_base
            for name, address in tuple(registers.items())
            if name.startswith('UARTE20.')
        })
    source_base = peripherals['GLOBAL_P1_S']
    target_base = peripherals['GLOBAL_P0_S']
    registers.update({
        name.replace('P1.', 'P0.', 1): address - source_base + target_base
        for name, address in tuple(registers.items())
        if name.startswith('P1.')
    })
    return registers


class WatchDiagnostic(base.WatchDiagnostic):
    """! @brief 양쪽 lane1 오류 필드에 DWT write watchpoint를 설치합니다. """

    def __init__(self, append):
        super().__init__(append)
        self.layouts = dict(LAYOUTS)
        self.registers = register_map()

    def arm(self, devices):
        """! @brief C01 준비 완료 뒤 UART21 lane1의 첫 오류 쓰기만 감시합니다. """
        assert not self.armed and not self.captured
        self.devices = devices
        for device in devices:
            assert device.image['core_revision'] == SOURCE
            role = device.image['role']
            suffix = 'dut' if role == 1 else 'peer'
            paths = list(BUILD.glob(
                '**/nucode.v04.t13_s_' + suffix + '/**/zephyr.elf'))
            assert len(paths) == 1
            if role not in self.layouts:
                self.layouts[role] = layout(paths[0])
            info = self.layouts[role]
            lanes = next(
                row['address'] for row in info['variables'] if row['name'] == 'lanes')
            lane_size = info['structs']['Lane']['size']
            error = lanes + lane_size + info['structs']['Lane']['fields']['error']
            assert error % 4 == 0 and device.target.read32(error) == 0
            self.addresses[role] = error
            self.original_demcr[role] = device.target.read32(0xE000EDFC)
            assert device.target.set_watchpoint(
                error, 4, Target.WatchpointType.WRITE), 'Hardware watchpoint unavailable'
            device.target.flush()
            self.append('debug/armed/role' + str(role), {
                'status': 'diagnostic',
                'address': error,
                'lane': 1,
                'instance': 21,
                'elf_sha256': hashlib.sha256(paths[0].read_bytes()).hexdigest(),
                'latch_before': 0,
                'source': SOURCE,
                'layout': info,
                'active_registers_before_start': {
                    name: device.target.read32(self.registers['UARTE21.' + name])
                    for name in ('CONFIG', 'ERRORSRC', 'ENABLE', 'BAUDRATE', 'SHORTS')
                },
            })
        self.armed = True


def install(pair, runner, flows):
    """! @brief flow-preflight의 C01 role1에만 진단 감시를 결합합니다. """
    for role, suffix in ((1, 'dut'), (2, 'peer')):
        paths = list(BUILD.glob(
            '**/nucode.v04.t13_s_' + suffix + '/**/zephyr.elf'))
        assert len(paths) == 1
        LAYOUTS[role] = layout(paths[0])
    original_group = runner.execute_group
    original_start = runner.start_devices
    original_stop = runner.stop_pair
    original_execute = flows.execute
    original_command = pair.Device.command
    active = {'manager': None}

    class Captured(pair.ProtocolError):
        """! @brief watchpoint 원본 보존 뒤 정상 판정 대신 진단 종료를 전달합니다. """

    def command(device, opcode, values=(), timeout=10):
        manager = active['manager']
        if manager is None or not manager.armed:
            return original_command(device, opcode, values, timeout)
        if device.poisoned or not 0 < timeout <= 60:
            raise pair.ProtocolError('session is poisoned or timeout invalid')
        device.sequence += 1
        packet = pair.encode(
            device.nonce, device.sequence, device.image['role'], opcode, values)
        request = device.image['symbols']['v04_request']
        response = device.image['symbols']['v04_response']
        try:
            device.target.write32(response, 0)
            device.target.write32(request, 0)
            device.target.write_memory_block8(request + 4, packet[4:])
            device.target.flush()
            device.target.write32(request, pair.MAGIC)
            device.target.flush()
            deadline = time.monotonic() + timeout
            while time.monotonic() < deadline:
                deadline += manager.check()
                if device.target.read32(response):
                    raw = bytes(device.target.read_memory_block8(response, pair.SIZE))
                    status, output = pair.decode(
                        raw, device.nonce, device.sequence, device.image['role'], opcode)
                    if manager.raise_pending:
                        manager.raise_pending = False
                        raise Captured(
                            'Hardware watchpoint captured first C01 UART21 error; '
                            'diagnostic only')
                    if status:
                        raise pair.ProtocolError(
                            'firmware rejected diagnostic mailbox command')
                    return output
                time.sleep(pair.MAILBOX_POLL_INTERVAL_SECONDS)
            raise pair.ProtocolError('debug mailbox timeout')
        except Captured:
            raise
        except BaseException:
            device.poisoned = True
            raise

    def start(devices, test, append, identifier, **kwargs):
        manager = active['manager']
        assert test['id'] == 101 and len(test['serial_links']) == 4
        manager.arm(devices)
        return original_start(devices, test, append, identifier, **kwargs)

    def stop(devices, append, label):
        manager = active['manager']
        if manager is not None:
            manager.disarm()
        return original_stop(devices, append, label)

    def group(devices, selected, duration, continuity, append, **kwargs):
        manager = active['manager']
        manager.append = append
        try:
            return original_group(
                devices, selected, duration, continuity, append, **kwargs)
        finally:
            manager.disarm()

    def execute(devices, test, role, continuity, append, *, preflight):
        assert test['id'] == 101 and role == 1 and preflight
        manager = WatchDiagnostic(append)
        active['manager'] = manager

        def diagnostic_append(identifier, row):
            """! @brief 진단 중 정상 관측도 qualification PASS로 승격하지 않습니다. """
            row = dict(row)
            if row.get('status') == 'passed':
                row['status'] = 'diagnostic-observation'
            for key in row:
                if key.endswith('_pass'):
                    row[key] = False
            append(identifier, row)

        try:
            original_execute(
                devices, test, role, continuity, diagnostic_append, preflight=True)
            raise pair.ProtocolError(
                'Bounded watchpoint diagnostic ended without reproducing the '
                'C01 UART21 fault; no qualification')
        finally:
            manager.disarm()
            for device in devices:
                if device.target.get_state() == Target.State.HALTED:
                    device.target.resume()
            active['manager'] = None

    pair.Device.command = command
    runner.start_devices = start
    runner.stop_pair = stop
    runner.execute_group = group
    flows.execute = execute
