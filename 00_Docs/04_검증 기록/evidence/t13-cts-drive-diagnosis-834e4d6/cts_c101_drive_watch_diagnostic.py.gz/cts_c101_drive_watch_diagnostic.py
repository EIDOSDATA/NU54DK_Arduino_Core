"""! @brief C01 실패 방향 TX의 고구동 비교와 첫 UART 오류 감시를 결합합니다. """

import cts_c101_watch_diagnostic as base


class DriveWatchDiagnostic(base.WatchDiagnostic):
    """! @brief B P1.6만 H0H1으로 바꾸어 송신 구동 여유를 분리합니다. """

    def arm(self, devices):
        """! @brief PREPARE 뒤 watchpoint와 B TX 구동을 함께 설정합니다. """
        super().arm(devices)
        device = next(device for device in devices if device.image['role'] == 2)
        address = self.registers['P1.PIN_CNF[6]']
        before = device.target.read32(address)
        drive_mask = (3 << 8) | (3 << 10)
        after = (before & ~drive_mask) | (1 << 8) | (1 << 10)
        assert before == 0x00000003
        assert after == 0x00000503
        device.target.write32(address, after)
        device.target.flush()
        observed = device.target.read32(address)
        assert observed == after
        self.append('debug/drive/role2-p1.6', {
            'status': 'diagnostic',
            'direction': 'B P1.6 TX to A P1.7 RX',
            'address': address,
            'before': before,
            'after': observed,
            'drive_before': 'S0S1',
            'drive_after': 'H0H1',
            'firmware_changed': False,
            'wiring_changed': False,
            'physical_pass_added': False,
        })


def install(pair, runner, flows):
    """! @brief 기존 C01 감시기에 단일 핀 구동 비교만 추가합니다. """
    base.WatchDiagnostic = DriveWatchDiagnostic
    base.install(pair, runner, flows)
