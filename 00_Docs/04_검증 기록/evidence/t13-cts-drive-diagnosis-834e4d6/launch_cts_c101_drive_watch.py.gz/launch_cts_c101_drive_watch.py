"""! @brief exact CTS 런처에 C01 TX 고구동 비교 감시를 결합합니다. """

import json
from pathlib import Path
import sys

from check_pc import WORK


assert '--name' in sys.argv
assert sys.argv[sys.argv.index('--name') + 1] == 'cts-c101-r1-834e-driveh-watch-01'
assert '--phase' in sys.argv
assert sys.argv[sys.argv.index('--phase') + 1] == 'flow-preflight'
assert '--cases' in sys.argv
assert sys.argv[sys.argv.index('--cases') + 1] == '101'
assert '--fault-role' in sys.argv
assert sys.argv[sys.argv.index('--fault-role') + 1] == '1'
folder = WORK / 't13-s-20260908'
helper = WORK / 'launch_t13_recovery.py'
source = helper.read_text(encoding='utf-8').replace(
    "Path('C:/tr13dev')", "Path('C:/Users/eidos/GitHub/NU54DK_Arduino_Core')")
source = source.replace("'recovery-builds.json'", "'cts-builds.json'")
source = source.replace(
    "str(SDK/'opt/bin/Scripts/pyocd.exe')",
    "str(Path(r'C:\\Users\\eidos\\AppData\\Local\\Python\\pythoncore-3.14-64\\Scripts\\pyocd.exe'))")
source = source.replace(
    "'pwm-recovery-preflight', 'pwm-recovery'), required=True)",
    "'pwm-recovery-preflight', 'pwm-recovery', 'flow-preflight', 'uart-flow'), required=True)")
needle = 'import v04_t13_session as session'
source = source.replace(
    needle,
    needle + '\nimport v04_t13_flow as flows\n'
    'from cts_c101_drive_watch_diagnostic import install\n'
    'install(pair, runner, flows)')
assert 'install(pair, runner, flows)' in source
try:
    exec(compile(source, str(helper), 'exec'))
finally:
    path = folder / 'cts-c101-r1-834e-driveh-watch-01' / 'result.json'
    if sys.argv[1] == 'execute' and path.exists():
        original = path.with_suffix('.before-diagnostic-classification.json')
        with original.open('xb') as output:
            output.write(path.read_bytes())
        evidence = json.loads(path.read_text(encoding='utf-8'))
        evidence.update(
            diagnostic_only=True,
            physical_pass_added=False,
            firmware_unchanged=True,
            wiring_unchanged=True,
            diagnostic_method=(
                'B P1.6 H0H1 drive comparison plus hardware write watchpoint '
                'on C01 lane1 error'),
        )
        path.write_text(json.dumps(evidence, indent=2) + '\n', encoding='utf-8')
