"""! @brief PDM 오류 주입 뒤 실제 GPIO와 enable을 reset 없이 보존합니다. """
import json
import logging
import sys
from datetime import datetime, timezone
from check_pc import REPO, WORK
from pyocd.core.helpers import ConnectHelper
sys.path.insert(0, str(REPO / 'tests/hil/nu54dk'))
import v04_pair as pair
from v04_protocol import ProbeLocks

logging.disable(logging.CRITICAL)
folder = WORK / 't13-s-20260908'
campaign = 'pdm-03f5ba4-starvation-preflight1'
images = json.loads((folder / campaign / 'images.json').read_text())
grant = json.loads((folder / 'session-grant-repair3.json').read_text())
private = json.loads((folder / 'probe-uids-local.json').read_text())
uids = [private[key].lower() for key in grant['uid_sha256']]
assert not json.loads((WORK / 'current_common_task_state.json').read_text())['active_t13_s']['hardware_running']
output = folder / (campaign + '-readonly-enable-01.json')
assert not output.exists()
available = {probe.unique_id.lower() for probe in ConnectHelper.get_all_connected_probes(blocking=False)}
assert set(uids).issubset(available)
report = {'source': images[0]['core_revision'], 'observed_utc': datetime.now(timezone.utc).isoformat(),
          'swd_frequency_hz': 10000000, 'reset_halt_resume_flash': False, 'devices': []}
with ProbeLocks(uids):
    for uid, image in zip(uids, images):
        with ConnectHelper.session_with_chosen_probe(unique_id=uid, target_override='nrf54l',
                frequency=10000000, blocking=False, no_config=True,
                options={'auto_unlock': False, 'connect_mode': 'attach',
                         'resume_on_disconnect': False, 'cmsis_dap.limit_packets': True}) as connection:
            target = connection.target
            pair.verify_identity(bytes(target.read_memory_block8(image['symbols']['v04_identity'], 64)),
                                 image['role'], image['core_revision'])
            row = {'role': image['role'], 'state': target.get_state().name, 'pin_cnf': {},
                   'pdm_enable': [target.read32(base + 0x500) for base in (0x500D0000, 0x500D1000)],
                   'serial21_enable': target.read32(0x500C7500)}
            for port, base, pins in ((0, 0x5010A000, range(4)), (1, 0x500D8200, [4, 5, 6, 7, 10, 14]),
                                     (2, 0x50050400, range(7))):
                for pin in pins:
                    row['pin_cnf'][f'P{port}.{pin:02}'] = target.read32(base + 0x80 + pin * 4)
            row['all_17_input_no_pull'] = all(value == 0 for value in row['pin_cnf'].values())
            report['devices'].append(row)
with output.open('x', encoding='utf-8') as stream:
    json.dump(report, stream, indent=2)
print(json.dumps(report, indent=2))
