"""! @brief 일회 진단의 실행 원본과 종료를 보존합니다. """
import os
from check_pc import WORK, PYTHON, run

name = 'uart20-a-first-error-watch-01'
options = ['--build', 'C:/t5f16', '--name', name, '--phase', 'uart-line-fault',
           '--cases', '2', '--fault-role', '1', '--uart-line-mode', 'parity']
base = [PYTHON, '-X', 'utf8', '-B', WORK / 'run_ncs.py', 'launch_t13_uart_watch.py']
for mode in ('preflight', 'execute'):
    result = run(name + '-' + mode, [*base, mode, *options], os.environ.copy())
    if result:
        raise SystemExit(result)
