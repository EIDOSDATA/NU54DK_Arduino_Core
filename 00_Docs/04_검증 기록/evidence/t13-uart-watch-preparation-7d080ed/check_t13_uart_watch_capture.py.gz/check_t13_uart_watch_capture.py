"""! @brief 감시점 적중·읽기 실패 모두에서 양쪽 해제와 재개를 모의 검사합니다. """
import json
from types import SimpleNamespace
from check_pc import WORK
import t13_uart_watch_diagnostic as watch

prepared = json.loads((WORK / 't13-s-20260908/uart-watch-preparation-01.json').read_text())
watch.LAYOUTS.update({int(role): info for role, info in prepared['layouts'].items()})

class FakeTarget:
    def __init__(self, bad_read=False):
        self.state = watch.Target.State.RUNNING
        self.watchpoints = []
        self.bad_read = bad_read
    def read32(self, address):
        return 0
    def read_memory_block32(self, address, count):
        return [0] * count
    def read_memory_block8(self, address, count):
        return [0] * count
    def read_core_registers_raw(self, names):
        if self.bad_read:
            raise RuntimeError('Injected capture read failure')
        return [0] * len(names)
    def set_watchpoint(self, address, size, kind):
        self.watchpoints.append((address, size, kind))
        return True
    def remove_watchpoint(self, address, size, kind):
        self.watchpoints.remove((address, size, kind))
    def flush(self):
        pass
    def get_state(self):
        return self.state
    def halt(self):
        self.state = watch.Target.State.HALTED
    def resume(self):
        self.state = watch.Target.State.RUNNING

for bad_read in (False, True):
    records = []
    manager = watch.WatchDiagnostic(lambda label, row: records.append((label, row)))
    devices = [SimpleNamespace(image={'role': role, 'core_revision': watch.SOURCE},
                               target=FakeTarget(bad_read and role == 1)) for role in (1, 2)]
    manager.arm(devices)
    devices[0].target.halt()
    try:
        manager.check()
        assert not bad_read
    except RuntimeError as error:
        assert bad_read and str(error) == 'Injected capture read failure'
    assert manager.captured and not manager.armed
    assert all(not d.target.watchpoints and d.target.state == watch.Target.State.RUNNING for d in devices)
    if not bad_read:
        assert len([row for label, row in records if label.startswith('debug/capture/')]) == 2
with (WORK / 't13-s-20260908/uart-watch-capture-host-01.json').open('x', encoding='utf-8') as output:
    json.dump({'status': 'passed', 'physical_executed': False,
               'checks': ['first role halt captures both and resumes both', 'read failure still removes both watchpoints and resumes both']}, output, indent=2)
print('Watch capture cleanup: 2 Host scenarios passed; no hardware accessed')
