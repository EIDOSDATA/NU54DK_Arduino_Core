"""! @brief exact image의 최초 정상 UART 오류 쓰기에서 멈추는 일회 진단입니다. """
import hashlib
import json
from pathlib import Path
import time
import xml.etree.ElementTree as ET
from pyocd.core.target import Target
from inspect_t13_debug_layout import layout

SVD = Path('C:/ncs/v3.4.0/modules/hal/nordic/nrfx/bsp/stable/mdk/nrf54l15_application.svd')
SOURCE = '7d080ed2fcc9cadfd80bfb21d63c697ec023906b'
LAYOUTS = {}


def register_map():
    """! @brief 고정 Nordic SVD에서 부작용 없는 관련 레지스터 주소만 선택합니다. """
    root = ET.parse(SVD).getroot()
    peripherals = {node.findtext('name'): node for node in root.findall('./peripherals/peripheral')}
    result = {}

    def walk(node, base, prefix='', access='read-write'):
        for child in node:
            if child.tag not in ('register', 'cluster'):
                continue
            name = child.findtext('name')
            offset = int(child.findtext('addressOffset'), 0)
            count = int(child.findtext('dim', '1'), 0)
            stride = int(child.findtext('dimIncrement', '0'), 0)
            local_access = child.findtext('access', access)
            assert child.find('readAction') is None
            for index in range(count):
                label = prefix + (name.replace('%s', str(index)) if count > 1 else name)
                address = base + offset + index * stride
                if child.tag == 'cluster':
                    yield from walk(child, address, label + '.', local_access)
                elif local_access != 'write-only':
                    yield label, address

    for selected in ('UARTE20', 'P1', 'P2', 'CLOCK'):
        peripheral = peripherals['GLOBAL_' + selected + '_S']
        base = int(peripheral.findtext('baseAddress'), 0)
        definition = peripheral
        while 'derivedFrom' in definition.attrib:
            definition = peripherals[definition.attrib['derivedFrom']]
        for name, address in walk(definition.find('registers'), base):
            if selected == 'UARTE20':
                keep = name.startswith(('EVENTS_', 'DMA.', 'PSEL.')) or name in (
                    'ERRORSRC', 'ENABLE', 'CONFIG', 'BAUDRATE', 'SHORTS', 'INTEN', 'FRAMETIMEOUT')
            elif selected == 'CLOCK':
                keep = name in ('XO.RUN', 'XO.STAT', 'PLL.RUN', 'PLL.STAT', 'LFCLK.RUN', 'LFCLK.STAT')
            else:
                keep = name in ('IN', 'OUT', 'DIR', 'LATCH') or name.startswith('PIN_CNF[')
            if keep:
                result[selected + '.' + name] = address
    assert result['UARTE20.ERRORSRC'] == 0x500C6480
    assert result['UARTE20.CONFIG'] == 0x500C656C
    return result


class WatchDiagnostic:
    """! @brief 현재 probe lock 안에서만 감시점을 설치하고 양쪽 RAM을 보존합니다. """
    def __init__(self, append):
        self.append = append
        self.devices = []
        self.layouts = dict(LAYOUTS)
        self.addresses = {}
        self.armed = False
        self.captured = False
        self.raise_pending = False
        self.registers = register_map()
        self.original_demcr = {}

    def arm(self, devices):
        assert not self.armed and not self.captured
        self.devices = devices
        for device in devices:
            assert device.image['core_revision'] == SOURCE
            role = device.image['role']
            paths = list(Path('C:/t5f16').glob('**/nucode.v04.t13_s_' + ('dut' if role == 1 else 'peer') + '/**/zephyr.elf'))
            assert len(paths) == 1
            if role not in self.layouts:
                self.layouts[role] = layout(paths[0])
            info = self.layouts[role]
            lanes = next(row['address'] for row in info['variables'] if row['name'] == 'lanes')
            error = lanes + info['structs']['Lane']['fields']['error']
            assert error % 4 == 0 and device.target.read32(error) == 0
            self.addresses[role] = error
            if role not in self.original_demcr:
                self.original_demcr[role] = device.target.read32(0xE000EDFC)
            assert device.target.set_watchpoint(error, 4, Target.WatchpointType.WRITE), 'Hardware watchpoint unavailable'
            device.target.flush()
            self.append('debug/armed/role' + str(role), {'status': 'diagnostic', 'address': error,
                        'elf_sha256': hashlib.sha256(paths[0].read_bytes()).hexdigest(),
                        'latch_before': 0, 'source': SOURCE, 'layout': info,
                        'normal_uart_config': {name: device.target.read32(self.registers['UARTE20.' + name])
                                               for name in ('CONFIG', 'ERRORSRC', 'ENABLE', 'BAUDRATE', 'SHORTS')}})
        self.armed = True

    def disarm(self):
        for device in self.devices:
            role = device.image['role']
            if role in self.addresses:
                device.target.remove_watchpoint(self.addresses[role], 4, Target.WatchpointType.WRITE)
                device.target.flush()
        self.armed = False

    def check(self):
        """! @brief SWD 명령과 같은 스레드에서 검사하여 probe 동시 접근을 막습니다. """
        if not self.armed:
            return 0.0
        started = time.monotonic()
        states = {d.image['role']: d.target.get_state() for d in self.devices}
        halted = [role for role, state in states.items() if state == Target.State.HALTED]
        if not halted:
            return 0.0
        self.captured = True
        self.raise_pending = True
        self.append('debug/watch-hit', {'status': 'diagnostic', 'initially_halted_roles': halted,
                    'states': {role: str(state) for role, state in states.items()},
                    'simultaneous_halt': False, 'physical_pass_added': False})
        try:
            for device in self.devices:
                if device.target.get_state() != Target.State.HALTED:
                    device.target.halt()
            assert all(d.target.get_state() == Target.State.HALTED for d in self.devices)
            for device in self.devices:
                role = device.image['role']
                target = device.target
                info = self.layouts[role]
                names = ['r' + str(index) for index in range(13)] + ['sp', 'lr', 'pc', 'xpsr', 'msp', 'psp', 'primask', 'basepri', 'faultmask', 'control']
                cpu = dict(zip(names, target.read_core_registers_raw(names)))
                row = {'status': 'diagnostic', 'cpu': cpu, 'lane_error': target.read32(self.addresses[role]),
                       'registers': {name: target.read32(address) for name, address in self.registers.items()},
                       'scb': {hex(address): target.read32(address) for address in
                               (0xE000ED04, 0xE000ED24, 0xE000ED28, 0xE000ED2C, 0xE000ED30, 0xE000EDF0, 0xE000EDFC)},
                       'nvic_enabled': target.read_memory_block32(0xE000E100, 16),
                       'nvic_pending': target.read_memory_block32(0xE000E200, 16),
                       'nvic_active': target.read_memory_block32(0xE000E300, 16),
                       'nvic_priorities': target.read_memory_block8(0xE000E400, 512),
                       'ram': {}}
                for name, cu, size in (('lanes', '/serial.cpp', info['structs']['Lane']['size']),
                                       ('contexts', '/UarteFabric.cpp', info['structs']['UarteContext']['size'] * 5)):
                    address = next(v['address'] for v in info['variables'] if v['name'] == name and v['cu'].endswith(cu))
                    row['ram'][name] = {'address': address, 'bytes_hex': bytes(target.read_memory_block8(address, size)).hex()}
                for reg in ('sp', 'msp', 'psp'):
                    address = cpu[reg] & ~3
                    if 0x20000000 <= address <= 0x20040000 - 256:
                        row['ram'][reg] = {'address': address, 'words': target.read_memory_block32(address, 64)}
                self.append('debug/capture/role' + str(role), row)
        finally:
            try:
                self.disarm()
            finally:
                for device in self.devices:
                    if device.target.get_state() == Target.State.HALTED:
                        device.target.resume()
            self.append('debug/resumed-for-stop', {'status': 'diagnostic', 'physical_pass_added': False,
                        'capture_seconds': time.monotonic() - started})
        return time.monotonic() - started


def install(pair, runner, uart_lines):
    """! @brief 정상 baseline/restart에만 감시점을 걸며 주입 오류에는 설치하지 않습니다. """
    for role, suffix in ((1, 'dut'), (2, 'peer')):
        paths = list(Path('C:/t5f16').glob('**/nucode.v04.t13_s_' + suffix + '/**/zephyr.elf'))
        assert len(paths) == 1
        LAYOUTS[role] = layout(paths[0])
    original_group = runner.execute_group
    original_start = runner.start_devices
    original_stop = runner.stop_pair
    original_execute = uart_lines.execute
    original_command = pair.Device.command
    active = {'manager': None}

    class Captured(pair.ProtocolError):
        pass

    def command(device, opcode, values=(), timeout=10):
        manager = active['manager']
        if manager is None or not manager.armed:
            return original_command(device, opcode, values, timeout)
        if device.poisoned or not 0 < timeout <= 60:
            raise pair.ProtocolError('session is poisoned or timeout invalid')
        device.sequence += 1
        packet = pair.encode(device.nonce, device.sequence, device.image['role'], opcode, values)
        request, response = device.image['symbols']['v04_request'], device.image['symbols']['v04_response']
        try:
            device.target.write32(response, 0)
            device.target.write32(request, 0)
            device.target.write_memory_block8(request + 4, packet[4:])
            device.target.flush()
            device.target.write32(request, pair.MAGIC)
            device.target.flush()
            deadline = time.monotonic() + timeout
            while time.monotonic() < deadline:
                deadline += manager.check()
                if device.target.read32(response):
                    raw = bytes(device.target.read_memory_block8(response, pair.SIZE))
                    status, output = pair.decode(raw, device.nonce, device.sequence, device.image['role'], opcode)
                    if manager.raise_pending:
                        manager.raise_pending = False
                        raise Captured('Hardware watchpoint captured first normal UART error; diagnostic only')
                    if status:
                        raise pair.ProtocolError('firmware rejected diagnostic mailbox command')
                    return output
                time.sleep(pair.MAILBOX_POLL_INTERVAL_SECONDS)
            raise pair.ProtocolError('debug mailbox timeout')
        except Captured:
            raise
        except BaseException:
            device.poisoned = True
            raise

    def start(devices, test, append, identifier, **kwargs):
        manager = active['manager']
        assert test['id'] == 2 and len(test['serial_links']) == 1
        manager.arm(devices)
        return original_start(devices, test, append, identifier, **kwargs)

    def stop(devices, append, label):
        manager = active['manager']
        if manager is not None:
            manager.disarm()
        return original_stop(devices, append, label)

    def group(devices, selected, duration, continuity, append, **kwargs):
        manager = active['manager']
        manager.append = append
        try:
            return original_group(devices, selected, duration, continuity, append, **kwargs)
        finally:
            manager.disarm()

    def execute(devices, test, role, mode, continuity, append, *, preflight):
        assert test['id'] == 2 and role == 1 and mode == 'parity' and not preflight
        manager = WatchDiagnostic(append)
        active['manager'] = manager

        def diagnostic_append(identifier, row):
            row = dict(row)
            if row.get('status') == 'passed':
                row['status'] = 'diagnostic-observation'
            for key in row:
                if key.endswith('_pass'):
                    row[key] = False
            append(identifier, row)

        try:
            original_execute(devices, test, role, mode, continuity, diagnostic_append, preflight=False)
            raise pair.ProtocolError('Bounded watchpoint diagnostic ended without reproducing a normal UART fault; no qualification')
        finally:
            manager.disarm()
            for device in devices:
                if device.target.get_state() == Target.State.HALTED:
                    device.target.resume()
            active['manager'] = None

    pair.Device.command = command
    runner.start_devices = start
    runner.stop_pair = stop
    runner.execute_group = group
    uart_lines.execute = execute
