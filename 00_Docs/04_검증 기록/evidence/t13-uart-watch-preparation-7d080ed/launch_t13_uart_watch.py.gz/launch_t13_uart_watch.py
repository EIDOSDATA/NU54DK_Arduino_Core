"""! @brief 기존 exact 검증·결선·배타 lock을 유지하는 UART 감시점 진단입니다. """
import json
from pathlib import Path
import sys
from check_pc import WORK

assert '--name' in sys.argv and sys.argv[sys.argv.index('--name') + 1] == 'uart20-a-first-error-watch-01'
assert '--phase' in sys.argv and sys.argv[sys.argv.index('--phase') + 1] == 'uart-line-fault'
assert '--cases' in sys.argv and sys.argv[sys.argv.index('--cases') + 1] == '2'
assert '--fault-role' in sys.argv and sys.argv[sys.argv.index('--fault-role') + 1] == '1'
folder = WORK / 't13-s-20260908'
priority = json.loads((folder / 's123-priority-diagnostic.json').read_text())
assert priority['owner'] == 'uart-first-error-watch'
source = (WORK / 'launch_t13_peer_rx.py').read_text(encoding='utf-8')
needle = 'import v04_t13_session as session'
source = source.replace(needle, needle + '\nimport v04_t13_uart_line as uart_lines\nfrom t13_uart_watch_diagnostic import install\ninstall(pair, runner, uart_lines)')
try:
    exec(compile(source, str(WORK / 'launch_t13_peer_rx.py'), 'exec'))
finally:
    path = folder / 'uart20-a-first-error-watch-01' / 'result.json'
    if sys.argv[1] == 'execute' and path.exists():
        with path.with_suffix('.before-diagnostic-classification.json').open('xb') as output:
            output.write(path.read_bytes())
        evidence = json.loads(path.read_text(encoding='utf-8'))
        evidence.update(diagnostic_only=True, physical_pass_added=False, firmware_unchanged=True,
                        diagnostic_method='Hardware write watchpoint on Lane.error in normal baseline/restart only')
        path.write_text(json.dumps(evidence, indent=2) + '\n', encoding='utf-8')
