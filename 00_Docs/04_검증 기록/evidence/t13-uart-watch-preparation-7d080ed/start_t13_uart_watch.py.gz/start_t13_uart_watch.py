"""! @brief 실행 중 시험의 종료를 기다린 뒤 한 번의 정상 오류 감시점 진단을 수행합니다. """
import datetime
import json
from pathlib import Path
import subprocess
import time
from check_pc import WORK, PYTHON

folder = WORK / 't13-s-20260908'
path = folder / 'uart-first-error-watch-controller-01.json'
assert not path.exists()
preparation = json.loads((folder / 'uart-watch-preparation-01.json').read_text())
assert preparation['status'] == 'passed' and not preparation['physical_executed']
priority = folder / 's123-priority-diagnostic.json'
with priority.open('x', encoding='utf-8') as output:
    json.dump({'owner': 'uart-first-error-watch', 'created_at': datetime.datetime.now(datetime.timezone.utc).isoformat()}, output)
report = {'status': 'waiting-active-cleanup', 'source': preparation['source'],
          'diagnostic_only': True, 'physical_pass_added': False,
          'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat()}

def save():
    report['updated_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    path.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')

try:
    save()
    deadline = time.monotonic() + 900
    while True:
        state = json.loads((WORK / 'current_common_task_state.json').read_text(encoding='utf-8'))['active_t13_s']
        assert not state.get('t13_traffic_paused_by_user') and not state.get('requires_wiring_repair')
        prior = Path(state['campaign']).name
        audit_path = folder / (prior + '-audit.json')
        if not state['hardware_running'] and audit_path.exists():
            assert json.loads(audit_path.read_text())['final_pin_return_proven']
            break
        assert time.monotonic() < deadline, 'Timed out waiting for the prior campaign to finish naturally'
        time.sleep(1)
    report.update(status='running-watch-diagnostic', preceding_campaign=prior)
    save()
    name = 'uart20-a-first-error-watch-01'
    outcome = subprocess.run([str(PYTHON), '-X', 'utf8', '-B', str(WORK / 'run_t13_uart_watch.py')], check=False)
    evidence = json.loads((folder / name / 'result.json').read_text(encoding='utf-8'))
    assert evidence['diagnostic_only'] and not evidence['physical_pass_added']
    subprocess.run([str(PYTHON), '-X', 'utf8', '-B', str(WORK / 'audit_t13_three_campaign.py'), name], check=True)
    audit = json.loads((folder / (name + '-audit.json')).read_text())
    assert audit['final_pin_return_proven']
    wiring = [row for row in evidence['results'] if row['id'].startswith('V04-WIRING/') and row.get('status') == 'passed']
    assert len(wiring) >= 105, 'Current wiring proof is incomplete'
    captures = [row['id'] for row in evidence['results'] if '/debug/capture/' in row['id'] or row['id'].startswith('debug/capture/')]
    report.update(status='finished-with-results', campaign=name, result=evidence['status'],
                  error=evidence.get('error'), exit_code=outcome.returncode, captures=captures, cleanup_proven=True)
    save()
    assert json.loads(priority.read_text())['owner'] == 'uart-first-error-watch'
    priority.unlink()
    print('Watch diagnostic and both-board cleanup preserved; independent S scheduler resumed', flush=True)
except BaseException as error:
    report.update(status='needs-evidence-review', error=f'{type(error).__name__}: {error}')
    save()
    raise
