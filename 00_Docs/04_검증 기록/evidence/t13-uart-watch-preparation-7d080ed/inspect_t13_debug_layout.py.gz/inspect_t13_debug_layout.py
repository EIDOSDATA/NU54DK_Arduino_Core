"""! @brief exact ELF의 DWARF에서 오류 latch와 진단 RAM 배치를 읽기만 합니다. """
import json
from pathlib import Path
from elftools.elf.elffile import ELFFile


def layout(path):
    with Path(path).open('rb') as stream:
        elf = ELFFile(stream)
        dwarf = elf.get_dwarf_info()
        structs = {}
        variables = []
        for cu in dwarf.iter_CUs():
            for die in cu.iter_DIEs():
                definition = die.get_DIE_from_attribute('DW_AT_specification') if 'DW_AT_specification' in die.attributes else die
                raw = definition.attributes.get('DW_AT_name')
                name = raw.value.decode(errors='replace') if raw else ''
                if die.tag == 'DW_TAG_structure_type' and name in ('Lane', 'UarteContext'):
                    size = die.attributes.get('DW_AT_byte_size')
                    if not size:
                        continue
                    fields = {}
                    for member in die.iter_children():
                        if member.tag != 'DW_TAG_member':
                            continue
                        label = member.attributes.get('DW_AT_name')
                        offset = member.attributes.get('DW_AT_data_member_location')
                        if label and offset and isinstance(offset.value, int):
                            fields[label.value.decode()] = offset.value
                    value = {'size': size.value, 'fields': fields}
                    assert name not in structs or structs[name] == value
                    structs[name] = value
                if die.tag == 'DW_TAG_variable' and name in ('lanes', 'contexts', 'lane_count'):
                    location = die.attributes.get('DW_AT_location')
                    if location and isinstance(location.value, list) and location.value[0] == 3:
                        variables.append({'name': name, 'address': int.from_bytes(bytes(location.value[1:]), 'little'),
                                          'cu': cu.get_top_DIE().attributes['DW_AT_name'].value.decode()})
        symbols = {}
        for symbol in elf.get_section_by_name('.symtab').iter_symbols():
            if ('lanes' in symbol.name or 'contexts' in symbol.name or 'lane_count' in symbol.name) and symbol['st_size']:
                symbols[symbol.name] = {'address': symbol['st_value'], 'size': symbol['st_size']}
        return {'elf': str(path), 'structs': structs, 'variables': variables, 'symbols': symbols}


if __name__ == '__main__':
    for path in Path('C:/t5f16').rglob('zephyr.elf'):
        print(json.dumps(layout(path)))
