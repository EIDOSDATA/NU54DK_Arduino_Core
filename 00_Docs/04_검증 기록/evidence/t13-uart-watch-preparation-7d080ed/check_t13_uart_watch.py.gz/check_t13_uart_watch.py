"""! @brief 감시점 준비에서 주소·구조체·부작용 없는 읽기와 해제를 모의 대조합니다. """
import datetime
import json
from pathlib import Path
import sys
from types import SimpleNamespace
from check_pc import WORK
import t13_uart_watch_diagnostic as watch

sys.path.insert(0, 'C:/trxof04/tests/hil/nu54dk')
import v04_pair as pair

registers = watch.register_map()
assert len(registers) > 50 and all(address % 4 == 0 for address in registers.values())
assert not any('TASKS_' in name or 'SUBSCRIBE_' in name or 'PUBLISH_' in name for name in registers)
assert 'UARTE20.ERRORSRC' in registers and 'UARTE20.DMA.RX.AMOUNT' in registers
images = [pair.inspect_image(Path('C:/trxof04'), Path('C:/t5f16'), role, family='t13_s') for role in (1, 2)]

class FakeTarget:
    def __init__(self):
        self.watches = []
        self.writes = []
    def read32(self, address):
        return 0
    def set_watchpoint(self, address, size, kind):
        self.watches.append((address, size, kind))
        return True
    def remove_watchpoint(self, address, size, kind):
        item = (address, size, kind)
        if item in self.watches:
            self.watches.remove(item)
    def flush(self):
        pass
    def get_state(self):
        return watch.Target.State.RUNNING

records = []
manager = watch.WatchDiagnostic(lambda label, row: records.append((label, row)))
devices = [SimpleNamespace(image=image, target=FakeTarget()) for image in images]
manager.arm(devices)
assert len(records) == 2 and all(len(device.target.watches) == 1 for device in devices)
assert manager.check() == 0 and not manager.captured
for role, info in manager.layouts.items():
    assert info['structs']['Lane']['size'] == 4808 and info['structs']['Lane']['fields']['error'] == 4696
    assert len([v for v in info['variables'] if v['name'] == 'contexts' and v['cu'].endswith('/UarteFabric.cpp')]) == 1
manager.disarm()
assert not manager.armed and all(not device.target.watches for device in devices)
report = {'checked_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'source': watch.SOURCE, 'status': 'passed', 'physical_executed': False,
          'checks': ['SVD read-only selection', 'exact ELF roles', 'DWARF latch bounds and unique UART contexts',
                     'two fake hardware write watchpoints', 'running state does not capture', 'both watchpoints removed'],
          'register_count': len(registers), 'registers': registers, 'layouts': manager.layouts}
with (WORK / 't13-s-20260908/uart-watch-preparation-01.json').open('x', encoding='utf-8') as output:
    json.dump(report, output, indent=2)
print('UART watchpoint preparation: 6 checks passed; hardware not accessed', flush=True)
