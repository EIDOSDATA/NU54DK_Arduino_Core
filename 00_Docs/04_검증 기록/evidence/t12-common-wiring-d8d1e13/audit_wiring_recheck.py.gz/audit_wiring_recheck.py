"""! @brief 실제 결선 원본을 실행기 판정 함수와 독립적으로 대조합니다. """
from collections import Counter
import hashlib
import json
from check_pc import WORK

folder = WORK / 'wiring-hardware-d8d1e13'
result = json.loads((folder / 'result.json').read_text(encoding='utf-8'))
journal = [json.loads(line) for line in (folder / 'result.json.jsonl').read_text(encoding='utf-8').splitlines()]
assert result['status'] == 'passed' and result['results'] == journal
assert result['core_revision'] == 'd8d1e135cfc96c1608c55c81b4f111963f56c10a'
assert result['swd_frequency_hz'] == 10000000 and result['cmsis_dap_limit_packets'] is True
entries = {row['id']: row for row in journal}
assert len(entries) == len(journal) == 524
assert Counter(row['status'] for row in journal) == {'observation': 416, 'passed': 105, 'cleanup': 3}
mask, none = 0x1ffff, 0xffffffff
prefix = 'V04-WIRING/501/'
expected_ids = set()
p1_10 = []

def check(key, words):
    """! @brief 고정 기대값과 모든 raw word를 대조합니다. """
    expected_ids.add(key)
    assert entries[key]['status'] == 'observation' and entries[key]['words'] == words, key

def cleanup(key, counter):
    """! @brief 두 보드의 출력·pull·소유권 반환을 별도로 확인합니다. """
    expected_ids.add(key)
    row = entries[key]
    assert row['status'] == 'cleanup' and len(row['outcomes']) == 2
    for role, outcome in enumerate(row['outcomes'], 1):
        assert outcome['role'] == role and outcome['stopped'] is True
        assert len(outcome['words']) == 8 and outcome['words'][1:] == [0, 0, 0, none, counter, counter, 0]

for controller in (1, 2):
    base = prefix + f'controller{controller}'
    for role in (1, 2):
        check(base + f'/baseline/raw-role{role}', [mask, 0, mask, mask, none, 0, 0, 1])
    for repetition in range(1, 4):
        for net in range(1, 18):
            key = base + f'/round{repetition}/net{net}'
            expected_ids.add(key)
            assert entries[key] == {'id': key, 'status': 'passed', 'direction': controller, 'net': net, 'repetition': repetition}
            bit = 1 << (net - 1)
            for role in (1, 2):
                check(key + f'/low/raw-role{role}', [mask ^ bit, bit if role == controller else 0,
                      mask, mask, net - 1 if role == controller else none, 0, 0, 1])
                check(key + f'/released/raw-role{role}', [mask, 0, mask, mask, none, 0, 0, 1])
            if net == 2:
                p1_10.append(key)
    cleanup(base + '/cleanup', 0)
for role in (1, 2):
    key = prefix + f'timeout/pulse-role{role}'
    expected_ids.add(key)
    assert entries[key]['status'] == 'passed'
    check(key + '/raw', [mask, 0, mask, mask, none, 1, 0, 1])
    key = prefix + f'timeout/lease/raw-role{role}'
    expected_ids.add(key)
    assert entries[key]['status'] == 'observation'
    assert len(entries[key]['words']) == 8 and entries[key]['words'][1:] == [0, 0, 0, none, 1, 1, 0]
key = prefix + 'timeout/lease'
expected_ids.add(key)
assert entries[key]['status'] == 'passed' and entries[key]['scope'] == 'both-firmware-leases-expired'
cleanup(prefix + 'timeout/cleanup', 1)
assert set(entries) == expected_ids
postflight = json.loads((WORK / 'wiring-recheck-postflight.json').read_text())
for row in postflight['boards']:
    assert row['core_revision'] == result['core_revision'] and row['cpuid'] == '0x411fd210'
    assert row['state'] in ('RUNNING', 'SLEEPING') and row['backend_packets'] == 1
    assert row['pwm_enable'] == [0, 0, 0] and row['dppi20_chen'] == 0
    assert len(row['pin_cnf']) == 17 and all(value == 0 for value in row['pin_cnf'].values())
record = {'status': 'passed', 'method': 'offline independent literal raw oracle; no runner oracle import',
          'core_revision': result['core_revision'], 'net_rounds': 102, 'pulse_timeouts': 2,
          'dual_lease_timeouts': 1, 'raw_observations': 416, 'cleanup_groups': 3,
          'p1_10_passed_net_rounds': p1_10,
          'postflight': 'both exact runtime identities; all 17 PIN_CNF zero; PWM/DPPI off; no reset/halt/flash',
          'result_raw_sha256': hashlib.sha256((folder / 'result.json').read_bytes()).hexdigest(),
          'journal_raw_sha256': hashlib.sha256((folder / 'result.json.jsonl').read_bytes()).hexdigest()}
with (folder / 'audit.json').open('x', encoding='utf-8', newline='\n') as stream:
    json.dump(record, stream, ensure_ascii=False, indent=2)
print(json.dumps(record))
