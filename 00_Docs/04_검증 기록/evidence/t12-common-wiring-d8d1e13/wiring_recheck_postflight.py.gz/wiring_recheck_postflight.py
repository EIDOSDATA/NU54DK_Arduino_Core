"""! @brief 이전 실기 뒤 현재 연결·출력 상태를 exact UID로 읽고 재설정하지 않습니다. """
import datetime
import hashlib
import json
import logging
import sys
from check_pc import REPO, WORK
logging.disable(logging.CRITICAL)
sys.path.insert(0, str(REPO / 'tests/hil/nu54dk'))
import v04_pair as pair
from v04_protocol import ProbeLocks
from pyocd.core.helpers import ConnectHelper
from serial.tools import list_ports
images = json.loads((WORK / 'wiring-hardware-d8d1e13/images.json').read_text())
private = json.loads((WORK / 'current-probe-uids.private.json').read_text(encoding='utf-8-sig'))
prior = json.loads((WORK / 'wiring-hardware-d8d1e13/confirmation.json').read_text())
uids = [private[key].lower() for key in prior['uid_sha256']]
available = {probe.unique_id.lower() for probe in ConnectHelper.get_all_connected_probes(blocking=False)}
assert set(uids).issubset(available)
ports = list_ports.comports()
catalog = json.loads((REPO / 'tests/hil/nu54dk/v04_common_fixture.json').read_text(encoding='utf-8'))
links = catalog['fixtures'][0]['links'][:-1]
bases = {0: 0x5010A000, 1: 0x500D8200, 2: 0x50050400}
report = {'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'frequency_hz': 10000000, 'reset_halt_resume_flash': False, 'boards': []}
with ProbeLocks(uids):
    for uid, image in zip(uids, images):
        session = ConnectHelper.session_with_chosen_probe(unique_id=uid, target_override='nrf54l',
            frequency=10000000, blocking=False, no_config=True,
            options={'auto_unlock': False, 'connect_mode': 'attach', 'resume_on_disconnect': False,
                     'cmsis_dap.limit_packets': True})
        assert session is not None
        with session:
            target = session.target
            raw = bytes(target.read_memory_block8(image['symbols']['v04_identity'], 64))
            pair.verify_identity(raw, image['role'], image['core_revision'])
            row = {'role': image['role'], 'uid_sha256': hashlib.sha256(uid.encode()).hexdigest(),
                   'ports': pair.matching_port_names(ports, uid), 'core_revision': image['core_revision'],
                   'cpuid': f'0x{target.read32(0xE000ED00):08x}', 'state': target.get_state().name,
                   'backend_packets': session.probe._link._packet_count,
                   'pwm_enable': [target.read32(base + 0x500) for base in (0x500D2000, 0x500D3000, 0x500D4000)],
                   'dppi20_chen': target.read32(0x500C2500), 'p1_14_pin_cnf': target.read32(0x500D82B8)}
            row['pin_cnf'] = {}
            for link in links:
                net = link['dut' if image['role'] == 1 else 'peer'][2]
                port, pin = map(int, net[1:].split('.'))
                row['pin_cnf'][net] = target.read32(bases[port] + 0x80 + pin * 4)
            report['boards'].append(row)
with (WORK / 'wiring-recheck-postflight.json').open('x', encoding='utf-8') as stream:
    json.dump(report, stream, indent=2)
for row in report['boards']:
    assert row['cpuid'] == '0x411fd210' and row['state'] in ('RUNNING', 'SLEEPING') and row['backend_packets'] == 1
    assert row['pwm_enable'] == [0, 0, 0] and row['dppi20_chen'] == 0 and all(value & 1 == 0 for value in row['pin_cnf'].values())
print(json.dumps(report, indent=2))

