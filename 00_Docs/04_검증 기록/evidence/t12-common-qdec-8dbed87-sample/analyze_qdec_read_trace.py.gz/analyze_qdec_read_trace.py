"""! @brief 완료한 QDEC 실패의 GPIO/SAMPLE/누산기와 첫 불일치 직전16회를 분리합니다. """
import argparse
import json
from check_pc import WORK

parser = argparse.ArgumentParser()
parser.add_argument('campaign')
args = parser.parse_args()
campaign = json.loads((WORK / args.campaign / 'result.json').read_text(encoding='utf-8'))
assert campaign['status'] == 'failed'
rows = campaign['results']
failure = next(row for row in reversed(rows) if row.get('status') == 'failed')
prefix = failure['id'].removesuffix('/failure')
selected = {row['id'].removeprefix(prefix + '/'): row for row in rows if row['id'].startswith(prefix + '/')}
signed = lambda value: value - 2**32 if value >= 2**31 else value
pages = [selected['diagnostic-page' + str(page)]['words'] for page in range(3)]
ring = []
for offset in range(0, 16, 2):
    values = selected['read-trace' + str(offset)]['words']
    assert len(values) == 20
    ring.extend([values[:10], values[10:]])
head = pages[2][15]
assert 0 <= head < 16
ordered = [record for record in ring[head:] + ring[:head] if record[1] > 0]
assert all(right[1] == left[1] + 1 for left, right in zip(ordered, ordered[1:]))
converted = []
for record in ordered:
    converted.append(dict(zip(('cycle', 'read_index', 'returned_acc', 'before_acc', 'after_acc',
                               'after_accread', 'sample_sum', 'gpio_sum', 'phase_age_us', 'last_sample'),
                              [signed(value) if index in (2, 3, 4, 5, 6, 7, 9) else value
                               for index, value in enumerate(record)])))
report = {'source': campaign['core_revision'], 'failure': failure, 'final': pages[0],
          'first_mismatch': pages[1], 'sample_current_and_first': pages[2],
          'poll_quality': {'first_gpio_max_gap_us': pages[1][4], 'first_sample_max_gap_us': pages[2][11],
                           'gpio_under128_and_sample_under384': pages[1][4] < 128 and pages[2][11] < 384},
          'read_trace_chronological': converted,
          'returned_vs_postread_differences': [row for row in converted if row['returned_acc'] != row['after_accread']]}
destination = WORK / (args.campaign + '-trace-analysis.json')
with destination.open('x', encoding='utf-8') as stream:
    json.dump(report, stream, ensure_ascii=False, indent=2)
print(json.dumps(report, ensure_ascii=False))
