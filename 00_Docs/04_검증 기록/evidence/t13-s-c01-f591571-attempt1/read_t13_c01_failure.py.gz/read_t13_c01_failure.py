"""! @brief 정지한 C01의 모든 lane RAM을 재설정 없이 읽어 실패 버퍼를 보존합니다. """
import base64
from datetime import datetime, timezone
import json
import logging
from pathlib import Path
import sys
from check_pc import REPO, WORK
from elftools.elf.elffile import ELFFile
from pyocd.core.helpers import ConnectHelper
sys.path.insert(0, str(REPO/'tests/hil/nu54dk'))
import v04_pair as pair
from v04_protocol import ProbeLocks

logging.disable(logging.CRITICAL)
folder = WORK/'t13-s-20260908'
campaign = folder/'soak-concurrent-serial-f591571-attempt1'
output = folder/'soak-concurrent-serial-f591571-attempt1-readonly-01.json'
assert not output.exists()
assert not json.loads((WORK/'current_common_task_state.json').read_text())['active_t13_s']['hardware_running']
images = json.loads((campaign/'images.json').read_text())
grant = json.loads((folder/'session-grant-repair1.json').read_text())
private = json.loads((folder/'probe-uids-local.json').read_text())
uids = [private[key].lower() for key in grant['uid_sha256']]
result = {'type':'read-only-stopped-c01-ram', 'source':images[0]['core_revision'],
          'observed_utc':datetime.now(timezone.utc).isoformat(), 'devices':[]}
with ProbeLocks(uids):
    for uid, image in zip(uids, images):
        with Path(image['elf']).open('rb') as stream:
            elf = ELFFile(stream)
            symbol = next(s for s in elf.get_section_by_name('.symtab').iter_symbols() if s.name.endswith('lanesE'))
            types = {}
            for cu in elf.get_dwarf_info().iter_CUs():
                for die in cu.iter_DIEs():
                    name = die.attributes.get('DW_AT_name')
                    if die.tag == 'DW_TAG_structure_type' and name and name.value in (
                            b'Lane', b'Buffer', b'Direction', b'Endpoint') and 'DW_AT_byte_size' in die.attributes:
                        members = {m.attributes['DW_AT_name'].value.decode():m.attributes['DW_AT_data_member_location'].value
                            for m in die.iter_children() if m.tag == 'DW_TAG_member' and 'DW_AT_data_member_location' in m.attributes}
                        types[name.value.decode()] = {'size':die.attributes['DW_AT_byte_size'].value,'members':members}
        with ConnectHelper.session_with_chosen_probe(unique_id=uid, target_override='nrf54l', frequency=10000000,
                blocking=False, no_config=True, options={'auto_unlock':False,'connect_mode':'attach',
                'resume_on_disconnect':False,'cmsis_dap.limit_packets':True}) as connection:
            target = connection.target
            pair.verify_identity(bytes(target.read_memory_block8(image['symbols']['v04_identity'],64)),
                                 image['role'],image['core_revision'])
            raw = bytes(target.read_memory_block8(symbol['st_value'],symbol['st_size']))
            lanes = []
            for index in range(4):
                start = index*types['Lane']['size']
                lanes.append({name:int.from_bytes(raw[start+offset:start+offset+(1 if name=='active' else 4)],'little')
                    for name,offset in types['Lane']['members'].items() if name in
                    ('error','driver_error','active','queued_tx','queued_rx','seed_tx','seed_rx','requests')})
            row = {'role':image['role'],'state':target.get_state().name,'lane_address':symbol['st_value'],
                'types':types,'lanes':lanes,'lane_raw_base64':base64.b64encode(raw).decode(),'pin_cnf':{}}
            for port,base,pins in ((0,0x5010A000,range(4)),(1,0x500D8200,[4,5,6,7,10,14]),(2,0x50050400,range(7))):
                for pin in pins:
                    row['pin_cnf'][f'P{port}.{pin:02}'] = target.read32(base+0x80+4*pin)
            assert all(value & 1 == 0 for value in row['pin_cnf'].values())
            result['devices'].append(row)
with output.open('x',encoding='utf-8') as stream:
    json.dump(result,stream,indent=2)
print(json.dumps([{'role':row['role'],'state':row['state'],'lanes':row['lanes']} for row in result['devices']]))
