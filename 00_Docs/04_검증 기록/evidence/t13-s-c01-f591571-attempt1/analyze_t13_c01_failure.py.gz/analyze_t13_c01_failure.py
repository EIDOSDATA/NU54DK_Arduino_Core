"""! @brief 보존된 C01 RAM의 TWI 실패 수신 prefix를 독립 pattern과 대조합니다. """
import base64
import json
import sys
from check_pc import REPO, WORK
sys.path.insert(0,str(REPO/'tests/hil/nu54dk'))
from v04_t13_oracle import pattern
folder = WORK/'t13-s-20260908'
source = folder/'soak-concurrent-serial-f591571-attempt1-readonly-01.json'
rows = json.loads(source.read_text())['devices']
result = []
for row in rows:
    raw = base64.b64decode(row['lane_raw_base64'])
    types = row['types']
    lane = types['Lane']
    start = 2*lane['size']
    at = lambda name: start+lane['members'][name]
    value = lambda offset,size=4:int.from_bytes(raw[offset:offset+size],'little')
    completed = value(at('received')+types['Direction']['members']['completed'])
    seed = value(at('seed_rx'))
    slot = completed%2
    buffer_start = at('rx')+slot*types['Buffer']['size']
    data = raw[buffer_start+16:buffer_start+16+256]
    expected = bytes(pattern(seed,completed*256+i) for i in range(256))
    mismatches = [{'offset':i,'actual':data[i],'expected':expected[i]} for i in range(256) if data[i]!=expected[i]]
    result.append({'role':row['role'],'completed':completed,'slot':slot,'seed':seed,
        'prefix241_matches':data[:241]==expected[:241],'mismatches':mismatches,
        'tail15_hex':data[241:].hex(),'data_hex':data.hex(),'expected_hex':expected.hex(),
        'before_guard_hex':raw[buffer_start:buffer_start+16].hex(),
        'after_guard_hex':raw[buffer_start+272:buffer_start+288].hex()})
output=folder/'soak-concurrent-serial-f591571-attempt1-buffer-analysis-01.json'
with output.open('x',encoding='utf-8') as stream:
    json.dump({'source':str(source),'observations':result},stream,indent=2)
print(json.dumps([{k:v for k,v in row.items() if k not in ('data_hex','expected_hex')} for row in result]))
