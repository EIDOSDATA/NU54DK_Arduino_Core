"""! @brief U 재결선 전 S 고정 시험을 유한 실행하며 실패 원본·정지 증명 뒤 독립 항목을 계속합니다. """
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import time
from check_pc import REPO, WORK, PYTHON

FOLDER = WORK / 't13-s-20260908'
SOURCE = '506680f5a1df7d944e547cb573abcd39ffb6dcbf'
BUILD = 'C:/t4h04'
OUTPUT = FOLDER / 'unattended-s-01.json'
assert not OUTPUT.exists()
grant = json.loads((FOLDER / 'session-grant-repair3.json').read_text())
report = dict(status='running', source=SOURCE, until='before-U-rewiring', jobs=[],
              expires_at_unix=grant['expires_at_unix'])


def save():
    """! @brief 각 실행 전후의 상태를 즉시 저장합니다. """
    report['observed_at_utc'] = datetime.now(timezone.utc).isoformat()
    OUTPUT.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(report), flush=True)


def git(*args):
    """! @brief 비활성·clean인 실기 checkout만 조회합니다. """
    return subprocess.check_output(['git', '-C', 'C:/tr13dev', *args], text=True).strip()


jobs = [(f'serial{instance}-handover-sauto-01', 450 if instance == 0 else 1800,
         ['--phase', 'handover', '--handover-instance', str(instance)]) for instance in (0, 20, 21, 22, 30)]
jobs += [(f'c{case - 100:02}-soak-sauto-01', (3600 if case == 105 else 900) + 120,
          ['--phase', 'soak', '--cases', str(case)]) for case in (101, 102, 103, 104, 105, 106, 108)]
try:
    save()
    for name, required_seconds, options in jobs:
        state = json.loads((WORK / 'current_common_task_state.json').read_text())['active_t13_s']
        if any(state.get(key) for key in ('hardware_running', 't13_traffic_paused_by_user', 'requires_wiring_repair')):
            raise RuntimeError('active hardware, user pause or unresolved wiring prevents continuation')
        if grant['expires_at_unix'] - time.time() < required_seconds:
            report['jobs'].append(dict(name=name, status='not-started-insufficient-session-time',
                                       required_seconds=required_seconds))
            save()
            continue
        if git('rev-parse', 'HEAD') != SOURCE or git('status', '--porcelain'):
            raise RuntimeError('registered original source is no longer clean/current')
        report['active'] = name
        save()
        result = subprocess.run([str(PYTHON), '-X', 'utf8', '-B', str(WORK / 'run_t13_recovery.py'),
                                 '--build', BUILD, '--name', name, *options], cwd=REPO)
        path = FOLDER / name / 'result.json'
        data = json.loads(path.read_text()) if path.exists() else {}
        executed = (WORK / (name + '-execute.json')).is_file()
        cleanup = [item for row in data.get('results', []) if row.get('status') == 'cleanup'
                   for item in row.get('outcomes', [])]
        stopped = bool(cleanup and all(item.get('stopped') for item in cleanup))
        row = dict(name=name, exit_code=result.returncode, status=data.get('status', 'preflight-failed'),
                   error=data.get('error'), cleanup_proven=stopped, executed=executed)
        report['jobs'].append(row)
        save()
        if executed:
            archive = subprocess.run([str(PYTHON), '-X', 'utf8', '-B', str(WORK / 'archive_t13_campaign.py'),
                                      name, 't13-' + name + '-506680f'], cwd=REPO)
            if archive.returncode:
                raise RuntimeError('archive failed; preserve output before continuing')
        if executed and not stopped:
            raise RuntimeError('pair cleanup unproven; all further physical work stopped')
        if result.returncode:
            print('T13_INDEPENDENT_CONTINUE_AFTER_PRESERVED_FAILURE ' + name, flush=True)
    report.pop('active', None)
    report['status'] = 'finished-available-fixed-S-jobs'
    save()
except BaseException as error:
    report['status'] = 'stopped-requires-review'
    report['error'] = f'{type(error).__name__}: {error}'
    save()
    raise
