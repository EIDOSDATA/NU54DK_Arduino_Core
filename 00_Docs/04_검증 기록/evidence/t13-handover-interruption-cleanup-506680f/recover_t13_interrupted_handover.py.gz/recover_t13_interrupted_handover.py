"""! @brief 종료된 Host의 원본을 보존하고 동일 nonce의 STOP만 수행해 장치를 정리합니다. """
import json
import logging
import struct
import subprocess
import sys
from datetime import datetime, timezone
from check_pc import REPO, WORK
from pyocd.core.helpers import ConnectHelper

sys.path.insert(0, str(REPO / 'tests/hil/nu54dk'))
import v04_pair as pair
import v04_protocol as protocol
import v04_t13_session as session

logging.disable(logging.CRITICAL)
folder = WORK / 't13-s-20260908'
campaign = 'serial0-506680f-handover-1'
out = folder / (campaign + '-interruption-cleanup.json')
assert not out.exists()
query = "@(Get-CimInstance Win32_Process | Where-Object { $_.Name -match 'python' -and $_.CommandLine -match 'run_t13_verified_batch|launch_t13_recovery|run_t13_recovery.py' }).Count"
assert subprocess.check_output(['C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe',
                                '-NoProfile', '-Command', query], text=True).strip() == '0'
images = json.loads((folder / campaign / 'images.json').read_text())
grant = json.loads((folder / 'session-grant-repair3.json').read_text())
private = json.loads((folder / 'probe-uids-local.json').read_text())
uids = [private[key].lower() for key in grant['uid_sha256']]
session.validate(grant, images, uids)
available = {probe.unique_id.lower() for probe in ConnectHelper.get_all_connected_probes(blocking=False)}
assert set(uids).issubset(available)
report = dict(source=images[0]['core_revision'], status='interrupted-not-pass',
              source_campaign=campaign, completed_rounds_before_interruption=47,
              reset_halt_resume_flash=False, swd_frequency_hz=10000000, devices=[])
with protocol.ProbeLocks(uids):
    for uid, image in zip(uids, images):
        row = dict(role=image['role'])
        report['devices'].append(row)
        try:
            with ConnectHelper.session_with_chosen_probe(unique_id=uid, target_override='nrf54l',
                    frequency=10000000, blocking=False, no_config=True,
                    options={'auto_unlock': False, 'connect_mode': 'attach',
                             'resume_on_disconnect': False, 'cmsis_dap.limit_packets': True}) as connection:
                target = connection.target
                identity = bytes(target.read_memory_block8(image['symbols']['v04_identity'], 64))
                pair.verify_identity(identity, image['role'], image['core_revision'])
                assert struct.unpack('<I', identity[12:16])[0] == 0x54313302
                row['cpu_state'] = target.get_state().name
                response = bytes(target.read_memory_block8(image['symbols']['v04_response'], 128))
                assert response == bytes(target.read_memory_block8(image['symbols']['v04_response'], 128))
                words = struct.unpack('<32I', response)
                nonce = response[20:36]
                protocol.decode(response, nonce, words[2], image['role'], words[4])
                assert target.read32(image['symbols']['v04_request']) == 0
                device = pair.Device(target, image, nonce)
                device.sequence = words[2]
                row['previous_response'] = list(words)
                row['engine_before'] = device.command(99, timeout=2)
                row['stop'] = device.command(102, timeout=2)
                row['clock'] = device.command(107, (0,), timeout=2)
                row['pins'] = device.command(51, timeout=2)
                row['pin_cnf'] = {}
                for port, base, pins in ((0, 0x5010A000, range(4)),
                        (1, 0x500D8200, [4, 5, 6, 7, 10, 14]), (2, 0x50050400, range(7))):
                    for pin in pins:
                        row['pin_cnf'][f'P{port}.{pin:02}'] = target.read32(base + 0x80 + pin * 4)
                row['stopped'] = (row['stop'] == [1] and row['clock'][1] == 0 and
                    row['pins'][1:4] == [0, 0, 0] and row['pins'][7] == 0 and
                    all(value & 0xD == 0 for value in row['pin_cnf'].values()))
        except BaseException as error:
            message = f'{type(error).__name__}: {error}'
            for exact_uid in uids:
                message = message.replace(exact_uid, '[exact UID redacted]')
            row.update(stopped=False, error=message)
report['observed_at_utc'] = datetime.now(timezone.utc).isoformat()
report['cleanup_proven'] = len(report['devices']) == 2 and all(row['stopped'] for row in report['devices'])
out.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
if report['cleanup_proven']:
    state_path = WORK / 'current_common_task_state.json'
    state = json.loads(state_path.read_text())
    state['active_t13_s'].update(hardware_running=False, interrupted_campaign=campaign,
        interruption_cleanup=str(out), checkpoint='Interrupted 47 rounds preserved; pair STOP verified; new campaign required')
    state_path.write_text(json.dumps(state, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(cleanup_proven=report['cleanup_proven'], output=str(out),
    devices=[{key: row[key] for key in ('role', 'cpu_state', 'stopped', 'engine_before', 'error') if key in row}
             for row in report['devices']])))
raise SystemExit(0 if report['cleanup_proven'] else 1)
