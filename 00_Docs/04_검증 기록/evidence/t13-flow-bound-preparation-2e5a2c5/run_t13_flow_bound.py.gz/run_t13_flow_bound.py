"""! @brief CTS 시험의 preflight와 실행 기록을 순서대로 보존합니다. """
from pathlib import Path
helper = Path(__file__).with_name('run_t13_recovery.py')
source = helper.read_text(encoding='utf-8').replace('launch_t13_recovery.py', 'launch_t13_flow_bound.py')
exec(compile(source, str(helper), 'exec'))
