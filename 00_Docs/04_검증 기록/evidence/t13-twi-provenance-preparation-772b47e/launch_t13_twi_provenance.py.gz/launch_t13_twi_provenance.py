"""! @brief 새 TWIM 판정 소스에 기존 exact UID·확인서·flash·CI gate를 유지합니다. """
from pathlib import Path
helper = Path(__file__).with_name('launch_t13_recovery.py')
source = helper.read_text(encoding='utf-8').replace("Path('C:/tr13dev')", "Path('C:/tstwp04')")
source = source.replace("'recovery-builds.json'", "'twi-provenance-builds.json'")
exec(compile(source, str(helper), 'exec'))
