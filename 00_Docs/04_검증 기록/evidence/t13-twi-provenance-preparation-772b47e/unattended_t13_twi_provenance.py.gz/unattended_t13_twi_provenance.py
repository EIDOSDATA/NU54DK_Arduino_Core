"""! @brief TWIS 최초 write 요청의2ms 공급 지연을 기존 보호 조건과 함께 검사합니다. """
from pathlib import Path

helper = Path(__file__).with_name('unattended_t13_followups.py')
prefix = helper.read_text(encoding='utf-8').split('\ntry:\n    save()')[0]
prefix = prefix.replace("'unattended-s-followups-01.json'", "'unattended-s-twi-provenance-01.json'")
prefix = prefix.replace("'waiting-for-current-S-batch'", "'waiting-for-twis-delay-tests'")
exec(compile(prefix, str(helper), 'exec'))

try:
    save()
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.OpenProcess.argtypes = (ctypes.c_uint32, ctypes.c_bool, ctypes.c_uint32)
    kernel.OpenProcess.restype = ctypes.c_void_p
    kernel.WaitForSingleObject.argtypes = (ctypes.c_void_p, ctypes.c_uint32)
    kernel.WaitForSingleObject.restype = ctypes.c_uint32
    kernel.CloseHandle.argtypes = (ctypes.c_void_p,)
    handle = kernel.OpenProcess(0x00100000, False, 24768)
    if not handle:
        raise RuntimeError('original TWIS delay process handle unavailable; review final state')
    try:
        while True:
            result = kernel.WaitForSingleObject(handle, 20000)
            if result == 0:
                break
            if result != 258:
                raise RuntimeError('TWIS delay process wait failed')
            if time.time() >= grant['expires_at_unix']:
                raise RuntimeError('S confirmation ended while prior TWIS delay tests were running')
    finally:
        kernel.CloseHandle(handle)
    previous = json.loads((folder/'unattended-s-twis-delay-01.json').read_text())
    if previous['status'] != 'finished-available-twis-delay-tests':
        raise RuntimeError('prior TWIS delay tests did not finish with attempted cleanup proven')
    records = json.loads((folder/'twi-provenance-builds.json').read_text())
    if len(records) != 1:
        raise RuntimeError('one exact TWIM RX provenance build registration required')
    build, record = next(iter(records.items()))
    source = record['source']
    passed = []
    for case in (16, 17, 18, 19):
        for role in (1,):
            name = f'twiprovenance{case}'
            options = ['--cases', str(case), '--fault-role', str(role), '--fault-mode', '4']
            if execute(name+'-preflight-sauto-01', source, 'run_t13_twi_provenance.py', build,
                       ['--phase', 'fault-preflight', *options], 120):
                passed.append((name, options))
    for name, options in passed:
        execute(name+'-100-sauto-01', source, 'run_t13_twi_provenance.py', build,
                ['--phase', 'serial-fault', *options], 420)
    report.pop('active', None)
    report['status'] = 'finished-available-twi-provenance-tests'
    save()
except BaseException as error:
    report.update(status='stopped-requires-review', error=f'{type(error).__name__}: {error}')
    save()
    raise
