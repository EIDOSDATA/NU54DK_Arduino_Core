"""! @brief TWIS 최초 write 요청의2ms 공급 지연을 기존 보호 조건과 함께 검사합니다. """
from pathlib import Path
helper = Path(__file__).with_name('run_t13_recovery.py')
source = helper.read_text(encoding='utf-8').replace('launch_t13_recovery.py', 'launch_t13_twi_provenance.py')
exec(compile(source, str(helper), 'exec'))
