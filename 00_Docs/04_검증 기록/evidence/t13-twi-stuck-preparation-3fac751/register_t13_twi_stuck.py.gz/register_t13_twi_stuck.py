"""! @brief SPI boundary의 exact image·로컬 검사·원격 전체 Host를 확인한 뒤 등록합니다. """
import json
from pathlib import Path
import re
import sys
from check_pc import WORK

source = sys.argv[1]
assert re.fullmatch('[0-9a-f]{40}', source)
repo = Path('C:/tsst04')
sys.path.insert(0, str(repo/'tests/hil/nu54dk'))
import v04_pair as pair
images = [pair.inspect_image(repo, Path('C:/t4t04'), role, family='t13_s') for role in (1, 2)]
assert all(image['core_revision'] == source for image in images)
gates = ['t13-twi-stuck-exact-'+name+'-01' for name in ('target', 'style', 'unit', 'contract', 'docs')]
assert all(json.loads((WORK/(gate+'.json')).read_text())['exit_code'] == 0 for gate in gates)
ci_name = 'ci-'+source[:7]+'-01'
ci = json.loads((WORK/'t13-s-20260908'/(ci_name+'.json')).read_text())
assert ci['source'] == source
assert any(row['name'] == 'Host unit with Windows PowerShell contracts' and row['conclusion'] == 'success'
           for row in ci['checks'])
path = WORK/'t13-s-20260908/twi-stuck-builds.json'
assert not path.exists()
record = {'C:/t4t04': {'source': source, 'repository': str(repo), 'local_gates': gates,
    'remote_exact_host': ci_name+'; success',
    'host_scope': 'Local changed SDA LOW recovery four tests; entire exact Host additionally mandatory on remote Windows CI',
    'purpose': 'S TWIM20/21/22/30 A staged recovery while B holds existing SDA open-drain LOW100ms; four conditions'}}
path.write_text(json.dumps(record, indent=2)+'\n')
print('registered C:/t4t04; no physical access')
