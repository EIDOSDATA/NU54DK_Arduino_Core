"""! @brief 등록된 SDA LOW 전용 image를 원래 UID·확인서·CI·실기 배타 검사 뒤 실행합니다. """
from pathlib import Path
helper = Path(__file__).with_name('launch_t13_recovery.py')
source = helper.read_text(encoding='utf-8').replace("Path('C:/tr13dev')", "Path('C:/tsst04')")
source = source.replace("'recovery-builds.json'", "'twi-stuck-builds.json'")
source = source.replace("'pwm-recovery-preflight', 'pwm-recovery'), required=True)",
    "'pwm-recovery-preflight', 'pwm-recovery', 'twi-stuck-preflight', 'twi-stuck'), required=True)")
assert "'twi-stuck'" in source
exec(compile(source, str(helper), 'exec'))
