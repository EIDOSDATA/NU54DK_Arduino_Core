# Third-party notices

이 파일은 Boards Manager 패키지에 포함된 외부 구성요소를 식별합니다. 저장소 최상위
`LICENSE`의 MIT 조건은 NUCODE가 자체 작성한 코드에만 적용되며 아래 구성요소의 원
라이선스를 대체하지 않습니다.

## ArduinoCore-API 1.5.2

- 원본: <https://github.com/arduino/ArduinoCore-API>
- 고정 commit: `cd91833d90b4fe50e428021ba5051e2b7ceafc84`
- 라이선스: `LGPL-2.1-or-later AND MIT`
- 원문: `third_party/ArduinoCore-API/LICENSE`

## NU54DK Zephyr DTS

- 원본: <https://github.com/Nucode01/NU54DK_Zephyr_DTS>
- 고정 commit: `fe65f2f0880bd05b32e562d9bf1ee59142b4f4d3`
- 패키지 포함 범위의 종합 식별: `MIT AND Apache-2.0`
- 저장소 최상위 원문 `LICENSE`: `MIT`
- 파생 범위 `boards/nucode/nu54dk/**`: `Apache-2.0`
- Apache 원문: `board_package/NU54DK_Zephyr_DTS/LICENSES/Apache-2.0.txt`
- 범위 고지: `board_package/NU54DK_Zephyr_DTS/NOTICE`

## 외부 설치 전제조건

다음 항목은 이 Boards Manager ZIP에 포함하거나 재배포하지 않고 공식 설치기 또는 사용자가
별도로 공급합니다. 종합 라이선스는 추정하지 않고 `NOASSERTION`으로 기록하며 최종 공개 전
법률 검토가 필요합니다.

- nRF Util `8.2.1` 및 nRF Util sdk-manager `1.16.1`
- nRF Connect SDK `v3.4.0` (`99553055607b2e9885fbc80ccd11fa9da81c2df0`)
- Zephyr `4.4.0` (`bf801e4e3d19e1ffa76164346480cb7734dd2800`)
- nRF Connect SDK toolchain bundle `dcbdc366a1`
- toolchain에 포함된 pyOCD `0.45.1`
- 사용자가 선택적으로 설치하는 SEGGER J-Link Software

상세 checksum과 파일별 SPDX 선언은 `license-inventory.json` 및 `sbom.spdx.json`에
기록합니다. 이 목록은 법률 자문 또는 최종 공개 배포 승인을 대신하지 않습니다.
